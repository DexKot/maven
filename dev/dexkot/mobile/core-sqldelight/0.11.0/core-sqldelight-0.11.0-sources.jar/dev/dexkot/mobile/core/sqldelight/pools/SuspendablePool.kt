package dev.dexkot.mobile.core.sqldelight.pools

import kotlinx.coroutines.sync.Mutex

class SuspendablePool<Type>(
    private val factory: () -> Type
) {

    private val pool = mutableListOf<Type>()
    private val mutex = Mutex(locked = false)

    suspend fun acquire(): Type {
        mutex.lock()
        val instance = pool.removeFirstOrNull()
        mutex.unlock()
        return instance ?: factory()
    }

    suspend fun release(instance: Type) {
        mutex.lock()
        pool.add(instance)
        mutex.unlock()
    }

}
