package dev.dexkot.mobile.core.sqldelight

import dev.dexkot.mobile.core.foundation.result.ResultOf

internal class RollbackException(
    val failure: ResultOf.Failure<*>
): Exception()
