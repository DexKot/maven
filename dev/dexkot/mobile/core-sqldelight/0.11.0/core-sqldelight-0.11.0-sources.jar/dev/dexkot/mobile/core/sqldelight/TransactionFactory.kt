package dev.dexkot.mobile.core.sqldelight

import app.cash.sqldelight.SuspendingTransacter
import app.cash.sqldelight.db.SqlDriver
import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.errors.ErrorEntity
import dev.dexkot.mobile.core.foundation.result.map
import dev.dexkot.mobile.core.foundation.data.transaction.ITransaction
import dev.dexkot.mobile.core.foundation.data.transaction.ITransactionFactory
import dev.dexkot.mobile.core.sqldelight.pools.SuspendablePool
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.coroutines.coroutineContext

class TransactionFactory(
    private val sqlDriver: SqlDriver,
    private val transacter: SuspendingTransacter
): ITransactionFactory {

    private val dispatchersPool = SuspendablePool(
        factory = { Executors.newSingleThreadExecutor().asCoroutineDispatcher() }
    )

    override suspend fun <Out> withTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out> {
        return currentTransaction()?.continueTransaction(block = block) ?: newTransaction(block = block)
    }

    private suspend fun <Out> newTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out> {

        val coroutineDispatcher = dispatchersPool.acquire()

        return withContext(coroutineDispatcher) {

            try {
                transacter.transactionWithResult {
                    val transaction = Transaction(
                        dispatcher = coroutineDispatcher,
                        sqlDriver = sqlDriver,
                        sqlTransaction = this
                    )

                    transaction.execute(block)
                }
            } catch (exception: RollbackException) {
                exception.failure.map()
            } catch (exception: Throwable) {
                ResultOf.Failure(
                    error = ErrorEntity.UnexpectedError(
                        exception = exception
                    )
                )
            } finally {
                dispatchersPool.release(coroutineDispatcher)
            }
        }

    }

    private suspend fun <Out> TransactionContextElement.continueTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out> {
        return try {
            transaction.innerTransaction(block)
        } catch (exception: RollbackException) {
            exception.failure.map()
        } catch (exception: Throwable) {
            ResultOf.Failure(
                error = ErrorEntity.UnexpectedError(
                    exception = exception
                )
            )
        }
    }

    private suspend fun currentTransaction(): TransactionContextElement? {
        return coroutineContext[TransactionContextElement]
    }

}
