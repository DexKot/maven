package dev.dexkot.mobile.core.remoteconfig.handler

import dev.dexkot.mobile.core.foundation.errors.ErrorEntity
import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.result.failureOf
import dev.dexkot.mobile.core.foundation.result.map
import dev.dexkot.mobile.core.foundation.result.successOf
import dev.dexkot.mobile.core.logger.interactors.ddl.logger
import dev.dexkot.mobile.core.remoteconfig.flow.mapState
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.Json

/**
 * Lee [key] como string y lo decodifica como JSON a [T] con [IRemoteConfigHandler.serializer].
 *
 * - Clave sin valor (string vacío): `Failure(ErrorEntity.NoData)`. No es un error de decodificación:
 *   la clave simplemente no está configurada en el backend.
 * - JSON inválido o que no corresponde a [T]: `Failure(ErrorEntity.UnexpectedError)` con la excepción
 *   de serialización.
 * - Error del handler al leer: se propaga la misma falla.
 */
inline fun <reified T> IRemoteConfigHandler.get(key: String): ResultOf<T> {
    return when (val stringResult = getString(key)) {
        is ResultOf.Success -> {
            if (stringResult.data.isEmpty()) return failureOf(ErrorEntity.NoData())
            try {
                successOf(serializer.decodeFromString<T>(stringResult.data))
            } catch (exception: Exception) {
                failureOf(exception)
            }
        }
        is ResultOf.Failure -> {
            stringResult.map()
        }
    }
}

inline fun <reified T> IRemoteConfigHandler.getFlow(
    key: String,
    defaultValue: T
): StateFlow<T> {
    val originalFlow = getStringFlow(key, "")
    return originalFlow.mapState { stringValue ->
        try {
            if (stringValue.isEmpty())
                defaultValue
            else
                serializer.decodeFromString<T>(stringValue)
        } catch (exception: Exception) {
            logger {
                error(
                    throwable = exception,
                    message = "Failed to decode string with key $key from remote config"
                )
            }
            defaultValue
        }
    }
}
