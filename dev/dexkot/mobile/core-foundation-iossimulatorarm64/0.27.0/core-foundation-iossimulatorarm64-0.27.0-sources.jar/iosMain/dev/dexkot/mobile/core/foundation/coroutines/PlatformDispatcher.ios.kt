package dev.dexkot.mobile.core.foundation.coroutines

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Runnable
import platform.darwin.DISPATCH_QUEUE_PRIORITY_DEFAULT
import platform.darwin.dispatch_async
import platform.darwin.dispatch_get_global_queue
import platform.darwin.dispatch_get_main_queue
import platform.darwin.dispatch_queue_t
import kotlin.coroutines.CoroutineContext

@OptIn(ExperimentalForeignApi::class)
actual object PlatformDispatchers : PlatformDispatcher {
    actual override val main: CoroutineDispatcher = GcdDispatcher(dispatch_get_main_queue())
    actual override val io: CoroutineDispatcher =
        GcdDispatcher(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT.toLong(), 0u))
    actual override val default: CoroutineDispatcher =
        GcdDispatcher(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT.toLong(), 0u))
    actual override val unconfined: CoroutineDispatcher = Dispatchers.Unconfined
}

/**
 * A [CoroutineDispatcher] backed by a Grand Central Dispatch queue. Used because
 * `Dispatchers.IO` is `internal` on Kotlin/Native, so real background execution needs GCD.
 */
@OptIn(ExperimentalForeignApi::class)
private class GcdDispatcher(
    private val queue: dispatch_queue_t
) : CoroutineDispatcher() {
    override fun dispatch(context: CoroutineContext, block: Runnable) {
        dispatch_async(queue) { block.run() }
    }
}
