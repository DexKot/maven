package dev.dexkot.mobile.core.database.sqldelight

import kotlinx.coroutines.ThreadContextElement
import kotlin.coroutines.CoroutineContext

internal class TransactionContextElement internal constructor(
    val transaction: Transaction<*>
) : ThreadContextElement<Transaction<*>?> {

    override val key: CoroutineContext.Key<TransactionContextElement> get() = Key

    override fun updateThreadContext(context: CoroutineContext): Transaction<*>? {
        val previous = threadLocal.get()
        threadLocal.set(transaction)
        return previous
    }

    override fun restoreThreadContext(context: CoroutineContext, oldState: Transaction<*>?) {
        threadLocal.set(oldState)
    }

    companion object Key : CoroutineContext.Key<TransactionContextElement> {
        private val threadLocal = ThreadLocal<Transaction<*>?>()

        fun current(): Transaction<*>? = threadLocal.get()
    }
}
