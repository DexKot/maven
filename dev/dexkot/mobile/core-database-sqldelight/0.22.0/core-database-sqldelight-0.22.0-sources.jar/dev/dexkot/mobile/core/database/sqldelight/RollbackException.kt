package dev.dexkot.mobile.core.database.sqldelight

import dev.dexkot.mobile.core.foundation.result.ResultOf

internal class RollbackException(
    val failure: ResultOf.Failure<*>
): Exception()
