package dev.dexkot.mobile.core.work.di.koin

import dev.dexkot.mobile.core.work.data.config.WorkTypeConfigFactory
import dev.dexkot.mobile.core.work.data.executor.WorkExecutorFactory
import dev.dexkot.mobile.core.work.domain.config.IWorkTypeConfigFactory
import dev.dexkot.mobile.core.work.domain.config.IWorkTypeConfigProvider
import dev.dexkot.mobile.core.work.domain.executor.IWorkExecutorFactory
import dev.dexkot.mobile.core.work.domain.executor.IWorkExecutorProvider
import org.koin.dsl.module

/**
 * Bindings comunes a cualquier backend de work: los factories que colectan los providers pluggables
 * ([IWorkTypeConfigProvider], [IWorkExecutorProvider]) que registran los feature modules.
 *
 * Lo incluyen tanto [coroutineWorkModule] (commonMain) como `workManagerWorkModule` (androidMain).
 */
val workFactoriesModule = module {

    single<IWorkTypeConfigFactory> {
        WorkTypeConfigFactory(delegates = getAll<IWorkTypeConfigProvider>())
    }

    single<IWorkExecutorFactory> {
        WorkExecutorFactory(providers = getAll<IWorkExecutorProvider>())
    }

}
