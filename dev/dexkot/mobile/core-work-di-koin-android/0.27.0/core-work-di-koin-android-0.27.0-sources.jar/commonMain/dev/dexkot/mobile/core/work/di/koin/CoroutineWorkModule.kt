package dev.dexkot.mobile.core.work.di.koin

import dev.dexkot.mobile.core.work.data.coroutine.CoroutineCancelWorkUseCase
import dev.dexkot.mobile.core.work.data.coroutine.CoroutineObserveWorkStatusUseCase
import dev.dexkot.mobile.core.work.data.coroutine.CoroutineScheduleWorkUseCase
import dev.dexkot.mobile.core.work.data.coroutine.CoroutineWorkEngine
import dev.dexkot.mobile.core.work.data.coroutine.NoOpWorkBackgroundGrace
import dev.dexkot.mobile.core.work.data.coroutine.WorkBackgroundGrace
import dev.dexkot.mobile.core.work.domain.usecase.ICancelWorkUseCase
import dev.dexkot.mobile.core.work.domain.usecase.IObserveWorkStatusUseCase
import dev.dexkot.mobile.core.work.domain.usecase.IScheduleWorkUseCase
import dev.dexkot.mobile.core.work.domain.worker.WorkerCoroutineContextFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.koin.core.qualifier.named
import org.koin.dsl.module

/**
 * Qualifier para el [CoroutineScope] app-scoped que el consumidor puede proveer para el work engine.
 *
 * Si el consumidor registra `single<CoroutineScope>(workCoroutineScope()) { ... }` (atado al ciclo de
 * vida de la app), el engine lo usa; si no, [coroutineWorkModule] crea uno por defecto.
 */
fun workCoroutineScope() = named("dev.dexkot.mobile.core.work.coroutineScope")

/**
 * Backend **in-process (corrutinas)** del contrato de work. Multiplataforma: es el que usa iOS, y
 * Android podría usarlo también (tests, work liviano que no necesita sobrevivir a la muerte del proceso).
 *
 * El consumidor puede proveer opcionalmente un [CoroutineScope] con el qualifier [workCoroutineScope]
 * y/o un [WorkBackgroundGrace]; si no, se usan defaults.
 */
val coroutineWorkModule = module {

    includes(workFactoriesModule)

    single<CoroutineWorkEngine> {
        CoroutineWorkEngine(
            scope = getOrNull<CoroutineScope>(workCoroutineScope())
                ?: CoroutineScope(SupervisorJob() + Dispatchers.Default),
            grace = getOrNull<WorkBackgroundGrace>() ?: NoOpWorkBackgroundGrace
        )
    }

    single<IScheduleWorkUseCase> {
        CoroutineScheduleWorkUseCase(
            engine = get(),
            executorFactory = get(),
            contextFactory = getOrNull<WorkerCoroutineContextFactory>()
        )
    }

    single<IObserveWorkStatusUseCase> {
        CoroutineObserveWorkStatusUseCase(engine = get())
    }

    single<ICancelWorkUseCase> {
        CoroutineCancelWorkUseCase(engine = get())
    }

}
