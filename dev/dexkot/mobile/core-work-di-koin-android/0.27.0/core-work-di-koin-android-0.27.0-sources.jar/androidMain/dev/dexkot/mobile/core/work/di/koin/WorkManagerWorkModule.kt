package dev.dexkot.mobile.core.work.di.koin

import androidx.work.WorkManager
import dev.dexkot.mobile.core.work.data.notification.WorkNotificationFactory
import dev.dexkot.mobile.core.work.data.worker.GenericWorkRunner
import dev.dexkot.mobile.core.work.domain.constraint.ConstraintChangeListener
import dev.dexkot.mobile.core.work.domain.constraint.ConstraintChecker
import dev.dexkot.mobile.core.work.domain.notification.IWorkNotificationFactory
import dev.dexkot.mobile.core.work.domain.notification.IWorkNotificationProvider
import dev.dexkot.mobile.core.work.domain.usecase.CancelWorkUseCase
import dev.dexkot.mobile.core.work.domain.usecase.ICancelWorkUseCase
import dev.dexkot.mobile.core.work.domain.usecase.IObserveWorkStatusUseCase
import dev.dexkot.mobile.core.work.domain.usecase.IScheduleWorkUseCase
import dev.dexkot.mobile.core.work.domain.usecase.ObserveWorkStatusUseCase
import dev.dexkot.mobile.core.work.domain.usecase.ScheduleWorkUseCase
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

/**
 * Backend **WorkManager** del contrato de work (Android): ejecución diferida real, con constraints y
 * notificaciones/foreground-service.
 *
 * El worker es app-owned: la app registra su propio `worker { MyWorker(...) }` (que delega en
 * [GenericWorkRunner]) y provee un `WorkerClassProvider` (que [ScheduleWorkUseCase] usa para saber qué
 * clase encolar); sigue llamando `workManagerFactory()` en `startKoin`. Los providers pluggables
 * (config/executor/notification) los registran los feature modules; este módulo solo los colecta.
 */
val workManagerWorkModule = module {

    includes(workFactoriesModule)

    single { WorkManager.getInstance(androidContext()) }

    single<IWorkNotificationFactory> {
        WorkNotificationFactory(providers = getAll<IWorkNotificationProvider>())
    }

    single {
        GenericWorkRunner(
            executorFactory = get(),
            notificationFactory = get(),
            permissionChecker = get(),
            coroutineContextFactory = getOrNull()
        )
    }

    single<IScheduleWorkUseCase> {
        ScheduleWorkUseCase(
            workManager = get(),
            configProvider = get(),
            workerClassProvider = get()
        )
    }

    single<ICancelWorkUseCase> {
        CancelWorkUseCase(context = androidContext(), workManager = get())
    }

    single { ConstraintChecker(context = androidContext()) }

    single { ConstraintChangeListener(context = androidContext()) }

    single<IObserveWorkStatusUseCase> {
        ObserveWorkStatusUseCase(
            workManager = get(),
            configFactory = get(),
            constraintChecker = get(),
            constraintChangeListener = get()
        )
    }

}
