package dev.dexkot.mobile.core.preferences.di

import com.russhwolf.settings.NSUserDefaultsSettings
import com.russhwolf.settings.Settings
import org.koin.core.module.Module
import org.koin.dsl.module

actual val settingsFactoryModule: Module = module {
    single<Settings.Factory> { NSUserDefaultsSettings.Factory() }
}
