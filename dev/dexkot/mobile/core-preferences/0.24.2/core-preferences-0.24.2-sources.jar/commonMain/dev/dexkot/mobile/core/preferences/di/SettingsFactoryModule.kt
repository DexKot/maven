package dev.dexkot.mobile.core.preferences.di

import org.koin.core.module.Module

/**
 * Provee un [com.russhwolf.settings.Settings.Factory] multiplataforma — la única pieza específica de
 * plataforma para crear stores de key-value (SharedPreferences en Android, NSUserDefaults en iOS).
 *
 * Los consumidores definen sus stores por NOMBRE en commonMain:
 * `single<Settings>(qualifier) { get<Settings.Factory>().create("mi.store") }`.
 */
expect val settingsFactoryModule: Module
