package dev.dexkot.mobile.core.remoteconfig.handler

/**
 * Thin platform-specific access to the PostHog feature-flag SDK. All orchestration lives in
 * [PostHogRemoteConfigHandler]; this only exposes the raw calls that differ per platform.
 */
internal expect class PostHogRemoteConfigClient() {

    /** Reloads feature flags, waiting at most [timeoutMillis]. Throws on timeout. */
    suspend fun reloadFeatureFlags(timeoutMillis: Long)

    /**
     * The payload of feature flag [key] as a string (JSON for structured payloads, the plain value
     * for scalars), or null if the flag has no payload.
     */
    fun featureFlagPayloadString(key: String): String?
}
