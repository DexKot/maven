package dev.dexkot.mobile.core.remoteconfig.handler

import dev.dexkot.mobile.core.foundation.errors.ErrorEntity
import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.result.getOrDefault
import dev.dexkot.mobile.core.logger.interactors.ddl.logger
import dev.dexkot.mobile.core.remoteconfig.error.ConfigNotFound
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import kotlin.concurrent.atomics.AtomicReference
import kotlin.concurrent.atomics.ExperimentalAtomicApi

/**
 * [IRemoteConfigHandler] backed by PostHog feature flags.
 *
 * All orchestration — the reactive flows, value parsing and reload flow — lives here in common code.
 * Only the raw SDK calls are platform-specific, delegated to [PostHogRemoteConfigClient] (PostHog
 * Android SDK on Android, PostHog iOS via cinterop on iOS). Uses the SDK singleton internally.
 */
@OptIn(ExperimentalAtomicApi::class)
class PostHogRemoteConfigHandler(
    override val serializer: Json,
) : IRemoteConfigHandler {

    private val client = PostHogRemoteConfigClient()

    private val boolFlows = AtomicReference<Map<String, MutableStateFlow<Boolean>>>(emptyMap())
    private val longFlows = AtomicReference<Map<String, MutableStateFlow<Long>>>(emptyMap())
    private val stringFlows = AtomicReference<Map<String, MutableStateFlow<String>>>(emptyMap())

    override suspend fun sync(): ResultOf<Boolean> {
        return try {
            client.reloadFeatureFlags(SYNC_TIMEOUT_MS)
            updateFlows()
            ResultOf.Success(true)
        } catch (exception: Exception) {
            logger {
                error(throwable = exception, message = "Failed to sync PostHog feature flags")
            }
            ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
        }
    }

    override fun getBoolean(key: String): ResultOf<Boolean> = read(key) { it.toBoolean() }

    override fun getLong(key: String): ResultOf<Long> =
        read(key) { it.toLongOrNull() ?: it.toDouble().toLong() }

    override fun getString(key: String): ResultOf<String> = read(key) { it }

    override fun getBooleanFlow(key: String, defaultValue: Boolean): StateFlow<Boolean> =
        boolFlows.getOrCreate(key) { getBoolean(key).getOrDefault(defaultValue) }

    override fun getLongFlow(key: String, defaultValue: Long): StateFlow<Long> =
        longFlows.getOrCreate(key) { getLong(key).getOrDefault(defaultValue) }

    override fun getStringFlow(key: String, defaultValue: String): StateFlow<String> =
        stringFlows.getOrCreate(key) { getString(key).getOrDefault(defaultValue) }

    private fun <T> read(key: String, parse: (String) -> T): ResultOf<T> {
        val raw = client.featureFlagPayloadString(key)
            ?: return ResultOf.Failure(ConfigNotFound(configKey = key))
        return try {
            ResultOf.Success(parse(raw))
        } catch (exception: Exception) {
            logger {
                error(throwable = exception, message = "Failed to parse value for key $key from PostHog")
            }
            ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
        }
    }

    private fun updateFlows() {
        boolFlows.load().forEach { (key, flow) -> flow.value = getBoolean(key).getOrDefault(flow.value) }
        longFlows.load().forEach { (key, flow) -> flow.value = getLong(key).getOrDefault(flow.value) }
        stringFlows.load().forEach { (key, flow) -> flow.value = getString(key).getOrDefault(flow.value) }
    }

    private fun <T> AtomicReference<Map<String, MutableStateFlow<T>>>.getOrCreate(
        key: String,
        initial: () -> T
    ): StateFlow<T> {
        load()[key]?.let { return it.asStateFlow() }
        val created = MutableStateFlow(initial())
        while (true) {
            val current = load()
            current[key]?.let { return it.asStateFlow() }
            if (compareAndSet(current, current + (key to created))) return created.asStateFlow()
        }
    }

    private companion object {
        const val SYNC_TIMEOUT_MS = 15_000L
    }
}
