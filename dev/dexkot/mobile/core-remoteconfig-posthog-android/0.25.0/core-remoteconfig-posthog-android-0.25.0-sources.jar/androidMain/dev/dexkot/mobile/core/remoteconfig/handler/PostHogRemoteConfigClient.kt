package dev.dexkot.mobile.core.remoteconfig.handler

import com.posthog.PostHog
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

internal actual class PostHogRemoteConfigClient actual constructor() {

    actual suspend fun reloadFeatureFlags(timeoutMillis: Long) {
        val deferred = CompletableDeferred<Unit>()
        PostHog.reloadFeatureFlags { deferred.complete(Unit) }
        withTimeout(timeoutMillis) { deferred.await() }
    }

    actual fun featureFlagPayloadString(key: String): String? =
        PostHog.getFeatureFlagPayload(key)?.asConfigString()

    private fun Any.asConfigString(): String = when (this) {
        is String -> this
        is Map<*, *>, is List<*> -> Json.encodeToString(JsonElement.serializer(), toJsonElement())
        else -> toString()
    }
}

private fun Any?.toJsonElement(): JsonElement = when (this) {
    null -> JsonNull
    is Boolean -> JsonPrimitive(this)
    is Number -> JsonPrimitive(this)
    is String -> JsonPrimitive(this)
    is Map<*, *> -> JsonObject(entries.associate { (k, v) -> k.toString() to v.toJsonElement() })
    is List<*> -> JsonArray(map { it.toJsonElement() })
    else -> JsonPrimitive(toString())
}
