package dev.dexkot.mobile.core.logger

import com.posthog.PostHog
import dev.dexkot.mobile.core.logger.levels.Level

internal actual class PostHogClient actual constructor() {

    actual fun identify(distinctId: String) {
        PostHog.identify(distinctId)
    }

    actual fun reset() {
        PostHog.reset()
    }

    actual fun setPersonProperties(properties: Map<String, Any>) {
        PostHog.setPersonProperties(userPropertiesToSet = properties)
    }

    actual fun capture(event: String, properties: Map<String, Any>) {
        PostHog.capture(event = event, properties = properties)
    }

    actual fun screen(screenTitle: String) {
        PostHog.screen(screenTitle = screenTitle)
    }

    actual fun captureException(throwable: Throwable, properties: Map<String, Any>) {
        PostHog.captureException(throwable = throwable, properties = properties)
    }

    actual fun diagnosticLog(level: Level, message: String, params: Map<String, Any>) {
        when (level) {
            Level.Verbose -> PostHog.logger.trace(message, params)
            Level.Debug -> PostHog.logger.debug(message, params)
            Level.Info -> PostHog.logger.info(message, params)
            Level.Warning -> PostHog.logger.warn(message, params)
            Level.Error -> PostHog.logger.error(message, params)
        }
    }
}
