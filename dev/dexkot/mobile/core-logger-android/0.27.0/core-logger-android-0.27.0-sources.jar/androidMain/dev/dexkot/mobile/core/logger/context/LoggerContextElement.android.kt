package dev.dexkot.mobile.core.logger.context

import dev.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor
import kotlinx.coroutines.ThreadContextElement
import kotlin.coroutines.CoroutineContext

actual class LoggerContextElement actual constructor(
    private val loggerInteractor: ILoggerInteractor,
) : ThreadContextElement<ILoggerInteractor?> {

    actual override val key: CoroutineContext.Key<*> get() = Key

    override fun updateThreadContext(context: CoroutineContext): ILoggerInteractor? {
        val previous = threadLocal.get()
        threadLocal.set(loggerInteractor)
        return previous
    }

    override fun restoreThreadContext(context: CoroutineContext, oldState: ILoggerInteractor?) {
        threadLocal.set(oldState)
    }

    actual companion object Key : CoroutineContext.Key<LoggerContextElement> {
        private val threadLocal = ThreadLocal<ILoggerInteractor?>()
        private var defaultLogger: ILoggerInteractor? = null

        actual fun current(): ILoggerInteractor? = threadLocal.get() ?: defaultLogger

        actual fun setDefault(logger: ILoggerInteractor) {
            defaultLogger = logger
        }
    }
}
