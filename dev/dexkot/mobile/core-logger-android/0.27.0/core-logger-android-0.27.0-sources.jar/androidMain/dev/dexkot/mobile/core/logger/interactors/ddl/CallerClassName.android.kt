package dev.dexkot.mobile.core.logger.interactors.ddl

internal actual fun currentCallerClassName(): String? {
    val stackTrace = Thread.currentThread().stackTrace
    val callerElement = stackTrace.getOrNull(STACK_DEPTH_TO_CALLER)
    return callerElement?.className?.substringAfterLast('.')
}

// LoggerInteractor.log -> currentCallerClassName -> this actual: index into the caller's frame.
private const val STACK_DEPTH_TO_CALLER = 6
