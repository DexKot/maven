package dev.dexkot.mobile.core.logger

import android.util.Log
import dev.dexkot.mobile.core.logger.levels.Level

internal actual fun platformLog(level: Level, tag: String, message: String) {
    val priority = when (level) {
        Level.Verbose -> Log.VERBOSE
        Level.Debug -> Log.DEBUG
        Level.Info -> Log.INFO
        Level.Warning -> Log.WARN
        Level.Error -> Log.ERROR
    }
    Log.println(priority, tag, message)
}

internal actual fun platformLog(tag: String, message: String, throwable: Throwable) {
    Log.e(tag, message, throwable)
}
