package dev.dexkot.mobile.core.work.data.worker

import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ForegroundInfo
import androidx.work.ListenableWorker
import androidx.work.workDataOf
import dev.dexkot.mobile.core.permission.Permission
import dev.dexkot.mobile.core.permission.checker.IPermissionChecker
import dev.dexkot.mobile.core.work.domain.executor.IWorkExecutorFactory
import dev.dexkot.mobile.core.work.domain.executor.model.WorkResult
import dev.dexkot.mobile.core.work.domain.notification.IWorkNotificationFactory
import dev.dexkot.mobile.core.work.domain.notification.NotificationContent
import dev.dexkot.mobile.core.work.domain.notification.WorkCompletionStatus
import dev.dexkot.mobile.core.work.domain.executor.model.WorkProgressData
import dev.dexkot.mobile.core.work.domain.notification.WorkNotificationId
import dev.dexkot.mobile.core.work.domain.worker.WorkerCoroutineContextFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.withContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlin.uuid.Uuid

/**
 * Lógica de ejecución de work genérica, reutilizable, **sin** ser el worker registrado en WorkManager.
 *
 * El worker concreto lo define y registra la **app** (para que su FQN sea estable y app-owned, ya que
 * WorkManager persiste ese nombre). El worker de la app solo delega en este runner:
 *
 * ```kotlin
 * class MyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
 *     override suspend fun doWork(): Result = koinInject<GenericWorkRunner>().run(this)
 * }
 * // y lo registra: worker { MyWorker(get(), get()) } + workManagerFactory() en startKoin
 * ```
 *
 * Este runner:
 * 1. Lee el work type y work ID del [ListenableWorker.getInputData] del worker.
 * 2. Crea el executor apropiado vía [executorFactory] y delega la ejecución.
 * 3. Mapea [WorkResult] al [ListenableWorker.Result] de WorkManager.
 * 4. Maneja notificaciones de progreso y foreground service.
 *
 * @property executorFactory Factory para crear executors según el work type.
 * @property notificationFactory Factory para crear los handlers de notificación por work type.
 * @property permissionChecker Checker para verificar el permiso de notificaciones.
 * @property coroutineContextFactory Contexto adicional opcional por work type.
 */
class GenericWorkRunner(
    private val executorFactory: IWorkExecutorFactory,
    private val notificationFactory: IWorkNotificationFactory,
    private val permissionChecker: IPermissionChecker,
    private val coroutineContextFactory: WorkerCoroutineContextFactory? = null
) {

    companion object {

        /**
         * Input data key for work type identifier.
         */
        private const val KEY_WORK_TYPE = "work_type"

        /**
         * Input data key for work instance ID.
         */
        private const val KEY_WORK_ID = "work_id"

        /**
         * Creates input data for the worker.
         * @param workType The type of work to be executed
         * @param workId The unique identifier for this work instance
         * @return Data object containing the work type and work ID
         */
        fun createInputData(
            workType: String,
            workId: Uuid
        ): Data {
            return workDataOf(
                KEY_WORK_TYPE to workType,
                KEY_WORK_ID to workId.toString()
            )
        }

    }

    /**
     * Ejecuta el work delegando en el executor apropiado.
     *
     * @param worker el worker concreto (app-owned) que invoca este runner desde su `doWork()`.
     * @return [ListenableWorker.Result] success/retry/failure según el resultado del executor.
     */
    suspend fun run(worker: CoroutineWorker): ListenableWorker.Result {
        val workType = worker.inputData.getString(KEY_WORK_TYPE)
            ?: return ListenableWorker.Result.failure()

        val additionalContext = coroutineContextFactory?.create(workType) ?: EmptyCoroutineContext
        return withContext(additionalContext) {
            run(worker, workType)
        }
    }

    private suspend fun run(worker: CoroutineWorker, workType: String): ListenableWorker.Result {
        // Extract and validate work ID
        val workId = parseWorkId(worker.inputData) ?: return ListenableWorker.Result.failure()

        // Create executor for this work type
        val executor = executorFactory.create(workType, workId) ?: return ListenableWorker.Result.failure()

        // Get notification provider (optional)
        val notificationProvider = notificationFactory.create(workType)

        // Track latest progress and channel IDs for notifications
        var latestProgress: WorkProgressData? = null
        var inProgressChannelId: String? = null
        var completionChannelId: String? = null

        // Setup notification if available and launch progress collection in parallel
        val progressJob = if (notificationProvider != null) {
            inProgressChannelId = notificationProvider.getChannelId()
            completionChannelId = notificationProvider.getCompletionChannelId()

            // Only setup notifications if channel ID is provided
            if (inProgressChannelId != null) {
                // Create a scope for progress collection
                val progressScope = CoroutineScope(currentCoroutineContext() + SupervisorJob())

                // Subscribe to work progress updates in parallel with work execution
                // The first progress emission will set the worker as foreground
                progressScope.launch {
                    executor.progressFlow
                        .filterNotNull()
                        .onEach { progress ->
                            latestProgress = progress

                            val content = notificationProvider.getNotification(progress)
                            setForegroundNotification(worker, workId, inProgressChannelId, content)
                        }
                        .catch { error ->
                            // Log flow errors
                            // The work continues even if notification updates fail
                        }
                        .collect()
                }
            } else {
                null
            }
        } else {
            null
        }

        return try {
            // Execute work and map result
            val result = executor.doWork()

            // Cancel progress collection as work is done
            progressJob?.cancel()

            // Show completion notification if applicable
            if (notificationProvider != null && latestProgress != null) {
                // Use completion channel ID if available, otherwise fall back to in-progress channel ID
                val channelId = completionChannelId ?: inProgressChannelId
                if (channelId != null) {
                    val status = when (result) {
                        is WorkResult.Success -> WorkCompletionStatus.Success
                        is WorkResult.Failure -> {
                            if (result.shouldRetry) WorkCompletionStatus.Retrying
                            else WorkCompletionStatus.Failed
                        }
                        is WorkResult.Interrupted -> WorkCompletionStatus.Failed
                    }
                    val completionContent = notificationProvider.getCompletedNotification(latestProgress, status)
                    showCompletionNotification(worker, workId, channelId, completionContent)
                }
            }

            when (result) {
                is WorkResult.Success -> {
                    ListenableWorker.Result.success()
                }
                is WorkResult.Failure -> {
                    if (result.shouldRetry) {
                        ListenableWorker.Result.retry()
                    } else {
                        ListenableWorker.Result.failure()
                    }
                }
                is WorkResult.Interrupted -> {
                    // Graceful stop - work was paused or cancelled by user
                    // Consider this a success since work state is saved
                    ListenableWorker.Result.success()
                }
            }
        } catch (_: Exception) {
            ListenableWorker.Result.retry()
        }
    }

    /**
     * Parses work ID from input data.
     *
     * @return UUID if parsing is successful, null otherwise
     */
    private fun parseWorkId(inputData: Data): Uuid? {
        val workIdString = inputData.getString(KEY_WORK_ID) ?: return null
        return try {
            Uuid.parse(workIdString)
        } catch (_: IllegalArgumentException) {
            null
        }
    }

    /**
     * Checks if notification permission is granted.
     *
     * On Android 13+ (TIRAMISU), POST_NOTIFICATIONS permission is required.
     * On earlier versions, notifications are always allowed.
     */
    private fun hasNotificationPermission(): Boolean {
        val permission = Permission.Notifications
        return !permission.isRelevantForCurrentSdk || permissionChecker.isGranted(permission)
    }

    /**
     * Sets or updates the foreground notification with current work progress.
     *
     * This should be called for every progress update, including the first one.
     * WorkManager requires calling setForegroundAsync for each notification update.
     *
     * Note: The notification channel should already be created at app startup.
     * Note: Skips setting foreground if notification permission is not granted.
     */
    private fun setForegroundNotification(
        worker: CoroutineWorker,
        workId: Uuid,
        channelId: String,
        content: NotificationContent
    ) {
        if (!hasNotificationPermission()) return

        val builder = NotificationCompat.Builder(worker.applicationContext, channelId)
            .setSmallIcon(content.iconResId)
            .setContentTitle(content.title)
            .setContentText(content.text)
            .setContentIntent(content.contentIntent)
            .setOngoing(true)

        // Add progress bar if progress information is available
        content.progress?.let { progress ->
            builder.setProgress(
                progress.total,
                progress.current,
                progress.indeterminate
            )
        }

        val notification = builder.build()

        val foregroundInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ForegroundInfo(WorkNotificationId.inProgress(workId), notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else
            ForegroundInfo(WorkNotificationId.inProgress(workId), notification)

        worker.setForegroundAsync(foregroundInfo)
    }

    /**
     * Shows completion notification.
     *
     * Note: The notification channel should already be created at app startup.
     * Note: Skips showing notification if notification permission is not granted.
     */
    private fun showCompletionNotification(
        worker: CoroutineWorker,
        workId: Uuid,
        channelId: String,
        content: NotificationContent
    ) {
        if (!hasNotificationPermission()) return

        val notification = NotificationCompat.Builder(worker.applicationContext, channelId)
            .setSmallIcon(content.iconResId)
            .setContentTitle(content.title)
            .setContentText(content.text)
            .setContentIntent(content.contentIntent)
            .setOngoing(false) // Not ongoing anymore
            .setAutoCancel(true)
            .build()

        val notificationManager = worker.applicationContext
            .getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(WorkNotificationId.completed(workId), notification)
    }

}
