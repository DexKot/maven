package dev.dexkot.mobile.core.work.data.coroutine

import dev.dexkot.mobile.core.work.domain.executor.model.WorkStatus
import dev.dexkot.mobile.core.work.domain.usecase.IObserveWorkStatusUseCase
import kotlinx.coroutines.flow.Flow
import kotlin.uuid.Uuid

/**
 * Implementación in-process de [IObserveWorkStatusUseCase] sobre [CoroutineWorkEngine].
 *
 * Emite el status en memoria del work. `null` si no está en el registro (nunca se schedulo en este
 * proceso o se perdió tras un reinicio). A diferencia del backend WorkManager, nunca emite
 * [WorkStatus.Blocked]: no hay gating de constraints por el OS.
 */
class CoroutineObserveWorkStatusUseCase(
    private val engine: CoroutineWorkEngine
) : IObserveWorkStatusUseCase {

    override operator fun invoke(
        workType: String,
        workId: Uuid
    ): Flow<WorkStatus?> = engine.observe(workId)

}
