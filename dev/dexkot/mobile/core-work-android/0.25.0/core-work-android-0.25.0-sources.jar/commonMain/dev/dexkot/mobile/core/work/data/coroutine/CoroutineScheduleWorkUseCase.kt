package dev.dexkot.mobile.core.work.data.coroutine

import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.work.domain.error.UnsupportedWorkType
import dev.dexkot.mobile.core.work.domain.executor.IWorkExecutorFactory
import dev.dexkot.mobile.core.work.domain.usecase.IScheduleWorkUseCase
import dev.dexkot.mobile.core.work.domain.worker.WorkerCoroutineContextFactory
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.uuid.Uuid

/**
 * Implementación in-process de [IScheduleWorkUseCase] sobre [CoroutineWorkEngine].
 *
 * Crea el executor vía [executorFactory] (Failure con [UnsupportedWorkType] si el tipo no está
 * registrado) y lo lanza en el motor. Devuelve el mismo `workId` como id del request: a diferencia
 * de WorkManager, acá no hay un id de request separado.
 */
class CoroutineScheduleWorkUseCase(
    private val engine: CoroutineWorkEngine,
    private val executorFactory: IWorkExecutorFactory,
    private val contextFactory: WorkerCoroutineContextFactory? = null
) : IScheduleWorkUseCase {

    override suspend operator fun invoke(
        workType: String,
        workId: Uuid
    ): ResultOf<Uuid> {
        val executor = executorFactory.create(workType, workId)
            ?: return ResultOf.Failure(UnsupportedWorkType(workType))

        val context = contextFactory?.create(workType) ?: EmptyCoroutineContext
        engine.schedule(workId = workId, executor = executor, context = context)

        return ResultOf.Success(workId)
    }

}
