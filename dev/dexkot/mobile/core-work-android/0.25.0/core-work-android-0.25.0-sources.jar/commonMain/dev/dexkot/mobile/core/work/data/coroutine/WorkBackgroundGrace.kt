package dev.dexkot.mobile.core.work.data.coroutine

/**
 * Da a un bloque de trabajo una ventana de gracia para terminar cuando la app pasa a background.
 *
 * En Android es un no-op (el work corre en su propio worker/proceso vía WorkManager). En iOS el
 * actual usa `beginBackgroundTask`/`endBackgroundTask` de `UIApplication` para pedir al OS unos
 * segundos extra y no cortar una síntesis a la mitad.
 *
 * El default [NoOpWorkBackgroundGrace] ejecuta el bloque sin pedir ninguna ventana.
 */
interface WorkBackgroundGrace {

    suspend fun <T> withGrace(block: suspend () -> T): T

}

/**
 * Ejecuta el bloque sin pedir ventana de background. Default multiplataforma (y comportamiento
 * correcto en Android).
 */
object NoOpWorkBackgroundGrace : WorkBackgroundGrace {

    override suspend fun <T> withGrace(block: suspend () -> T): T = block()

}
