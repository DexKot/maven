package dev.dexkot.mobile.core.work.data.coroutine

import dev.dexkot.mobile.core.work.domain.executor.IWorkExecutor
import dev.dexkot.mobile.core.work.domain.executor.model.WorkResult
import dev.dexkot.mobile.core.work.domain.executor.model.WorkStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.uuid.Uuid

/**
 * Motor de ejecución de work **en-proceso**, basado en corrutinas.
 *
 * Es el backend multiplataforma del contrato de work (schedule/observe/cancel): no usa WorkManager
 * ni BGTaskScheduler. Cada work corre como una corrutina en [scope] (típicamente un scope de app),
 * y el status se mantiene en memoria en un `StateFlow` por `workId`.
 *
 * **Durabilidad:** este motor NO persiste nada. El estado durable es responsabilidad del executor
 * (p.ej. su cola en DB). Tras un reinicio, el registro en memoria arranca vacío y la app debe
 * re-schedular los works incompletos leyéndolos de su fuente durable; el executor debe tolerar la
 * re-entrada (saltear el trabajo ya hecho).
 *
 * @property scope scope de app donde corren los works (cancelarlo cancela todos).
 * @property grace ventana de gracia al pasar a background (no-op por defecto; iOS: beginBackgroundTask).
 */
class CoroutineWorkEngine(
    private val scope: CoroutineScope,
    private val grace: WorkBackgroundGrace = NoOpWorkBackgroundGrace
) {

    private data class Entry(val status: WorkStatus, val job: Job?)

    private val registry = MutableStateFlow<Map<Uuid, Entry>>(emptyMap())

    /**
     * Lanza [executor] para [workId]. Idempotente por reemplazo: si había un work activo con ese id,
     * se cancela y se reemplaza.
     */
    fun schedule(
        workId: Uuid,
        executor: IWorkExecutor,
        context: CoroutineContext = EmptyCoroutineContext
    ) {
        registry.value[workId]?.job?.cancel()

        // Sembrar el estado antes de lanzar, así un observador ve Queued aunque el dispatcher
        // todavía no haya corrido el cuerpo.
        registry.update { it + (workId to Entry(WorkStatus.Queued, null)) }

        val job = scope.launch(context) {
            setStatus(workId, WorkStatus.Running)
            try {
                val result = grace.withGrace { executor.doWork() }
                setStatus(
                    workId,
                    when (result) {
                        WorkResult.Success -> WorkStatus.Completed
                        is WorkResult.Failure -> WorkStatus.Failed
                        WorkResult.Interrupted -> WorkStatus.Cancelled
                    }
                )
            } catch (cancellation: CancellationException) {
                setStatus(workId, WorkStatus.Cancelled)
                throw cancellation
            } catch (error: Throwable) {
                setStatus(workId, WorkStatus.Failed)
            }
        }

        // Adjuntar el Job preservando el status actual (el cuerpo pudo ya haberlo avanzado).
        registry.update { current ->
            current[workId]?.let { current + (workId to it.copy(job = job)) } ?: current
        }
    }

    /** Flujo del status de [workId]; `null` si nunca se schedulo en este proceso (o se perdió tras reinicio). */
    fun observe(workId: Uuid): Flow<WorkStatus?> =
        registry
            .map { it[workId]?.status }
            .distinctUntilChanged()

    /** Cancela el work [workId] si está activo. No-op si ya terminó o no existe. */
    fun cancel(workId: Uuid) {
        registry.value[workId]?.job?.cancel()
    }

    private fun setStatus(workId: Uuid, status: WorkStatus) {
        registry.update { current ->
            val entry = current[workId]
            current + (workId to (entry?.copy(status = status) ?: Entry(status, null)))
        }
    }

}
