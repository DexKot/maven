package dev.dexkot.mobile.core.work.data.coroutine

import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.work.domain.usecase.ICancelWorkUseCase
import kotlin.uuid.Uuid

/**
 * Implementación in-process de [ICancelWorkUseCase] sobre [CoroutineWorkEngine].
 *
 * Cancela la corrutina del work. Si ya terminó o no existe, es no-op (Success igual).
 */
class CoroutineCancelWorkUseCase(
    private val engine: CoroutineWorkEngine
) : ICancelWorkUseCase {

    override operator fun invoke(
        workType: String,
        workId: Uuid
    ): ResultOf<Unit> {
        engine.cancel(workId)
        return ResultOf.Success(Unit)
    }

}
