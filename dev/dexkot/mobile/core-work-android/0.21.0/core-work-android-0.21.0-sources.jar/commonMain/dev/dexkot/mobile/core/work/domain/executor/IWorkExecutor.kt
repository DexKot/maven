package dev.dexkot.mobile.core.work.domain.executor

import dev.dexkot.mobile.core.work.domain.executor.model.WorkResult
import dev.dexkot.mobile.core.work.domain.executor.model.WorkProgressData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow

/**
 * Executes a specific instance of background work.
 *
 * Each work instance gets its own executor instance.
 * The executor is constructed with the work ID and is responsible for:
 * - Fetching work data from repository
 * - Executing work steps
 * - Updating progress in repository
 * - Handling interruptions (pause/cancel)
 * - Saving intermediate state for resume support
 * - Emitting work progress through the progressFlow
 *
 * Example:
 * ```
 * class ScanWorkExecutor(
 *     private val workId: Uuid,
 *     private val repository: IScanWorkRepository,
 *     private val recognizeText: IRecognizeTextUseCase
 * ) : IWorkExecutor {
 *
 *     private val _progressFlow = MutableStateFlow(
 *         WorkProgressData(
 *             workType = ScanPdfWork.TYPE,
 *             workId = workId,
 *             current = 0,
 *             total = 0
 *         )
 *     )
 *     override val progressFlow: Flow<WorkProgressData> = _progressFlow
 *
 *     override suspend fun doWork(): WorkResult {
 *         val work = repository.get(workId)
 *
 *         // Emit initial progress
 *         _progressFlow.value = _progressFlow.value.copy(
 *             total = work.totalPages,
 *             metadata = mapOf("uri" to work.uri.toString())
 *         )
 *
 *         // Execute work and emit progress updates
 *         work.pages.forEachIndexed { index, page ->
 *             _progressFlow.value = _progressFlow.value.copy(current = index + 1)
 *             // Process page...
 *         }
 *     }
 * }
 * ```
 */
interface IWorkExecutor {

    /**
     * Flow that emits work progress updates during execution.
     *
     * This flow should emit:
     * - Initial progress when execution starts
     * - Progress updates as work progresses
     * - Final progress before completion
     *
     * The emitted progress data is used by notification handlers to display progress.
     *
     * Opcional: por defecto no emite progreso ([emptyFlow]). Solo overrideá esto si tu work
     * muestra progreso (notificación con barra). Para jobs simples/silenciosos, ignoralo.
     */
    val progressFlow: Flow<WorkProgressData?> get() = emptyFlow()

    /**
     * Starts executing the work.
     *
     * This method should:
     * - Fetch work data from repository using the work ID provided in constructor
     * - Execute work steps
     * - Update progress in repository periodically
     * - Emit progress updates through progressFlow
     * - Check for interruptions
     * - Save intermediate state for resume support
     *
     * @return WorkResult indicating outcome (Success, Failure, or Interrupted)
     *
     * Para frenar/limpiar al cancelar, usá cancelación cooperativa de corrutinas: cuando WorkManager
     * frena el work, esta corrutina se cancela y podés limpiar en un `finally`. No hay un método
     * `interrupt()` separado (era redundante con la cancelación).
     */
    suspend fun doWork(): WorkResult

}
