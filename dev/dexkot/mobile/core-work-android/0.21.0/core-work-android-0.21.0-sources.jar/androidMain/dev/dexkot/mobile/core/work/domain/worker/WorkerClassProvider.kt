package dev.dexkot.mobile.core.work.domain.worker

import androidx.work.ListenableWorker

/**
 * Provee la clase concreta del worker que la app registra en WorkManager.
 *
 * El worker es **app-owned** (su FQN se persiste en la DB de WorkManager, así que su identidad
 * pertenece a la app). DexKot es dueño de la lógica de scheduling ([ScheduleWorkUseCase]), pero
 * necesita saber qué clase encolar — la app la aporta implementando esta interfaz:
 *
 * ```kotlin
 * single<WorkerClassProvider> { WorkerClassProvider { MyWorker::class.java } }
 * ```
 */
fun interface WorkerClassProvider {
    fun workerClass(): Class<out ListenableWorker>
}
