package dev.dexkot.mobile.core.work.data.notification

import dev.dexkot.mobile.core.work.domain.notification.IWorkNotificationFactory
import dev.dexkot.mobile.core.work.domain.notification.IWorkNotificationProvider

/**
 * Factory that retrieves work notification providers by work type.
 *
 * This factory maintains a map of work type identifiers to their corresponding
 * providers. The app module or feature modules can register [IWorkNotificationProvider]
 * instances that handle notifications for specific work types.
 *
 * This design avoids circular dependency issues that would occur if the factory
 * itself was collected via getAll().
 *
 * Example usage with Koin:
 * ```
 * // In app module or feature modules:
 * val appModule = module {
 *     factory<IWorkNotificationProvider> {
 *         ScanWorkNotificationProvider(
 *             context = androidContext()
 *         )
 *     }
 * }
 *
 * // In core:work module:
 * val workModule = module {
 *     // Factory automatically collects all registered providers
 *     single<IWorkNotificationFactory> {
 *         WorkNotificationFactory(
 *             providers = getAll<IWorkNotificationProvider>()
 *         )
 *     }
 * }
 * ```
 *
 * @property providers List of work notification providers from app/feature modules
 */
class WorkNotificationFactory(
    providers: List<IWorkNotificationProvider>
) : IWorkNotificationFactory {

    /**
     * Map of work type to provider for efficient lookup.
     */
    private val providerMap: Map<String, IWorkNotificationProvider> = providers.associateBy { it.workType }

    /**
     * Retrieves the notification provider for the specified work type.
     *
     * Looks up the provider for the given work type.
     * If no provider is registered for the work type, returns null (no notifications).
     *
     * @param workType The work type identifier (e.g., "scan_pdf", "export_pdf")
     * @return Notification provider instance, or null if workType is not supported
     */
    override fun create(workType: String): IWorkNotificationProvider? {
        return providerMap[workType]
    }
}