package dev.dexkot.mobile.core.work.domain.executor.model

import androidx.work.WorkInfo

/**
 * Maps WorkInfo.State to WorkStatus.
 *
 * @return Corresponding WorkStatus for this WorkInfo.State
 */
internal fun WorkInfo.State.toWorkStatus(
    constraintsMet: Boolean
): WorkStatus {
    return when (this) {
        WorkInfo.State.ENQUEUED,
        WorkInfo.State.BLOCKED -> {
            when (constraintsMet) {
                true -> WorkStatus.Queued
                false -> WorkStatus.Blocked
            }
        }
        WorkInfo.State.RUNNING -> WorkStatus.Running
        WorkInfo.State.SUCCEEDED -> WorkStatus.Completed
        WorkInfo.State.FAILED -> WorkStatus.Failed
        WorkInfo.State.CANCELLED -> WorkStatus.Cancelled
    }
}