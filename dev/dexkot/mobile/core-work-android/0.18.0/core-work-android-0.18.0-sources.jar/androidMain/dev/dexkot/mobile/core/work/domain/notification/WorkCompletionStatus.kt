package dev.dexkot.mobile.core.work.domain.notification

/**
 * Represents the completion status of a work when generating completion notifications.
 *
 * This distinguishes between a permanent failure and a temporary failure that will be retried,
 * allowing notification providers to show appropriate messages for each scenario.
 */
enum class WorkCompletionStatus {
    /**
     * Work completed successfully.
     */
    Success,

    /**
     * Work failed permanently and will not be retried.
     */
    Failed,

    /**
     * Work failed temporarily and has been scheduled for retry.
     */
    Retrying
}
