package dev.dexkot.mobile.core.work.domain.constraint

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.PowerManager
import dev.dexkot.mobile.core.work.domain.config.model.WorkTypeConfig
import dev.dexkot.mobile.core.work.domain.config.model.network.NetworkRequirement

/**
 * Checks if WorkManager constraints are currently met.
 *
 * This class replicates the constraint checking logic used internally by WorkManager
 * to determine if work can execute. It checks system conditions like network connectivity,
 * battery level, charging status, storage availability, and device idle state.
 *
 * Note: This is an approximation of WorkManager's internal logic and may not be 100%
 * accurate in all edge cases, but should be sufficient for UI state determination.
 *
 * @param context Application context for accessing system services
 */
class ConstraintChecker(
    private val context: Context
) {

    /**
     * Checks if all constraints defined in the work configuration are currently met.
     *
     * @param config The work type configuration containing constraint definitions
     * @return true if all constraints are met, false otherwise
     */
    fun areConstraintsMet(config: WorkTypeConfig): Boolean {
        return isNetworkConstraintMet(config.networkRequirement) &&
               (!config.requiresBatteryNotLow || isBatteryNotLow()) &&
               (!config.requiresCharging || isCharging()) &&
               (!config.requiresStorageNotLow || isStorageNotLow()) &&
               (!config.requiresDeviceIdle || isDeviceIdle())
    }

    /**
     * Checks if the network constraint is met.
     *
     * @param requirement The network requirement to check
     * @return true if the network requirement is satisfied
     */
    private fun isNetworkConstraintMet(requirement: NetworkRequirement): Boolean {
        return when (requirement) {
            NetworkRequirement.NONE -> true
            NetworkRequirement.CONNECTED -> isNetworkConnected()
            NetworkRequirement.UNMETERED -> isNetworkUnmetered()
        }
    }

    /**
     * Checks if any network is connected and has internet capability.
     *
     * @return true if a network connection is available
     */
    private fun isNetworkConnected(): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false

        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    /**
     * Checks if an unmetered network (typically WiFi or Ethernet) is available.
     *
     * @return true if an unmetered network connection is available
     */
    private fun isNetworkUnmetered(): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false

        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) &&
               capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    /**
     * Checks if battery is not in low state.
     *
     * WorkManager considers battery low when the device enters low battery mode,
     * which typically happens around 15% battery level.
     *
     * @return true if battery is not low
     */
    private fun isBatteryNotLow(): Boolean {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return true // If we can't determine, assume constraint is met

        val batteryLow = batteryIntent.getBooleanExtra(BatteryManager.EXTRA_BATTERY_LOW, false)
        return !batteryLow
    }

    /**
     * Checks if device is currently charging.
     *
     * @return true if device is charging or fully charged
     */
    private fun isCharging(): Boolean {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return false

        val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return status == BatteryManager.BATTERY_STATUS_CHARGING ||
               status == BatteryManager.BATTERY_STATUS_FULL
    }

    /**
     * Checks if storage is not low.
     *
     * WorkManager uses the system's low storage broadcast to determine this.
     * If we can register for the broadcast without getting an existing intent,
     * it means storage is not currently low.
     *
     * @return true if storage is not low
     */
    @Suppress("DEPRECATION")
    private fun isStorageNotLow(): Boolean {
        // Check if the low storage intent is currently active
        val storageIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_DEVICE_STORAGE_LOW))
        // If the intent is null, storage is not low. If not null, storage is low.
        return storageIntent == null
    }

    /**
     * Checks if device is in idle (Doze) mode.
     *
     * This constraint is only applicable on API 23+.
     * On older versions, this always returns true (constraint met).
     *
     * @return true if device is idle (or API < 23)
     */
    private fun isDeviceIdle(): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return powerManager.isDeviceIdleMode
    }

}
