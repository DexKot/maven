package dev.dexkot.mobile.core.work.domain.work

import android.os.Parcelable
import kotlin.uuid.Uuid

/**
 * Represents background work as PURE DATA.
 * Contains ONLY state and metadata - NO execution logic.
 *
 * Each feature module defines its own Work implementation.
 *
 * Examples:
 * - ScanWork (in :scanner module)
 * - AudioGenerationWork (in :media module)
 * - PdfExportWork (in :publisher module)
 *
 * Note: Work status and progress are tracked by WorkManager at runtime, not persisted here.
 */
interface IWork : Parcelable {

    /**
     * Unique identifier for this work instance.
     */
    val id: Uuid

    /**
     * Work type identifier.
     * Used to identify the work type.
     *
     * Examples: "scan_work", "audio_generation", "pdf_export"
     */
    val type: String

}
