package dev.dexkot.mobile.core.work.domain.usecase

import android.app.NotificationManager
import android.content.Context
import androidx.work.WorkManager
import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.work.domain.notification.WorkNotificationId
import dev.dexkot.mobile.core.work.domain.work.workTag
import kotlin.uuid.Uuid

/**
 * Implementation of [ICancelWorkUseCase].
 *
 * This use case:
 * 1. Constructs the work tag from workType and workId
 * 2. Cancels all work with that tag in WorkManager
 * 3. Dismisses any completion notifications for the cancelled work
 *
 * @property context Android context for accessing NotificationManager
 * @property workManager Android WorkManager instance
 */
internal class CancelWorkUseCase(
    private val context: Context,
    private val workManager: WorkManager
) : ICancelWorkUseCase {

    /**
     * Cancels scheduled or running work and dismisses any completion notifications.
     *
     * Uses the unique work tag (workType_workId) to identify and cancel the work.
     * This ensures we only cancel the specific work instance.
     * Also dismisses the completion notification if it was shown.
     *
     * @param workType The type of work to cancel
     * @param workId The unique identifier for this work instance
     * @return Success always - WorkManager and NotificationManager operations don't throw
     */
    override operator fun invoke(
        workType: String,
        workId: Uuid
    ): ResultOf<Unit> {
        // Get the unique work tag
        val tag = workTag(workType, workId)

        // Cancel all work with this tag (should only be one instance)
        workManager.cancelAllWorkByTag(tag)

        // Dismiss completion notification if any
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(WorkNotificationId.completed(workId))

        return ResultOf.Success(Unit)
    }

}
