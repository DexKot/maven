package dev.dexkot.mobile.core.work.domain.usecase

import androidx.work.Constraints
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkRequest
import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.work.data.worker.GenericWorkManagerWorker
import dev.dexkot.mobile.core.work.data.worker.GenericWorkManagerWorker.Companion.createInputData
import dev.dexkot.mobile.core.work.domain.config.IWorkTypeConfigFactory
import dev.dexkot.mobile.core.work.domain.config.model.backoff.toWorkManagerBackoffPolicy
import dev.dexkot.mobile.core.work.domain.config.model.network.toNetworkType
import dev.dexkot.mobile.core.work.domain.error.UnsupportedWorkType
import dev.dexkot.mobile.core.work.domain.error.WorkEnqueueFailed
import dev.dexkot.mobile.core.work.domain.work.workIdTag
import dev.dexkot.mobile.core.work.domain.work.workTag
import dev.dexkot.mobile.core.work.domain.work.workTypeTag
import kotlin.uuid.Uuid
import kotlin.uuid.toKotlinUuid
import java.util.concurrent.TimeUnit

/**
 * Implementation of [IScheduleWorkUseCase].
 *
 * This use case:
 * 1. Gets configuration for the work type
 * 2. Converts framework-agnostic config to WorkManager constraints
 * 3. Creates and enqueues a WorkRequest
 *
 * @property workManager Android WorkManager instance
 * @property configProvider Provider for work type configurations
 */
internal class ScheduleWorkUseCase(
    private val workManager: WorkManager,
    private val configProvider: IWorkTypeConfigFactory
) : IScheduleWorkUseCase {

    /**
     * Schedules work for execution.
     *
     * Automatically tags the work with:
     * - Work type tag (e.g., "scan_pdf")
     * - Work instance tag (e.g., "work_123e4567-e89b-12d3-a456-426614174000")
     *
     * These tags can be used later to query WorkManager for the status of this specific work.
     *
     * This suspend function waits for the work to be successfully enqueued before returning.
     *
     * @param workType The type of work to schedule
     * @param workId The unique identifier for this work instance
     * @return Success with WorkRequest UUID if enqueued, or Failure if work type not supported or enqueue fails
     */
    override suspend operator fun invoke(
        workType: String,
        workId: Uuid
    ): ResultOf<Uuid> {

        // Get configuration for work type
        val config = configProvider.getConfig(workType) ?: return ResultOf.Failure(UnsupportedWorkType(workType))

        // Build constraints from framework-agnostic config
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(config.networkRequirement.toNetworkType())
            .setRequiresBatteryNotLow(config.requiresBatteryNotLow)
            .setRequiresCharging(config.requiresCharging)
            .setRequiresStorageNotLow(config.requiresStorageNotLow)
            .setRequiresDeviceIdle(config.requiresDeviceIdle)
            .build()

        // Create internal tags for this work
        // Tag 1: Work type (e.g., "scan_pdf") - allows querying all works of this type
        // Tag 2: Work ID (e.g., "workId_<uuid>") - allows querying by work ID
        // Tag 3: Work instance (e.g., "scan_pdf_<workId>") - unique tag for this specific work instance
        val workTypeTag = workTypeTag(workType)
        val workIdTag = workIdTag(workId)
        val workInstanceTag = workTag(workType, workId)

        // Create work request
        val request = OneTimeWorkRequestBuilder<GenericWorkManagerWorker>()
            .setInputData(
                createInputData(
                    workType = workType,
                    workId = workId
                )
            )
            .setConstraints(constraints)
            .setBackoffCriteria(
                config.backoffPolicy.toWorkManagerBackoffPolicy(),
                WorkRequest.MIN_BACKOFF_MILLIS,
                TimeUnit.MILLISECONDS
            )
            .addTag(workTypeTag)
            .addTag(workIdTag)
            .addTag(workInstanceTag)
            .build()

        // Enqueue work and wait for it to complete
        return try {
            val operation = workManager.enqueue(request)
            operation.result.get()
            ResultOf.Success(request.id.toKotlinUuid())
        } catch (e: Exception) {
            ResultOf.Failure(WorkEnqueueFailed(workType = workType, cause = e))
        }
    }

}
