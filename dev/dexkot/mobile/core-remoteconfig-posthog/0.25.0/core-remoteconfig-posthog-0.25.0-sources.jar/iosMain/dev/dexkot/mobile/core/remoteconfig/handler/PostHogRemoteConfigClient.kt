package dev.dexkot.mobile.core.remoteconfig.handler

import cocoapods.PostHog.PostHogSDK
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import platform.Foundation.NSJSONSerialization
import platform.Foundation.NSString
import platform.Foundation.NSUTF8StringEncoding
import platform.Foundation.create
import kotlin.coroutines.resume

@OptIn(ExperimentalForeignApi::class)
internal actual class PostHogRemoteConfigClient actual constructor() {

    private val postHog: PostHogSDK = PostHogSDK.shared()

    actual suspend fun reloadFeatureFlags(timeoutMillis: Long) {
        withTimeout(timeoutMillis) {
            suspendCancellableCoroutine { continuation ->
                postHog.reloadFeatureFlagsWithCallback {
                    continuation.resume(Unit)
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    actual fun featureFlagPayloadString(key: String): String? {
        val payload = postHog.getFeatureFlagPayload(key) ?: return null
        return payload.toConfigString()
    }

    private fun Any.toConfigString(): String = when (this) {
        is String -> this
        else -> jsonString() ?: toString()
    }

    // Structured payloads (dictionaries/arrays) are serialised back to JSON so the common handler
    // can deserialise them; scalars fall through to their string form.
    private fun Any.jsonString(): String? {
        if (!NSJSONSerialization.isValidJSONObject(this)) return null
        val data = NSJSONSerialization.dataWithJSONObject(this, 0u, null) ?: return null
        return NSString.create(data, NSUTF8StringEncoding) as String?
    }
}
