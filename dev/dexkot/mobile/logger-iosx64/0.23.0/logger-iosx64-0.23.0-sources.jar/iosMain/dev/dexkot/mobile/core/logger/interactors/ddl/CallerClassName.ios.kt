package dev.dexkot.mobile.core.logger.interactors.ddl

// Kotlin/Native does not expose a class-name stack trace the way the JVM does, so the tag falls back
// to the source component alone (see LoggerInteractor.getCallerTag).
internal actual fun currentCallerClassName(): String? = null
