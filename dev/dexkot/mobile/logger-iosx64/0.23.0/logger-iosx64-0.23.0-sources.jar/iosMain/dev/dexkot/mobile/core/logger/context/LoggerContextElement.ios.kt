package dev.dexkot.mobile.core.logger.context

import dev.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor
import kotlin.coroutines.CoroutineContext

/**
 * Native has no `ThreadContextElement`, so this is a plain context element: it still travels with the
 * coroutine context (readable from suspend code via `coroutineContext[Key]`), but [current] cannot
 * mirror it to the running thread and falls back to the default set via [setDefault].
 */
actual class LoggerContextElement actual constructor(
    val loggerInteractor: ILoggerInteractor,
) : CoroutineContext.Element {

    actual override val key: CoroutineContext.Key<*> get() = Key

    actual companion object Key : CoroutineContext.Key<LoggerContextElement> {
        private var defaultLogger: ILoggerInteractor? = null

        actual fun current(): ILoggerInteractor? = defaultLogger

        actual fun setDefault(logger: ILoggerInteractor) {
            defaultLogger = logger
        }
    }
}
