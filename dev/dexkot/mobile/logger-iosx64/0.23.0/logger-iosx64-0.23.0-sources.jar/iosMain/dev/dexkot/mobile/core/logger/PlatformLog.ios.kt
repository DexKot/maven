package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.levels.Level
import platform.Foundation.NSLog

internal actual fun platformLog(level: Level, tag: String, message: String) {
    NSLog("[${level.name.uppercase()}] $tag: $message")
}

internal actual fun platformLog(tag: String, message: String, throwable: Throwable) {
    NSLog("[ERROR] $tag: $message\n${throwable.stackTraceToString()}")
}
