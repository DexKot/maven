package dev.dexkot.mobile.core.logger.interactors.ddl

/**
 * Best-effort simple name of the class that called into the logger, used to build the log tag.
 *
 * On the JVM it is read from the current thread's stack trace; on platforms without that kind of
 * stack introspection (Native) it returns null and the tag falls back to just the source component.
 */
internal expect fun currentCallerClassName(): String?
