package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import dev.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import dev.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import dev.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import dev.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import dev.dexkot.mobile.core.logger.events.ui.state.UiStateEvent
import dev.dexkot.mobile.core.logger.levels.Level

class ConsoleLogger(
    private val tag: String
) : ILogger {

    override fun setUserId(identifier: String) {
        platformLog(Level.Info, tag, "User id: $identifier")
    }

    override fun setUserProperty(key: String, value: String?) {
        platformLog(Level.Info, tag, "User property: $key = $value")
    }

    override fun removeUserId() {
        platformLog(Level.Info, tag, "User id deleted")
    }

    override fun removeUserProperty(key: String) {
        platformLog(Level.Info, tag, "User property $key deleted")
    }

    override fun log(event: LogEvent) {
        when (event) {
            is InteractionEvent -> platformLog(
                Level.Info,
                tag,
                "[${event.sourceComponent}] ${event.interaction.value}: ${event.elementId}" +
                    event.extras.ifNotEmpty { " $it" },
            )
            is ScreenEvent -> platformLog(
                Level.Info,
                tag,
                "[${event.sourceComponent}] screen: ${event.action.value}",
            )
            is NavigationEvent -> platformLog(
                Level.Info,
                tag,
                "[${event.sourceComponent}] navigation: ${event.navigationId}" +
                    event.params.ifNotEmpty { " $it" },
            )
            is OperationEvent -> platformLog(
                Level.Info,
                tag,
                "[${event.sourceComponent}] operation: ${event.operationId} [${event.status.value}]" +
                    event.params.ifNotEmpty { " $it" },
            )
            is PermissionEvent -> platformLog(
                Level.Info,
                tag,
                "[${event.sourceComponent}] permission: ${event.permissions.map { "${it.key}=${it.value.value}" }}",
            )
            is IntentionEvent -> platformLog(
                Level.Info,
                tag,
                "[${event.sourceComponent}] intention: ${event.intentionId}" +
                    event.params.ifNotEmpty { " $it" },
            )
            is UiStateEvent -> platformLog(
                Level.Info,
                tag,
                "[${event.sourceComponent}] ${event.state.value}: ${event.elementId}" +
                    event.extras.ifNotEmpty { " $it" },
            )
        }
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        platformLog(level, tag, "$message${params.ifNotEmpty { " $it" }}")
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        platformLog(tag, "$message${params.ifNotEmpty { " $it" }}", throwable)
    }

    private fun <K, V> Map<K, V>.ifNotEmpty(transform: (Map<K, V>) -> String): String {
        return if (isNotEmpty()) transform(this) else ""
    }

}
