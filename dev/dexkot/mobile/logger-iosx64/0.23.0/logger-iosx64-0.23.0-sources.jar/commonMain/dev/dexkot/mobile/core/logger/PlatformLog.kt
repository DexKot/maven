package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.levels.Level

/**
 * Platform sink used by [ConsoleLogger]. Android routes to `android.util.Log`; other platforms print
 * to stdout. Only the sink is platform-specific — all message formatting stays in common code.
 */
internal expect fun platformLog(level: Level, tag: String, message: String)

internal expect fun platformLog(tag: String, message: String, throwable: Throwable)
