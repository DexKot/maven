package dev.dexkot.mobile.core.logger.interactors.ddl

import dev.dexkot.mobile.core.logger.ILogger
import dev.dexkot.mobile.core.logger.debug
import dev.dexkot.mobile.core.logger.error
import dev.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.Status
import dev.dexkot.mobile.core.logger.info
import dev.dexkot.mobile.core.logger.verbose
import dev.dexkot.mobile.core.logger.warning

class LoggerInteractor(
    private val logger: ILogger,
    private val sourceComponent: String
): ILoggerInteractor {

    override fun verbose(
        message: String,
        params: Map<String, Any>
    ) {
        logger.verbose(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun debug(
        message: String,
        params: Map<String, Any>
    ) {
        logger.debug(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun info(
        message: String,
        params: Map<String, Any>
    ) {
        logger.info(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun warning(
        message: String,
        params: Map<String, Any>
    ) {
        logger.warning(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun error(
        message: String,
        params: Map<String, Any>
    ) {
        logger.error(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun error(
        throwable: Throwable,
        message: String?,
        params: Map<String, Any>
    ) {
        logger.log(
            throwable = throwable,
            message = message,
            params = params
        )
    }

    override fun operation(
        operationId: String,
        result: Status,
        params: Map<String, String>,
        isBusinessEvent: Boolean,
    ) {
        logger.log(
            event = OperationEvent(
                sourceComponent = sourceComponent,
                operationId = operationId,
                status = result,
                params = params,
                isBusinessEvent = isBusinessEvent
            )
        )
    }

    /**
     * Builds the log tag from the calling class name when the platform can provide it, falling back
     * to just the source component otherwise (see [currentCallerClassName]).
     */
    private fun getCallerTag(): String {
        val caller = currentCallerClassName() ?: "Unknown"
        return "$sourceComponent/$caller"
    }

}
