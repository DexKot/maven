package dev.dexkot.mobile.core.logger.context

import dev.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor
import kotlin.coroutines.CoroutineContext

/**
 * Carries an [ILoggerInteractor] through a coroutine scope so that non-suspend code can reach it via
 * [current] (the `logger { }` DSL). Add it to a scope: `CoroutineScope(... + LoggerContextElement(x))`.
 *
 * Platform behaviour differs:
 * - **Android/JVM**: a `kotlinx.coroutines.ThreadContextElement` mirrors the interactor into a thread
 *   local on every resume, so [current] returns the scope's interactor from any thread it runs on.
 * - **iOS/Native**: `ThreadContextElement` is not available, so this is a plain context element and
 *   [current] falls back to the default set via [setDefault]. Per-scope resolution from non-suspend
 *   code is not available there.
 */
expect class LoggerContextElement(
    loggerInteractor: ILoggerInteractor
) : CoroutineContext.Element {

    override val key: CoroutineContext.Key<*>

    companion object Key : CoroutineContext.Key<LoggerContextElement> {

        fun current(): ILoggerInteractor?

        fun setDefault(logger: ILoggerInteractor)
    }
}
