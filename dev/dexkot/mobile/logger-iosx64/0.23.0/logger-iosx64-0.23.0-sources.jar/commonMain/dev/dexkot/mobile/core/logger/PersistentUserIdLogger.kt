package dev.dexkot.mobile.core.logger

import com.russhwolf.settings.Settings
import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.levels.Level

/**
 * Wraps [delegate] and persists the user id so it can be re-applied on the next app start.
 *
 * Storage is provided by the app through [settings]: the app owns the underlying store (its name,
 * suite, etc.), so the library never hardcodes it. On Android build it from a `SharedPreferences`,
 * on iOS from `NSUserDefaults`.
 */
class PersistentUserIdLogger(
    private val settings: Settings,
    private val delegate: ILogger
) : ILogger {

    init {
        settings.getStringOrNull(KEY_USER_ID)?.let { cachedUserId ->
            delegate.setUserId(cachedUserId)
        }
    }

    override fun setUserId(identifier: String) {
        settings.putString(KEY_USER_ID, identifier)
        delegate.setUserId(identifier)
    }

    override fun removeUserId() {
        settings.remove(KEY_USER_ID)
        delegate.removeUserId()
    }

    override fun setUserProperty(key: String, value: String?) {
        delegate.setUserProperty(key, value)
    }

    override fun removeUserProperty(key: String) {
        delegate.removeUserProperty(key)
    }

    override fun log(event: LogEvent) {
        delegate.log(event)
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        delegate.log(level, tag, message, params)
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        delegate.log(throwable, message, params)
    }

    private companion object {
        const val KEY_USER_ID = "user_id"
    }
}
