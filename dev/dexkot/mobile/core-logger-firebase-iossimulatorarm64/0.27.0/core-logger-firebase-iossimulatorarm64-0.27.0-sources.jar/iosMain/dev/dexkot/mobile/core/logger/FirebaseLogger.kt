package dev.dexkot.mobile.core.logger

import cocoapods.FirebaseAnalytics.FIRAnalytics
import cocoapods.FirebaseCrashlytics.FIRCrashlytics
import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.levels.Level
import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSError
import platform.Foundation.NSLocalizedDescriptionKey

@OptIn(ExperimentalForeignApi::class)
actual class FirebaseLogger actual constructor() : ILogger {

    private val crashlytics: FIRCrashlytics = FIRCrashlytics.crashlytics()

    actual override fun setUserId(identifier: String) {
        FIRAnalytics.setUserID(identifier)
        crashlytics.setUserID(identifier)
    }

    actual override fun removeUserId() {
        FIRAnalytics.setUserID(null)
        crashlytics.setUserID("")
    }

    actual override fun setUserProperty(key: String, value: String?) {
        FIRAnalytics.setUserPropertyString(value, key)
    }

    actual override fun removeUserProperty(key: String) {
        FIRAnalytics.setUserPropertyString(null, key)
    }

    actual override fun log(event: LogEvent) {
        @Suppress("UNCHECKED_CAST")
        FIRAnalytics.logEventWithName(event.type, event.firebaseParameters() as Map<Any?, *>)
    }

    actual override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) = Unit

    actual override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        message?.let { crashlytics.log(it) }
        params.forEach { (key, value) -> crashlytics.setCustomValue(value, key) }
        crashlytics.recordError(throwable.toNSError())
    }

    private fun Throwable.toNSError(): NSError = NSError.errorWithDomain(
        domain = this::class.qualifiedName ?: "KotlinException",
        code = 0,
        userInfo = mapOf<Any?, Any?>(
            NSLocalizedDescriptionKey to (message ?: toString())
        )
    )
}
