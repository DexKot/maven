package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import dev.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import dev.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import dev.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import dev.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import dev.dexkot.mobile.core.logger.events.ui.state.UiStateEvent

/**
 * Flattens a [LogEvent] into the string parameters logged to Firebase Analytics. Shared by the
 * Android (Bundle) and iOS (NSDictionary) backends so both report identical event data.
 */
internal fun LogEvent.firebaseParameters(): Map<String, String> = when (this) {
    is InteractionEvent -> buildMap {
        put("source", sourceComponent)
        put("element_id", elementId)
        put("interaction", interaction.value)
        extras.forEach { (key, value) -> put("extra_$key", value) }
    }
    is ScreenEvent -> buildMap {
        put("source", sourceComponent)
        put("action", action.value)
    }
    is NavigationEvent -> buildMap {
        put("source", sourceComponent)
        put("navigation_id", navigationId)
        params.forEach { (key, value) -> put("parameter_$key", value.toString()) }
    }
    is OperationEvent -> buildMap {
        put("source", sourceComponent)
        put("operation_id", operationId)
        put("status", status.value)
        params.forEach { (key, value) -> put("parameter_$key", value) }
    }
    is PermissionEvent -> buildMap {
        put("source", sourceComponent)
        permissions.forEach { (key, value) -> put("permission_$key", value.value) }
    }
    is IntentionEvent -> buildMap {
        put("source", sourceComponent)
        put("intention_id", intentionId)
        params.forEach { (key, value) -> put("parameter_$key", value) }
    }
    is UiStateEvent -> buildMap {
        put("source", sourceComponent)
        put("element_id", elementId)
        put("state", state.value)
        extras.forEach { (key, value) -> put("extra_$key", value) }
    }
    else -> parameters.mapValues { it.value.toString() }
}
