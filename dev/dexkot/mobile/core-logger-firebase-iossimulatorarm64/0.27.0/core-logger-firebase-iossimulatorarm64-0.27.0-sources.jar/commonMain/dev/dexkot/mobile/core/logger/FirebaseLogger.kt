package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.levels.Level

/**
 * [ILogger] backed by Firebase Analytics + Crashlytics.
 *
 * Each platform uses the native Firebase SDK directly (no cross-platform wrapper), reaching the
 * SDK singletons internally so the constructor takes no arguments. Because the constructor is common
 * (`()`), the type is referenceable from common code — e.g. a shared DI can do `FirebaseLogger()`.
 */
expect class FirebaseLogger() : ILogger {

    override fun setUserId(identifier: String)

    override fun setUserProperty(key: String, value: String?)

    override fun removeUserId()

    override fun removeUserProperty(key: String)

    override fun log(event: LogEvent)

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>)

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>)
}
