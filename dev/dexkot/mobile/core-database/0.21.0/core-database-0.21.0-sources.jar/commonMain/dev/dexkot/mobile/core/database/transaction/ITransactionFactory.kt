package dev.dexkot.mobile.core.database.transaction

import dev.dexkot.mobile.core.foundation.result.ResultOf

interface ITransactionFactory {

    suspend fun <Out> withTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out>

}
