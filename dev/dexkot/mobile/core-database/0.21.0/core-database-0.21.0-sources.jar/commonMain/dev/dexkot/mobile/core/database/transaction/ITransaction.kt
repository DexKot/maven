package dev.dexkot.mobile.core.database.transaction

import dev.dexkot.mobile.core.foundation.result.ResultOf

interface ITransaction<Output> {

    suspend fun <Out> execute(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out>

    suspend fun rollback(
        failure: ResultOf.Failure<*>
    ): Nothing

    suspend fun <Data> rollBackIfFailure(
        result: ResultOf<Data>
    ): Data {
        when (result) {
            is ResultOf.Failure -> rollback(result)
            is ResultOf.Success -> return result.data
        }
    }

    suspend fun <Out> innerTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out>

}
