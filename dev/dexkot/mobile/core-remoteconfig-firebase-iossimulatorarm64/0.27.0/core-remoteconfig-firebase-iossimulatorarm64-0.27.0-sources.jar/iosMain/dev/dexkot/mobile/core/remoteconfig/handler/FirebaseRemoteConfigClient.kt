package dev.dexkot.mobile.core.remoteconfig.handler

import cocoapods.FirebaseRemoteConfig.FIRRemoteConfig
import cocoapods.FirebaseRemoteConfig.FIRRemoteConfigSource
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import platform.Foundation.NSError
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@OptIn(ExperimentalForeignApi::class)
internal actual class FirebaseRemoteConfigClient actual constructor() {

    private val config: FIRRemoteConfig = FIRRemoteConfig.remoteConfig()

    actual suspend fun fetchAndActivate(expirationSeconds: Long, timeoutMillis: Long): Boolean {
        return withTimeout(timeoutMillis) {
            fetch(expirationSeconds.toDouble())
            activate()
        }
    }

    actual fun remoteStringOrNull(key: String): String? {
        val value = config.configValueForKey(key)
        return if (value.source == FIRRemoteConfigSource.FIRRemoteConfigSourceRemote) value.stringValue else null
    }

    actual fun observeUpdates(onUpdate: () -> Unit, onError: (Throwable) -> Unit) {
        config.addOnConfigUpdateListener { _, error ->
            if (error != null) {
                onError(error.toThrowable())
            } else {
                config.activateWithCompletion { _, activateError ->
                    if (activateError != null) onError(activateError.toThrowable()) else onUpdate()
                }
            }
        }
    }

    private suspend fun fetch(expirationSeconds: Double) = suspendCancellableCoroutine { continuation ->
        config.fetchWithExpirationDuration(expirationSeconds) { _, error ->
            if (error != null) {
                continuation.resumeWithException(error.toThrowable())
            } else {
                continuation.resume(Unit)
            }
        }
    }

    private suspend fun activate(): Boolean = suspendCancellableCoroutine { continuation ->
        config.activateWithCompletion { changed, error ->
            if (error != null) {
                continuation.resumeWithException(error.toThrowable())
            } else {
                continuation.resume(changed)
            }
        }
    }

    private fun NSError.toThrowable(): Throwable =
        IllegalStateException(localizedDescription)
}
