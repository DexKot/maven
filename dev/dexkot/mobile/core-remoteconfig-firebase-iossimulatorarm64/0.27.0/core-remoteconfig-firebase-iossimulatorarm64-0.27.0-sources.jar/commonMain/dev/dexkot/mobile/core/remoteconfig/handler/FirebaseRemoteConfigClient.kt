package dev.dexkot.mobile.core.remoteconfig.handler

/**
 * Thin platform-specific access to the Firebase Remote Config SDK. All orchestration lives in
 * [FirebaseRemoteConfigHandler]; this only exposes the raw calls that differ per platform.
 */
internal expect class FirebaseRemoteConfigClient() {

    /**
     * Fetches (honouring [expirationSeconds]) and activates remote config, waiting at most
     * [timeoutMillis]. Returns true if new values were activated. Throws on failure/timeout.
     */
    suspend fun fetchAndActivate(expirationSeconds: Long, timeoutMillis: Long): Boolean

    /** The value for [key] as a string, or null if it does not come from a remote (fetched) source. */
    fun remoteStringOrNull(key: String): String?

    /**
     * Registers a real-time config-update listener. On each update the SDK is re-activated and
     * [onUpdate] is invoked; failures go to [onError].
     */
    fun observeUpdates(onUpdate: () -> Unit, onError: (Throwable) -> Unit)
}
