package dev.dexkot.mobile.core.work.domain.error

import kotlin.uuid.Uuid

/**
 * Exception thrown when consecutive network errors exceed the threshold during work execution.
 *
 * This is used as a cancellation cause to indicate that the work should be retried later
 * when network conditions improve.
 *
 * @property workId The work instance that encountered network issues
 * @property consecutiveErrors Number of consecutive network errors encountered
 */
class NetworkErrorThresholdExceededException(
    val workId: Uuid,
    val consecutiveErrors: Int
) : Exception("Work $workId exceeded network error threshold with $consecutiveErrors consecutive errors")
