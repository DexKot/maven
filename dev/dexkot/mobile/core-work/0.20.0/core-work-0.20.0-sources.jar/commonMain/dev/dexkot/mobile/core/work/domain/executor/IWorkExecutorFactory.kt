package dev.dexkot.mobile.core.work.domain.executor

import kotlin.uuid.Uuid

/**
 * Factory for creating work executors.
 *
 * This is the main interface for creating work executors. The implementation
 * ([dev.dexkot.mobile.core.work.data.executor.WorkExecutorFactory]) aggregates multiple [IWorkExecutorProvider] instances
 * from feature modules and delegates creation based on work type.
 *
 * Feature modules should implement [IWorkExecutorProvider] instead of this interface
 * to avoid circular dependency issues during dependency injection.
 *
 * Example implementation (internal to core:work):
 * ```
 * class WorkExecutorFactory(
 *     providers: List<IWorkExecutorProvider>
 * ) : IWorkExecutorFactory {
 *     private val providerMap = providers.associateBy { it.workType }
 *
 *     override fun create(workType: String, workId: Uuid): IWorkExecutor? {
 *         return providerMap[workType]?.create(workId)
 *     }
 * }
 * ```
 *
 * @see IWorkExecutorProvider for feature module implementations
 */
interface IWorkExecutorFactory {

    /**
     * Creates an executor for the specified work type and ID.
     *
     * @param workType The type identifier (e.g., "scan_work", "pdf_export")
     * @param workId The unique work instance ID
     * @return Executor instance, or null if workType is not supported
     */
    fun create(workType: String, workId: Uuid): IWorkExecutor?

}
