package dev.dexkot.mobile.core.work.domain.config.model.network

/**
 * Network requirements for background work execution.
 *
 * Defines what type of network connectivity is needed for work to run.
 */
enum class NetworkRequirement {
    /**
     * No network required - work can run offline.
     */
    NONE,

    /**
     * Any network connection required (WiFi, cellular, etc.).
     */
    CONNECTED,

    /**
     * Unmetered network required (typically WiFi).
     * Work will not run on metered connections like cellular data.
     */
    UNMETERED
}
