package dev.dexkot.mobile.core.work.domain.work

import kotlin.uuid.Uuid

private const val WORK_TAG_PREFIX = "workId"
private const val WORK_TYPE_TAG_PREFIX = "workType"

fun workTag(
    workType: String,
    workId: Uuid
): String {
    return "${workType}_${workId}"
}

fun workIdTag(
    workId: Uuid
): String {
    return "${WORK_TAG_PREFIX}_${workId}"
}

fun workTypeTag(
    workType: String
): String {
    return "${WORK_TYPE_TAG_PREFIX}_${workType}"
}