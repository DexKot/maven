package dev.dexkot.mobile.core.work.domain.config

import dev.dexkot.mobile.core.work.domain.config.model.WorkTypeConfig

/**
 * Provides configuration for different work types.
 *
 * This is the main interface for providing work type configurations. The implementation
 * ([dev.dexkot.mobile.core.work.data.config.WorkTypeConfigFactory]) aggregates multiple [IWorkTypeConfigProvider] instances
 * from feature modules and delegates configuration lookup based on work type.
 *
 * Feature modules should implement [IWorkTypeConfigProvider] instead of this interface
 * to avoid circular dependency issues during dependency injection.
 *
 * Example implementation (internal to core:work):
 * ```
 * class WorkTypeConfigProvider(
 *     delegates: List<IWorkTypeConfigDelegate>
 * ) : IWorkTypeConfigProvider {
 *     private val delegateMap = delegates.associateBy { it.workType }
 *
 *     override fun getConfig(workType: String): WorkTypeConfig? {
 *         return delegateMap[workType]?.getConfig()
 *     }
 * }
 * ```
 *
 * @see IWorkTypeConfigProvider for feature module implementations
 */
interface IWorkTypeConfigFactory {

    /**
     * Returns configuration for the specified work type.
     *
     * @param workType The work type identifier
     * @return Configuration, or null if work type is not supported
     */
    fun getConfig(workType: String): WorkTypeConfig?

}
