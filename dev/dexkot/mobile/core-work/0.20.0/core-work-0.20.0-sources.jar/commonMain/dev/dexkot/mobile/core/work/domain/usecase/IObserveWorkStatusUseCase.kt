package dev.dexkot.mobile.core.work.domain.usecase

import dev.dexkot.mobile.core.work.domain.executor.model.WorkStatus
import kotlinx.coroutines.flow.Flow
import kotlin.uuid.Uuid

/**
 * Use case for observing WorkManager status of a specific work instance.
 *
 * This use case allows feature modules to monitor the execution status of work
 * scheduled in WorkManager without directly depending on WorkManager APIs.
 *
 * The use case internally constructs the work instance tag ("work_<workId>") and
 * observes the WorkInfo status from WorkManager, mapping it to [WorkStatus].
 *
 * Note: Returns null if the work is not scheduled in WorkManager (never scheduled or already pruned).
 *
 * Example usage:
 * ```
 * class ScanViewModel(
 *     private val observeWorkManagerStatus: IObserveWorkManagerStatusUseCase
 * ) : ViewModel() {
 *
 *     fun observeScanWork(workId: Uuid) {
 *         viewModelScope.launch {
 *             observeWorkManagerStatus(
 *                 workType = "scan_pdf",
 *                 workId = workId
 *             ).collect { status ->
 *                 when (status) {
 *                     null -> // Not scheduled in WorkManager
 *                     WorkStatus.Queued -> // Enqueued, waiting for constraints
 *                     WorkStatus.Running -> // Currently executing
 *                     WorkStatus.Completed -> // Successfully completed
 *                     WorkStatus.Failed -> // Failed
 *                     WorkStatus.Cancelled -> // Cancelled
 *                 }
 *             }
 *         }
 *     }
 * }
 * ```
 */
interface IObserveWorkStatusUseCase {

    /**
     * Observes the WorkManager status of a specific work instance.
     *
     * The flow emits:
     * - null if no work is found with the given workId (not scheduled or already pruned)
     * - Current [WorkStatus] as it changes (Queued -> Running -> Completed/Failed/Cancelled)
     *
     * The flow is hot and will continue emitting as the work status changes in WorkManager.
     *
     * @param workType The type of work (e.g., "scan_pdf", "pdf_export")
     * @param workId The unique identifier for the work instance
     * @return Flow emitting WorkManager status updates (null if not scheduled)
     */
    operator fun invoke(
        workType: String,
        workId: Uuid
    ): Flow<WorkStatus?>

}
