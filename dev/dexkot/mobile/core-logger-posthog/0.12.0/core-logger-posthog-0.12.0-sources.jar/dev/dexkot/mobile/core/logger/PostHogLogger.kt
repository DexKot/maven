package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.Status
import dev.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.Status as PermissionStatus
import dev.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import dev.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import dev.dexkot.mobile.core.logger.events.ui.screen.Action
import dev.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import dev.dexkot.mobile.core.logger.events.ui.state.UiStateEvent
import dev.dexkot.mobile.core.logger.levels.Level
import com.posthog.PostHogInterface

class PostHogLogger(
    private val postHog: PostHogInterface
): ILogger {

    override fun setUserId(identifier: String) {
        postHog.identify(identifier)
    }

    override fun removeUserId() {
        postHog.reset()
    }

    override fun setUserProperty(key: String, value: String?) {
        if (value == null) {
            removeUserProperty(key)
            return
        }
        postHog.setPersonProperties(
            userPropertiesToSet = mapOf(key to value),
        )
    }

    override fun removeUserProperty(key: String) {
        postHog.capture(
            event = "\$set",
            properties = mapOf("\$unset" to listOf(key)),
        )
    }

    override fun log(event: LogEvent) {
        when (event) {
            is InteractionEvent -> postHog.capture(
                event = "${event.sourceComponent}:${event.elementId}_${event.interaction.value}",
                properties = buildMap {
                    put("\$screen_name", event.sourceComponent)
                    put("element_id", event.elementId)
                    put("interaction", event.interaction.value)
                    event.extras.forEach { (key, value) -> put(key, value) }
                },
            )
            is ScreenEvent -> if (event.action == Action.Enter) {
                postHog.screen(
                    screenTitle = event.sourceComponent,
                )
            }
            is NavigationEvent -> postHog.logger.info(
                "navigation: ${event.navigationId}",
                event.params,
            )
            is OperationEvent -> {
                postHog.logger.info(
                    "operation: ${event.operationId} [${event.status.value}]",
                    event.params,
                )
                if (event.isBusinessEvent && event.status == Status.Success) {
                    postHog.capture(
                        event = "${event.sourceComponent}:${event.operationId}",
                        properties = buildMap {
                            put("\$screen_name", event.sourceComponent)
                            put("status", event.status.value)
                            event.params.forEach { (key, value) -> put(key, value) }
                        },
                    )
                }
            }
            is PermissionEvent -> {
                postHog.logger.info(
                    "permission: ${event.permissions.map { "${it.key}=${it.value.value}" }}",
                )
                val isResult = event.permissions.any { it.value != PermissionStatus.Request }
                if (isResult) {
                    postHog.capture(
                        event = event.type,
                        properties = buildMap {
                            put("\$screen_name", event.sourceComponent)
                            event.permissions.forEach { (key, value) -> put(key, value.value) }
                        },
                    )
                }
            }
            is IntentionEvent -> postHog.logger.info(
                "intention: ${event.intentionId}",
                event.params,
            )
            is UiStateEvent -> postHog.logger.info(
                "${event.state.value}: ${event.elementId}",
                event.extras,
            )
        }
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        when (level) {
            Level.Verbose -> postHog.logger.trace(message, params)
            Level.Debug -> postHog.logger.debug(message, params)
            Level.Info -> postHog.logger.info(message, params)
            Level.Warning -> postHog.logger.warn(message, params)
            Level.Error -> postHog.logger.error(message, params)
        }
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        postHog.captureException(
            throwable = throwable,
            properties = buildMap {
                message?.let { put("message", it) }
                putAll(params)
            },
        )
    }

}
