package dev.dexkot.mobile.core.permission.checker

import dev.dexkot.mobile.core.permission.Permission

/**
 * Simple permission checker that only checks if permissions are granted.
 * This interface only requires Context, not Activity, making it safe for use in ViewModels.
 *
 * For full permission handling (rationale, first-time tracking, requesting),
 * use [dev.dexkot.mobile.core.permission.controller.IPermissionController] in the Compose layer.
 */
interface IPermissionChecker {

    /**
     * Check if a permission is currently granted.
     *
     * @param permission The permission to check.
     * @return true if the permission is granted, false otherwise.
     */
    fun isGranted(permission: Permission): Boolean
}
