package dev.dexkot.mobile.core.permission.controller

import dev.dexkot.mobile.core.permission.Permission
import dev.dexkot.mobile.core.permission.PermissionResult
import dev.dexkot.mobile.core.permission.PermissionState

/**
 * Full controller for querying, managing, and requesting permission states.
 *
 * This interface contains Activity-dependent methods
 * for rationale checking, first-time tracking, result evaluation, and permission requests.
 *
 * Use this in the Compose layer where Activity is available.
 * For ViewModels, use [dev.dexkot.mobile.core.permission.checker.IPermissionChecker] instead.
 */
interface IPermissionController {

    /**
     * Get the complete state of a permission.
     *
     * @param permission The permission to query.
     * @return The current state including status, rationale requirement, and first-time flags.
     */
    fun getState(
        permission: Permission
    ): PermissionState

    /**
     * Request a single permission from the Android OS.
     *
     * If the permission is permanently denied, [onResult] will be called immediately
     * with [PermissionResult.AutoDenied] without showing the OS dialog.
     *
     * @param permission The permission to request.
     * @param onResult Callback invoked with the result of the permission request.
     */
    fun requestPermission(
        permission: Permission,
        onResult: (PermissionResult) -> Unit
    )

    /**
     * Request multiple permissions from the Android OS.
     *
     * Permissions that are permanently denied will return [PermissionResult.AutoDenied]
     * in the result map without showing an OS dialog for them.
     *
     * @param permissions The permissions to request.
     * @param onResult Callback invoked with a map of each permission to its result.
     */
    fun requestPermissions(
        permissions: List<Permission>,
        onResult: (Map<Permission, PermissionResult>) -> Unit
    )
}
