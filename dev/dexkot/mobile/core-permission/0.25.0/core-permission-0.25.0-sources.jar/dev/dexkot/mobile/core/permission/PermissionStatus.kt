package dev.dexkot.mobile.core.permission

/**
 * Represents the current status of a permission.
 */
enum class PermissionStatus {
    /**
     * Permission has been granted by the user.
     */
    Granted,

    /**
     * Permission has been denied but can be requested again.
     * This includes first-time requests and denials without "Don't ask again".
     */
    Denied,

    /**
     * Permission has been permanently denied.
     * The user selected "Don't ask again" or the permission was auto-denied.
     * The app should direct the user to Settings to grant this permission.
     */
    PermanentlyDenied
}
