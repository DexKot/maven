package dev.dexkot.mobile.core.permission.controller

import dev.dexkot.mobile.core.permission.Permission
import dev.dexkot.mobile.core.permission.PermissionResult
import dev.dexkot.mobile.core.permission.PermissionState
import dev.dexkot.mobile.core.permission.PermissionStatus

/**
 * A dummy implementation of [IPermissionController] for use in Compose previews.
 *
 * By default, all permissions are reported as granted. You can customize behavior
 * by providing a custom [permissionStates] map.
 *
 * @param permissionStates Optional map of permission states. Permissions not in this map
 *                         will be reported as granted.
 */
class DummyPermissionController(
    private val permissionStates: Map<Permission, PermissionState> = emptyMap()
) : IPermissionController {

    override fun getState(
        permission: Permission
    ): PermissionState {
        return permissionStates[permission] ?: PermissionState.Granted
    }

    override fun requestPermission(
        permission: Permission,
        onResult: (PermissionResult) -> Unit
    ) {
        val state = getState(permission)
        val result = when (state.status) {
            PermissionStatus.Granted -> PermissionResult.Granted
            PermissionStatus.PermanentlyDenied -> PermissionResult.AutoDenied
            PermissionStatus.Denied -> PermissionResult.Denied
        }
        onResult(result)
    }

    override fun requestPermissions(
        permissions: List<Permission>,
        onResult: (Map<Permission, PermissionResult>) -> Unit
    ) {
        val results = permissions.associateWith { permission ->
            val state = getState(permission)
            when (state.status) {
                PermissionStatus.Granted -> PermissionResult.Granted
                PermissionStatus.PermanentlyDenied -> PermissionResult.AutoDenied
                PermissionStatus.Denied -> PermissionResult.Denied
            }
        }
        onResult(results)
    }
}
