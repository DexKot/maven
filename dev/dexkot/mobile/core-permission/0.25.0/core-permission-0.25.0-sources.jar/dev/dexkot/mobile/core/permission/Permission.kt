package dev.dexkot.mobile.core.permission

import android.Manifest
import android.os.Build

open class Permission(
    val key: String,
    val minSdk: Int? = null
) {

    val isRelevantForCurrentSdk: Boolean
        get() = minSdk == null || Build.VERSION.SDK_INT >= minSdk

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Permission) return false
        return key == other.key
    }

    override fun hashCode(): Int = key.hashCode()

    override fun toString(): String = "Permission($key)"

    /**
     * Catálogo de permisos estándar de Android. [Permission] sigue siendo `open`, así que la app
     * puede definir permisos custom instanciándola directamente. Los que se agregaron en una API
     * concreta llevan su [minSdk] para que [isRelevantForCurrentSdk] los filtre correctamente.
     */
    companion object {

        val RecordAudio = Permission(Manifest.permission.RECORD_AUDIO)

        val Camera = Permission(Manifest.permission.CAMERA)

        val FineLocation = Permission(Manifest.permission.ACCESS_FINE_LOCATION)

        val CoarseLocation = Permission(Manifest.permission.ACCESS_COARSE_LOCATION)

        val BackgroundLocation = Permission(
            key = Manifest.permission.ACCESS_BACKGROUND_LOCATION,
            minSdk = Build.VERSION_CODES.Q
        )

        val ActivityRecognition = Permission(
            key = Manifest.permission.ACTIVITY_RECOGNITION,
            minSdk = Build.VERSION_CODES.Q
        )

        val BluetoothScan = Permission(
            key = Manifest.permission.BLUETOOTH_SCAN,
            minSdk = Build.VERSION_CODES.S
        )

        val BluetoothConnect = Permission(
            key = Manifest.permission.BLUETOOTH_CONNECT,
            minSdk = Build.VERSION_CODES.S
        )

        val Notifications = Permission(
            key = Manifest.permission.POST_NOTIFICATIONS,
            minSdk = Build.VERSION_CODES.TIRAMISU
        )

        val ReadMediaImages = Permission(
            key = Manifest.permission.READ_MEDIA_IMAGES,
            minSdk = Build.VERSION_CODES.TIRAMISU
        )

        val ReadMediaVideo = Permission(
            key = Manifest.permission.READ_MEDIA_VIDEO,
            minSdk = Build.VERSION_CODES.TIRAMISU
        )

        val ReadMediaAudio = Permission(
            key = Manifest.permission.READ_MEDIA_AUDIO,
            minSdk = Build.VERSION_CODES.TIRAMISU
        )

    }
}
