package dev.dexkot.mobile.core.permission.controller.requests

import dev.dexkot.mobile.core.permission.Permission
import dev.dexkot.mobile.core.permission.PermissionResult

internal data class MultiplePermissionsRequest(
    val permissions: List<Permission>,
    val rationalesBefore: Map<Permission, Boolean>,
    val callback: (Map<Permission, PermissionResult>) -> Unit
)
