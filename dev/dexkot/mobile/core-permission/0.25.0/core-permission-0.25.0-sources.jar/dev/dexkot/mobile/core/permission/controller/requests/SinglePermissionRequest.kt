package dev.dexkot.mobile.core.permission.controller.requests

import dev.dexkot.mobile.core.permission.Permission
import dev.dexkot.mobile.core.permission.PermissionResult

internal data class SinglePermissionRequest(
    val permission: Permission,
    val rationaleBefore: Boolean,
    val callback: (PermissionResult) -> Unit
)
