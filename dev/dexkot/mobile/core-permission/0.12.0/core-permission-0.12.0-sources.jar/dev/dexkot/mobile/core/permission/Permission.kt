package dev.dexkot.mobile.core.permission

import android.os.Build

open class Permission(
    val key: String,
    val minSdk: Int? = null
) {

    val isRelevantForCurrentSdk: Boolean
        get() = minSdk == null || Build.VERSION.SDK_INT >= minSdk

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Permission) return false
        return key == other.key
    }

    override fun hashCode(): Int = key.hashCode()

    override fun toString(): String = "Permission($key)"
}
