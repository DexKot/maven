package dev.dexkot.mobile.core.ui.compose.screen

@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.CLASS)
annotation class UiState
