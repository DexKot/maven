package dev.dexkot.mobile.core.ui.compose.permission

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import dev.dexkot.mobile.core.permission.controller.DummyPermissionController
import dev.dexkot.mobile.core.permission.controller.IPermissionController

val LocalPermissionController = staticCompositionLocalOf<IPermissionController> { DummyPermissionController() }

@Composable
fun PermissionController(
    permissionController: IPermissionController,
    content: @Composable () -> Unit
) {

    CompositionLocalProvider(
        LocalPermissionController provides permissionController,
        content = content
    )

}
