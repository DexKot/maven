package dev.dexkot.mobile.core.ui.viewmodel.android

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope as baseViewModelScope
import dev.dexkot.mobile.core.ui.navigation.action.INavAction
import dev.dexkot.mobile.core.ui.viewmodel.IScreenViewModel
import dev.dexkot.mobile.core.ui.viewmodel.event.Event
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

abstract class AndroidViewModel<Model, Intention>: IScreenViewModel<Model, Intention>, ViewModel() {

    private var _additionalContext: CoroutineContext = EmptyCoroutineContext
    private var _scopeWithContext: CoroutineScope? = null

    fun addCoroutineContext(context: CoroutineContext) {
        _additionalContext += context
        _scopeWithContext = null
    }

    protected val viewModelScope: CoroutineScope
        get() {
            if (_additionalContext === EmptyCoroutineContext) return baseViewModelScope
            return _scopeWithContext
                ?: CoroutineScope(baseViewModelScope.coroutineContext + _additionalContext)
                    .also { _scopeWithContext = it }
        }

    private val _nav: MutableStateFlow<Event<INavAction>?> = MutableStateFlow(null)
    override val nav = _nav.asStateFlow()

    protected fun emit(action: INavAction) {
        _nav.value = Event(action)
    }

    protected fun <T> Flow<T>.stateFlow(
        coroutineScope: CoroutineScope = viewModelScope,
        started: SharingStarted = SharingStarted.WhileSubscribed(),
        initialValue: T
    ) = this.stateIn(coroutineScope, started, initialValue)

}
