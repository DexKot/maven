package dev.dexkot.mobile.core.ui.compose.permission

import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import dev.dexkot.mobile.core.permission.Permission
import dev.dexkot.mobile.core.permission.PermissionResult
import dev.dexkot.mobile.core.permission.PermissionState
import dev.dexkot.mobile.core.permission.controller.IPermissionController
import dev.dexkot.mobile.core.logger.events.ui.permission.Status as LogStatus

internal class LoggedPermissionController(
    private val delegate: IPermissionController,
    private val logger: ILoggerInteractor
) : IPermissionController {

    override fun getState(permission: Permission): PermissionState {
        return delegate.getState(permission)
    }

    override fun requestPermission(permission: Permission, onResult: (PermissionResult) -> Unit) {
        logger.permission(listOf(permission.key))
        delegate.requestPermission(permission) { result ->
            logger.permission(mapOf(permission.key to result.toLogStatus()))
            onResult(result)
        }
    }

    override fun requestPermissions(
        permissions: List<Permission>,
        onResult: (Map<Permission, PermissionResult>) -> Unit
    ) {
        logger.permission(permissions.map { it.key })
        delegate.requestPermissions(permissions) { results ->
            logger.permission(results.map { (permission, result) ->
                permission.key to result.toLogStatus()
            }.toMap())
            onResult(results)
        }
    }

    private fun PermissionResult.toLogStatus(): LogStatus = when (this) {
        is PermissionResult.Granted -> LogStatus.Granted
        is PermissionResult.Denied -> LogStatus.Denied
        is PermissionResult.AutoDenied -> LogStatus.RequestIgnored
    }
}

fun IPermissionController.withLogging(
    logger: ILoggerInteractor
): IPermissionController {
    return LoggedPermissionController(
        delegate = this,
        logger = logger
    )
}
