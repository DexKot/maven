package dev.dexkot.mobile.core.ui.viewmodel

import dev.dexkot.mobile.core.ui.navigation.action.INavAction
import dev.dexkot.mobile.core.ui.viewmodel.event.Event
import kotlinx.coroutines.flow.StateFlow

interface IScreenViewModel<Model, Intention> : IViewModel<Model, Intention> {

    val nav: StateFlow<Event<INavAction>?>

}
