package dev.dexkot.mobile.core.ui.compose.logger

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor

val LocalLogger = staticCompositionLocalOf<ILoggerInteractor> { DummyLoggerInteractor }

@Composable
fun Logger(
    loggerInteractor: ILoggerInteractor,
    content: @Composable () -> Unit
) {

    CompositionLocalProvider(
        LocalLogger provides loggerInteractor,
        content = content
    )

}
