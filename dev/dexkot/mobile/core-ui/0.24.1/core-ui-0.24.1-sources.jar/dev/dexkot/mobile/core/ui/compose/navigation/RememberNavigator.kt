package dev.dexkot.mobile.core.ui.compose.navigation

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator
import dev.dexkot.mobile.core.ui.navigation.navigator.Navigator

@Composable
fun rememberNavigator(
    activity: FragmentActivity,
    navHostController: NavHostController = rememberNavController(),
    deepLinkScheme: String
): INavigator {
    lateinit var navigator: Navigator

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        navigator.onActivityResult(result)
    }

    navigator = Navigator(
        navHostController = navHostController,
        activity = activity,
        launcher = launcher,
        deepLinkScheme = deepLinkScheme,
    )

    return navigator
}
