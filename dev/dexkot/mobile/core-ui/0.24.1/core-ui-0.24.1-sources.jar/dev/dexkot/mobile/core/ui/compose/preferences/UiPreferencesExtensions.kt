package dev.dexkot.mobile.core.ui.compose.preferences

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.remember
import dev.dexkot.mobile.core.ui.preferences.IUiPreferences

@Composable
fun IUiPreferences.getBooleanState(
    key: String,
    defaultValue: Boolean = false
): State<Boolean> {
    val flow = remember(key) { getBooleanFlow(key, defaultValue) }
    return flow.collectAsState()
}

@Composable
fun IUiPreferences.getStringState(
    key: String,
    defaultValue: String = "",
): State<String> {
    val flow = remember(key) { getStringFlow(key, defaultValue) }
    return flow.collectAsState()
}

@Composable
fun IUiPreferences.getStringSetState(
    key: String,
    defaultValue: Set<String> = emptySet(),
): State<Set<String>> {
    val flow = remember(key) { getStringSetFlow(key, defaultValue) }
    return flow.collectAsState()
}

@Composable
fun IUiPreferences.getFloatState(
    key: String,
    defaultValue: Float = 0f
): State<Float> {
    val flow = remember(key) { getFloatFlow(key, defaultValue) }
    return flow.collectAsState()
}

@Composable
fun <T> IUiPreferences.getState(
    key: String,
    defaultValue: String = "",
    converter: (String) -> T
): State<T> {
    val stringState = remember(key) { getStringFlow(key, defaultValue) }.collectAsState()
    return remember(key) { derivedStateOf { converter(stringState.value) } }
}
