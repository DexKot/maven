package dev.dexkot.mobile.core.ui.navigation.action

interface INavAction
