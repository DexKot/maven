package dev.dexkot.mobile.core.ui.compose.transitions

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

val LocalNavAnimatedVisibilityScope = staticCompositionLocalOf<AnimatedVisibilityScope?> { null }

@Composable
fun NavAnimatedVisibility(
    scope: AnimatedVisibilityScope,
    content: @Composable () -> Unit
) {

    CompositionLocalProvider(
        LocalNavAnimatedVisibilityScope provides scope,
        content = content
    )

}
