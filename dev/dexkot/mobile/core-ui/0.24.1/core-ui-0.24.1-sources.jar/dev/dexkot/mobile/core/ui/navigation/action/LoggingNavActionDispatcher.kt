package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import dev.dexkot.mobile.core.ui.navigation.navigator.INavActionExecutor
import kotlin.reflect.KClass

internal class LoggingNavActionDispatcher(
    private val delegate: INavActionDispatcher,
    private val logger: ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) : INavActionDispatcher {

    private val decoratorMap: Map<KClass<*>, INavActionLogDecorator> =
        decorators.associateBy { it.actionType }

    override fun dispatch(action: INavAction): INavActionExecutor {
        val executor = delegate.dispatch(action)
        val decorator = decoratorMap[action::class] ?: return executor
        return decorator.wrap(executor, action, logger)
    }

}

fun INavActionDispatcher.withLogging(
    logger: ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
): INavActionDispatcher = LoggingNavActionDispatcher(this, logger, decorators)
