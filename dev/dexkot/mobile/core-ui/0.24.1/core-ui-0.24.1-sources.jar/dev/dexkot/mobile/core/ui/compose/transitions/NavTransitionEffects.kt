package dev.dexkot.mobile.core.ui.compose.transitions

import androidx.compose.animation.EnterExitState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.remember

/**
 * `true` mientras la transición de entrada/salida de la pantalla está en curso.
 *
 * Se apoya en [LocalNavAnimatedVisibilityScope]; fuera de un destino de navegación
 * (p. ej. en previews) reporta siempre `false`.
 */
@Composable
fun rememberIsScreenTransitioning(): State<Boolean> {

    val transition = LocalNavAnimatedVisibilityScope.current?.transition

    return remember(transition) {
        derivedStateOf {
            transition != null && transition.currentState != transition.targetState
        }
    }

}

/**
 * Invoca [onFinished] cuando la transición de **entrada** de la pantalla termina
 * de asentarse en [EnterExitState.Visible].
 *
 * Si no hay [LocalNavAnimatedVisibilityScope] (p. ej. en previews) dispara de
 * inmediato, para que el consumidor no quede esperando indefinidamente.
 */
@Composable
fun OnEnterTransitionFinished(onFinished: () -> Unit) {

    val transition = LocalNavAnimatedVisibilityScope.current?.transition

    if (transition == null) {
        LaunchedEffect(Unit) { onFinished() }
        return
    }

    val settled = transition.currentState == EnterExitState.Visible &&
        transition.targetState == EnterExitState.Visible

    LaunchedEffect(settled) {
        if (settled) onFinished()
    }

}

/**
 * Invoca [onFinished] cuando la transición de **salida** de la pantalla termina
 * de asentarse en [EnterExitState.PostExit], justo antes de que el destino se
 * descarte del backstack.
 *
 * Fuera de un destino de navegación es un no-op (un destino sin scope nunca sale).
 */
@Composable
fun OnExitTransitionFinished(onFinished: () -> Unit) {

    val transition = LocalNavAnimatedVisibilityScope.current?.transition ?: return

    val settled = transition.currentState == EnterExitState.PostExit &&
        transition.targetState == EnterExitState.PostExit

    LaunchedEffect(settled) {
        if (settled) onFinished()
    }

}
