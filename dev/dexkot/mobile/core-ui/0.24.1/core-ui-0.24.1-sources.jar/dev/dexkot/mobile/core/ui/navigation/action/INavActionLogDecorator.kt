package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import dev.dexkot.mobile.core.ui.navigation.navigator.INavActionExecutor
import kotlin.reflect.KClass

interface INavActionLogDecorator {

    val actionType: KClass<out INavAction>

    fun wrap(
        executor: INavActionExecutor,
        action: INavAction,
        logger: ILoggerInteractor
    ): INavActionExecutor

}
