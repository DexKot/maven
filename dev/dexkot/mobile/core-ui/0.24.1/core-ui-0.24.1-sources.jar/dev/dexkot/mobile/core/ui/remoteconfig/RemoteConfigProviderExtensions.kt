package dev.dexkot.mobile.core.ui.remoteconfig

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import dev.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider

@Composable
fun IRemoteConfigProvider.getBooleanState(
    key: String,
    defaultValue: Boolean
): State<Boolean> {
    val flow = remember { getBooleanFlow(key, defaultValue) }
    return flow.collectAsState()
}

@Composable
fun IRemoteConfigProvider.getLongState(
    key: String,
    defaultValue: Long
): State<Long> {
    val flow = remember { getLongFlow(key, defaultValue) }
    return flow.collectAsState()
}

@Composable
fun IRemoteConfigProvider.getStringState(
    key: String,
    defaultValue: String
): State<String> {
    val flow = remember { getStringFlow(key, defaultValue) }
    return flow.collectAsState()
}
