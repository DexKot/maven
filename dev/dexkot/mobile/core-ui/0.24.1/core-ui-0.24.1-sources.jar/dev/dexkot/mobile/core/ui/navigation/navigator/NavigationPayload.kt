package dev.dexkot.mobile.core.ui.navigation.navigator

import android.os.Bundle
import androidx.lifecycle.SavedStateHandle

private const val KEY_ARGS = "__nav_args"
private const val KEY_RESULT = "__nav_result"

internal fun SavedStateHandle.setNavArgs(args: Bundle) {
    set(KEY_ARGS, args)
}

internal fun SavedStateHandle.setNavResult(result: Bundle) {
    set(KEY_RESULT, result)
}

internal fun SavedStateHandle.consumeNavArgs(): Bundle? = consume(KEY_ARGS)

internal fun SavedStateHandle.consumeNavResult(): Bundle? = consume(KEY_RESULT)

private fun SavedStateHandle.consume(key: String): Bundle? {
    val value = get<Bundle>(key)
    if (value != null) remove<Bundle>(key)
    return value
}
