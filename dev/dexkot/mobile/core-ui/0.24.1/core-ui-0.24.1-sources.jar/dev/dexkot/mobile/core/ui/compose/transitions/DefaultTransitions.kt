package dev.dexkot.mobile.core.ui.compose.transitions

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut

val DefaultTransitions = Transitions(
    enterTransition = {
        fadeIn(animationSpec = tween(durationMillis = 250, delayMillis = 100))
    },
    exitTransition = {
        fadeOut(animationSpec = tween(durationMillis = 250, delayMillis = 100))
    },
    popEnterTransition = {
        fadeIn(animationSpec = tween(durationMillis = 250, delayMillis = 100))
    },
    popExitTransition = {
        fadeOut(animationSpec = tween(durationMillis = 250, delayMillis = 100))
    }
)
