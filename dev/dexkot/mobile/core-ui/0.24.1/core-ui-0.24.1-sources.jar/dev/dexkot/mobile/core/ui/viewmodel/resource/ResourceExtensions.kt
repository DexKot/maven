package dev.dexkot.mobile.core.ui.viewmodel.resource

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

fun <T> Flow<Resource<T>>.values(): Flow<T> {
    return this.filterIsInstance<Resource.Loaded<T>>().map { it.data }
}

fun <T> Flow<Resource<T>>.finished(): Flow<Resource<T>> {
    return this.filter { !it.inProgress() }
}

fun Resource<*>.inProgress(): Boolean {
    return this is Resource.Loading || this is Resource.None
}

suspend fun <T1> onLoaded(
    flow1: Flow<Resource<T1>>,
    block: suspend (T1) -> Unit
) {
    val firstValue = flow1.values().first()
    block(firstValue)
}

suspend fun <T1, T2> onLoaded(
    flow1: Flow<Resource<T1>>,
    flow2: Flow<Resource<T2>>,
    block: suspend (T1, T2) -> Unit
) {
    val firstValue = flow1.values().first()
    val secondValue = flow2.values().first()
    block(firstValue, secondValue)
}

suspend fun <T1, T2, T3> onLoaded(
    flow1: Flow<Resource<T1>>,
    flow2: Flow<Resource<T2>>,
    flow3: Flow<Resource<T3>>,
    block: suspend (T1, T2, T3) -> Unit
) {
    val firstValue = flow1.values().first()
    val secondValue = flow2.values().first()
    val thirdValue = flow3.values().first()
    block(firstValue, secondValue, thirdValue)
}

suspend fun <T1, T2, T3> onFinished(
    flow1: Flow<Resource<T1>>,
    flow2: Flow<Resource<T2>>,
    flow3: Flow<Resource<T3>>,
    block: suspend (T1?, T2?, T3?) -> Unit
) {
    val firstValue = flow1.finished().first().data
    val secondValue = flow2.finished().first().data
    val thirdValue = flow3.finished().first().data
    block(firstValue, secondValue, thirdValue)
}
