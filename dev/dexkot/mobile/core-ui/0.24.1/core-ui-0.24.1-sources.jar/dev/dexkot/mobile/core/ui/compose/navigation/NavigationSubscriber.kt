package dev.dexkot.mobile.core.ui.compose.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.navigation.NavBackStackEntry
import dev.dexkot.mobile.core.ui.compose.logger.LocalLogger
import dev.dexkot.mobile.core.ui.compose.screen.ScreenLifeCycle
import dev.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator
import dev.dexkot.mobile.core.ui.navigation.navigator.consumeNavArgs
import dev.dexkot.mobile.core.ui.navigation.navigator.consumeNavResult
import dev.dexkot.mobile.core.ui.viewmodel.IScreenViewModel

@Composable
fun NavigationSubscriber(
    viewModel: IScreenViewModel<*,*>,
    navigator: INavigator,
    dispatcher: INavActionDispatcher
) {

    val loggerInteractor = LocalLogger.current

    val savedStateHandle = (LocalViewModelStoreOwner.current as? NavBackStackEntry)?.savedStateHandle

    ScreenLifeCycle(
        onCreate = {
            viewModel.onCreate(savedStateHandle?.consumeNavArgs())
        },
        onResume = {
            loggerInteractor.enter()
            viewModel.onResume(savedStateHandle?.consumeNavResult())
        },
        onPause = {
            loggerInteractor.exit()
        },
        onStop = {
            viewModel.onStop()
        }
    )

    val navEvent by viewModel.nav.collectAsState()
    LaunchedEffect(navEvent) {
        navEvent?.handle()?.let { navAction ->
            val resolved = dispatcher.dispatch(navAction)
            resolved(navigator)
        }
    }

}
