package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.ui.navigation.navigator.INavActionExecutor
import kotlin.reflect.KClass

interface INavActionFactory<T : INavAction> {

    val actionType: KClass<T>

    fun resolve(action: T): INavActionExecutor

}
