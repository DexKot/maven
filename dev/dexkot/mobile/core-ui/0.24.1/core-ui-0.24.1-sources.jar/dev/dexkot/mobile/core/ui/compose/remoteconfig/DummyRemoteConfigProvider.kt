package dev.dexkot.mobile.core.ui.compose.remoteconfig

import dev.dexkot.mobile.core.foundation.result.getOrDefault
import dev.dexkot.mobile.core.foundation.result.unwrap
import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import dev.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import kotlinx.coroutines.flow.StateFlow

object DummyRemoteConfigProvider: IRemoteConfigProvider {

    override val remoteConfigHandler: IRemoteConfigHandler = DummyRemoteConfigHandler

    override fun getBoolean(key: String): Boolean? =
        remoteConfigHandler.getBoolean(key).unwrap()

    override fun getBoolean(key: String, defaultValue: Boolean): Boolean =
        remoteConfigHandler.getBoolean(key).getOrDefault(defaultValue)

    override fun getString(key: String): String? =
        remoteConfigHandler.getString(key).unwrap()

    override fun getString(key: String, defaultValue: String): String =
        remoteConfigHandler.getString(key).getOrDefault(defaultValue)

    override fun getLong(key: String): Long? =
        remoteConfigHandler.getLong(key).unwrap()

    override fun getLong(key: String, defaultValue: Long): Long =
        remoteConfigHandler.getLong(key).getOrDefault(defaultValue)

    override fun getBooleanFlow(key: String, defaultValue: Boolean): StateFlow<Boolean> =
        remoteConfigHandler.getBooleanFlow(key, defaultValue)

    override fun getLongFlow(key: String, defaultValue: Long): StateFlow<Long> =
        remoteConfigHandler.getLongFlow(key, defaultValue)

    override fun getStringFlow(key: String, defaultValue: String): StateFlow<String> =
        remoteConfigHandler.getStringFlow(key, defaultValue)

}
