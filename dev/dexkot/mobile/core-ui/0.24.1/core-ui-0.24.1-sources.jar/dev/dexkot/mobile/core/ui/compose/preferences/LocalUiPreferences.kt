package dev.dexkot.mobile.core.ui.compose.preferences

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import dev.dexkot.mobile.core.ui.preferences.IUiPreferences

val LocalUiPreference = staticCompositionLocalOf<IUiPreferences> { DummyUiPreference }

@Composable
fun Preferences(
    uiPreferences: IUiPreferences,
    content: @Composable () -> Unit
) {

    CompositionLocalProvider(
        LocalUiPreference provides uiPreferences,
        content = content
    )

}
