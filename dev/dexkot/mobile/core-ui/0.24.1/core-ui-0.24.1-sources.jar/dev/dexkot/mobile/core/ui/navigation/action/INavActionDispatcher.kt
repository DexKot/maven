package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.ui.navigation.navigator.INavActionExecutor

interface INavActionDispatcher {

    fun dispatch(action: INavAction): INavActionExecutor

}
