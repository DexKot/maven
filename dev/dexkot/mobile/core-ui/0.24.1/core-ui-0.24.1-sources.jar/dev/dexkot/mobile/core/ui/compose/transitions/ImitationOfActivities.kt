package dev.dexkot.mobile.core.ui.compose.transitions

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween

val ImitationOfActivities = Transitions(
    enterTransition = {
        slideIntoContainer(
            towards = AnimatedContentTransitionScope.SlideDirection.Left,
            animationSpec = tween(durationMillis = 250, delayMillis = 100, easing = LinearOutSlowInEasing),
            initialOffset = { it },
        )
    },
    exitTransition = {
        slideOutOfContainer(
            towards = AnimatedContentTransitionScope.SlideDirection.Right,
            animationSpec = tween(durationMillis = 250, delayMillis = 100, easing = FastOutLinearInEasing),
            targetOffset = { -it/2 },
        )
    },
    popEnterTransition = {
        slideIntoContainer(
            towards = AnimatedContentTransitionScope.SlideDirection.Left,
            animationSpec = tween(durationMillis = 250, delayMillis = 100, easing = LinearOutSlowInEasing),
            initialOffset = { -it/2 },
        )
    },
    popExitTransition = {
        slideOutOfContainer(
            towards = AnimatedContentTransitionScope.SlideDirection.Right,
            animationSpec = tween(durationMillis = 250, delayMillis = 100, easing = FastOutLinearInEasing),
            targetOffset = { it },
        )
    }
)
