package dev.dexkot.mobile.core.ui.compose.screen

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import dev.dexkot.mobile.core.permission.controller.IPermissionController
import dev.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import dev.dexkot.mobile.core.ui.compose.logger.LocalLogger
import dev.dexkot.mobile.core.ui.compose.logger.Logger
import dev.dexkot.mobile.core.ui.compose.navigation.NavigationSubscriber
import dev.dexkot.mobile.core.ui.compose.permission.PermissionController
import dev.dexkot.mobile.core.ui.compose.permission.withLogging
import dev.dexkot.mobile.core.ui.compose.remoteconfig.RemoteConfig
import dev.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import dev.dexkot.mobile.core.ui.navigation.action.INavActionLogDecorator
import dev.dexkot.mobile.core.ui.navigation.action.withLogging
import dev.dexkot.mobile.core.ui.navigation.graph.Route
import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator

@Composable
internal fun <Model, Intention> Screen(
    route: Route<Model, Intention>,
    navigator: INavigator,
    permissionController: IPermissionController,
    dispatcher: INavActionDispatcher,
    remoteConfigProvider: IRemoteConfigProvider,
    loggerFactory: (sourceComponent: String) -> ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) {

    RemoteConfig(
        remoteConfigProvider = remoteConfigProvider
    ) {

        Logger(
            loggerInteractor = loggerFactory(route.identifier)
        ) {

            val logger = LocalLogger.current

            val loggedPermissionController = remember(permissionController, logger) {
                permissionController.withLogging(logger)
            }

            PermissionController(
                permissionController = loggedPermissionController
            ) {

                val loggingDispatcher = remember(dispatcher, logger) {
                    dispatcher.withLogging(logger, decorators)
                }

                val viewModel = route.viewModelFactory()

                NavigationSubscriber(
                    viewModel = viewModel,
                    navigator = navigator,
                    dispatcher = loggingDispatcher
                )

                route.screenContent(viewModel)

            }

        }

    }

}
