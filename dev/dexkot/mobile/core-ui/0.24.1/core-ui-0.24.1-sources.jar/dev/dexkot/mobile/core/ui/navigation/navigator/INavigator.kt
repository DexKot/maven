package dev.dexkot.mobile.core.ui.navigation.navigator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContract
import androidx.core.net.toUri
import androidx.navigation.NavHostController
import androidx.navigation.NavOptionsBuilder

interface INavigator {

    companion object {
        const val RESULT_KEY = "result"
    }

    val activity: Activity

    val navHostController: NavHostController

    val deepLinkScheme: String

    fun popBackStack(
        result: Bundle? = null
    )

    fun navigate(
        uri: Uri,
        args: Bundle? = null,
        builder: NavOptionsBuilder.() -> Unit = { }
    )

    fun navigate(
        uri: String,
        args: Bundle? = null,
        builder: NavOptionsBuilder.() -> Unit = { }
    ) = navigate(
        uri = "$deepLinkScheme://$uri".toUri(),
        args = args,
        builder = builder
    )

    fun navigate(
        builder: Activity.() -> Intent
    )

    fun navigate(
        intent: Intent
    )

    fun <Input, Output> navigateForResult(
        contract: ActivityResultContract<Input, Output>,
        launch: (Activity, (Input) -> Unit) -> Unit
    )

    fun onActivityResult(
        activityResult: ActivityResult
    )

}
