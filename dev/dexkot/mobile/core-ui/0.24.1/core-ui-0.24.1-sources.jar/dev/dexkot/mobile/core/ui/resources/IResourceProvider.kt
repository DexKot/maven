package dev.dexkot.mobile.core.ui.resources

import androidx.annotation.StringRes

interface IResourceProvider {

    fun getString(
        @StringRes id: Int
    ): String

    fun getString(
        @StringRes resId: Int,
        vararg formatArgs: Any
    ): String

}
