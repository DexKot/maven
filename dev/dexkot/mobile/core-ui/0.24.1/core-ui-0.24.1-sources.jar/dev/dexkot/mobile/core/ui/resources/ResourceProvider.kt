package dev.dexkot.mobile.core.ui.resources

import android.content.Context
import androidx.annotation.StringRes

class ResourceProvider(
    private val context: Context
): IResourceProvider {

    override fun getString(
        @StringRes id: Int
    ): String {
        return context.getString(id)
    }

    override fun getString(
        @StringRes resId: Int,
        vararg formatArgs: Any
    ): String {
        return context.getString(resId, *formatArgs)
    }

}
