package dev.dexkot.mobile.core.ui.compose.remoteconfig

import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json

object DummyRemoteConfigHandler: IRemoteConfigHandler {

    override val serializer: Json = Json

    override suspend fun sync(): ResultOf<Boolean> {
        return ResultOf.Success(true)
    }

    override fun getBoolean(
        key: String
    ): ResultOf<Boolean> {
        return ResultOf.Success(false)
    }

    override fun getString(
        key: String
    ): ResultOf<String> {
        return ResultOf.Success("")
    }

    override fun getBooleanFlow(
        key: String,
        defaultValue: Boolean
    ): StateFlow<Boolean> {
        return MutableStateFlow(defaultValue).asStateFlow()
    }

    override fun getLongFlow(
        key: String,
        defaultValue: Long
    ): StateFlow<Long> {
        return MutableStateFlow(defaultValue).asStateFlow()
    }

    override fun getStringFlow(
        key: String,
        defaultValue: String
    ): StateFlow<String> {
        return MutableStateFlow(defaultValue).asStateFlow()
    }

    override fun getLong(
        key: String
    ): ResultOf<Long> {
        return ResultOf.Success(0L)
    }

}
