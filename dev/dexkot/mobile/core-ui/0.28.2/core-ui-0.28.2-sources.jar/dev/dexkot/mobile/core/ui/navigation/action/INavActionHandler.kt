package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator
import kotlin.reflect.KClass

/**
 * Ejecuta la navegación de un tipo de [INavAction].
 *
 * Se registra en Koin (multi-binding) y el [NavActionDispatcher] lo resuelve por [actionType].
 * Las dependencias que la navegación necesita (preferences, remote config, …) se inyectan por
 * constructor. Es una instancia compartida: no debe guardar estado de una navegación concreta.
 */
interface INavActionHandler<T : INavAction> {

    val actionType: KClass<T>

    fun handle(action: T, navigator: INavigator)

}
