package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator
import kotlin.reflect.KClass

class NavActionDispatcher(
    handlers: List<INavActionHandler<*>>
) : INavActionDispatcher {

    private val handlerMap: Map<KClass<*>, INavActionHandler<*>> =
        handlers.associateBy { it.actionType }

    @Suppress("UNCHECKED_CAST")
    override fun dispatch(action: INavAction, navigator: INavigator) {
        val handler = handlerMap[action::class]
            ?: error("No INavActionHandler registered for ${action::class.qualifiedName}")
        (handler as INavActionHandler<INavAction>).handle(action, navigator)
    }

}
