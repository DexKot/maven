package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import kotlin.reflect.KClass

/**
 * Registra en analytics la navegación de un tipo de [INavAction]. Lo genera `@AutoLogNavAction`
 * y lo invoca [LoggingNavActionDispatcher] antes de delegar la navegación.
 */
interface INavActionLogDecorator {

    val actionType: KClass<out INavAction>

    fun log(
        action: INavAction,
        logger: ILoggerInteractor
    )

}
