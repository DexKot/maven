package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator
import kotlin.reflect.KClass

internal class LoggingNavActionDispatcher(
    private val delegate: INavActionDispatcher,
    private val logger: ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) : INavActionDispatcher {

    private val decoratorMap: Map<KClass<*>, INavActionLogDecorator> =
        decorators.associateBy { it.actionType }

    override fun dispatch(action: INavAction, navigator: INavigator) {
        decoratorMap[action::class]?.log(action, logger)
        delegate.dispatch(action, navigator)
    }

}

fun INavActionDispatcher.withLogging(
    logger: ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
): INavActionDispatcher = LoggingNavActionDispatcher(this, logger, decorators)
