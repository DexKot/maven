package dev.dexkot.mobile.core.ui.navigation.action

import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator

interface INavActionDispatcher {

    fun dispatch(action: INavAction, navigator: INavigator)

}
