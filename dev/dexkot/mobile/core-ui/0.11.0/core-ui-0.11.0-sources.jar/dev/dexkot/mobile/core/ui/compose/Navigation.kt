package dev.dexkot.mobile.core.ui.compose

import androidx.compose.runtime.Composable
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navDeepLink
import androidx.navigation.navigation
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import dev.dexkot.mobile.core.permission.controller.IPermissionController
import dev.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import dev.dexkot.mobile.core.ui.compose.logger.DummyLoggerInteractor
import dev.dexkot.mobile.core.ui.compose.remoteconfig.DummyRemoteConfigProvider
import dev.dexkot.mobile.core.ui.compose.screen.Screen
import dev.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import dev.dexkot.mobile.core.ui.navigation.action.INavActionLogDecorator
import dev.dexkot.mobile.core.ui.navigation.graph.Graph
import dev.dexkot.mobile.core.ui.navigation.graph.Route
import dev.dexkot.mobile.core.ui.navigation.navigator.INavigator
import dev.dexkot.mobile.core.ui.navigation.splash.splashScreen

@Composable
fun FragmentActivity.Navigation(
    graphs: List<Graph>,
    navigator: INavigator,
    dispatcher: INavActionDispatcher,
    permissionController: IPermissionController,
    remoteConfigProvider: IRemoteConfigProvider = DummyRemoteConfigProvider,
    loggerFactory: (sourceComponent: String) -> ILoggerInteractor = { DummyLoggerInteractor },
    decorators: List<INavActionLogDecorator> = emptyList(),
    removeSplash: () -> Unit = { },
    startDestination: Graph = graphs.first()
) {

    NavHost(
        navController = navigator.navHostController,
        startDestination = startDestination.route
    ) {
        graphs(
            graphs = graphs,
            navigator = navigator,
            permissionController = permissionController,
            dispatcher = dispatcher,
            remoteConfigProvider = remoteConfigProvider,
            loggerFactory = loggerFactory,
            decorators = decorators
        )
    }

    navigator.navHostController.splashScreen(
        route = startDestination.startDestination.route,
        removeSplash = removeSplash
    )

}

private fun NavGraphBuilder.graphs(
    graphs: List<Graph>,
    navigator: INavigator,
    permissionController: IPermissionController,
    dispatcher: INavActionDispatcher,
    remoteConfigProvider: IRemoteConfigProvider,
    loggerFactory: (sourceComponent: String) -> ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) {
    graphs.forEach { graph ->
        graph(
            graph = graph,
            navigator = navigator,
            permissionController = permissionController,
            dispatcher = dispatcher,
            remoteConfigProvider = remoteConfigProvider,
            loggerFactory = loggerFactory,
            decorators = decorators
        )
    }
}

private fun NavGraphBuilder.graph(
    graph: Graph,
    navigator: INavigator,
    permissionController: IPermissionController,
    dispatcher: INavActionDispatcher,
    remoteConfigProvider: IRemoteConfigProvider,
    loggerFactory: (sourceComponent: String) -> ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) {
    navigation(
        startDestination = graph.startDestination.route,
        route = graph.route
    ) {
        routes(
            routes = graph.routes,
            navigator = navigator,
            permissionController = permissionController,
            dispatcher = dispatcher,
            remoteConfigProvider = remoteConfigProvider,
            loggerFactory = loggerFactory,
            decorators = decorators
        )
    }
}

private fun NavGraphBuilder.routes(
    routes: List<Route<*, *>>,
    navigator: INavigator,
    permissionController: IPermissionController,
    dispatcher: INavActionDispatcher,
    remoteConfigProvider: IRemoteConfigProvider,
    loggerFactory: (sourceComponent: String) -> ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) {
    routes.forEach { route ->
        route(
            route = route,
            navigator = navigator,
            permissionController = permissionController,
            dispatcher = dispatcher,
            remoteConfigProvider = remoteConfigProvider,
            loggerFactory = loggerFactory,
            decorators = decorators
        )
    }
}

private fun <Model, Intention> NavGraphBuilder.route(
    route: Route<Model, Intention>,
    navigator: INavigator,
    permissionController: IPermissionController,
    dispatcher: INavActionDispatcher,
    remoteConfigProvider: IRemoteConfigProvider,
    loggerFactory: (sourceComponent: String) -> ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) {

    composable(
        route = route.route,
        arguments = route.arguments,
        deepLinks = route.deepLinks.map {
            navDeepLink { uriPattern = "${navigator.deepLinkScheme}://${it.uriPattern}" }
        },
        enterTransition = route.transitions.enterTransition,
        exitTransition = route.transitions.exitTransition,
        popEnterTransition = route.transitions.popEnterTransition,
        popExitTransition = route.transitions.popExitTransition
    ) {

        Screen(
            route = route,
            navigator = navigator,
            permissionController = permissionController,
            dispatcher = dispatcher,
            remoteConfigProvider = remoteConfigProvider,
            loggerFactory = loggerFactory,
            decorators = decorators
        )

    }

}
