package dev.dexkot.mobile.core.ui.viewmodel.android

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewModelScope as baseViewModelScope
import dev.dexkot.mobile.core.ui.navigation.action.INavAction
import dev.dexkot.mobile.core.ui.viewmodel.IScreenViewModel
import dev.dexkot.mobile.core.ui.viewmodel.event.Event
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.reflect.KClass

abstract class AndroidViewModel<Model, Intention>: IScreenViewModel<Model, Intention>, ViewModel() {

    private var _additionalContext: CoroutineContext = EmptyCoroutineContext
    private var _scopeWithContext: CoroutineScope? = null

    fun addCoroutineContext(context: CoroutineContext) {
        _additionalContext += context
        _scopeWithContext = null
    }

    protected val viewModelScope: CoroutineScope
        get() {
            if (_additionalContext === EmptyCoroutineContext) return baseViewModelScope
            return _scopeWithContext
                ?: CoroutineScope(baseViewModelScope.coroutineContext + _additionalContext)
                    .also { _scopeWithContext = it }
        }

    private val _nav: MutableStateFlow<Event<INavAction>?> = MutableStateFlow(null)
    override val nav = _nav.asStateFlow()

    protected fun emit(action: INavAction) {
        _nav.value = Event(action)
    }

    /**
     * Ata el ciclo de vida de [delegate] al de este ViewModel: cuando este se limpia, [delegate]
     * también (se cierran sus closeables, se cancela su `viewModelScope` y se llama su `onCleared`).
     *
     * Existe para los decoradores (p. ej. el que genera `@AutoLogViewModel`): el ViewModelStore guarda
     * solo al decorador, y sin esto el ViewModel envuelto nunca se limpiaría. `ViewModel.clear()` es
     * interno de androidx, así que [delegate] se registra en un [ViewModelStore] propio cuyo
     * `clear()` público hace la limpieza completa.
     *
     * Llamar una sola vez por [delegate], típicamente desde el `init` del decorador.
     */
    protected fun clearTogetherWith(delegate: ViewModel) {
        val store = ViewModelStore()
        val factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: KClass<T>, extras: CreationExtras): T =
                delegate as T
        }
        @Suppress("UNCHECKED_CAST")
        ViewModelProvider.create(store, factory)[DELEGATE_KEY, delegate::class as KClass<ViewModel>]
        addCloseable { store.clear() }
    }

    protected fun <T> Flow<T>.stateFlow(
        coroutineScope: CoroutineScope = viewModelScope,
        started: SharingStarted = SharingStarted.WhileSubscribed(),
        initialValue: T
    ) = this.stateIn(coroutineScope, started, initialValue)


    private companion object {
        const val DELEGATE_KEY = "dev.dexkot.mobile.core.ui.viewmodel.android.AndroidViewModel.delegate"
    }

}
