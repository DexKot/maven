package dev.dexkot.mobile.core.ui.compose.state

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf

/**
 * Crea un [MutableState] observable por Compose que, en cada escritura, también invoca [setValue].
 *
 * Pensado para las clases `@Parcelize` de estado de UI (ScreenState / UiState): el campo de
 * respaldo del constructor es lo que se parcela y sobrevive a la muerte del proceso, mientras que la
 * propiedad expuesta es reactiva para Compose.
 *
 * ```kotlin
 * @Parcelize
 * @Stable
 * @UiState
 * class DialogUiState(private var _isVisible: Boolean = false) : Parcelable {
 *
 *     @IgnoredOnParcel
 *     var isVisible by fieldMutableStateOf(_isVisible) { _isVisible = it }
 * }
 * ```
 *
 * Toda escritura pasa por [setValue], incluida la hecha con el setter obtenido por
 * desestructuración (`val (value, setValue) = state`).
 *
 * @param initialValue valor inicial; normalmente, el del campo de respaldo.
 * @param setValue callback que sincroniza el campo de respaldo. Se invoca antes de actualizar el
 * estado observable.
 */
fun <T> fieldMutableStateOf(
    initialValue: T,
    setValue: (T) -> Unit,
): MutableState<T> = FieldMutableState(
    internalState = mutableStateOf(initialValue),
    onSet = setValue,
)

/**
 * No delega con `by internalState`: [MutableState.component2] quedaría delegado al estado interno
 * y el setter desestructurado se saltearía [onSet].
 */
private class FieldMutableState<T>(
    private val internalState: MutableState<T>,
    private val onSet: (T) -> Unit,
) : MutableState<T> {

    override var value: T
        get() = internalState.value
        set(value) {
            onSet(value)
            internalState.value = value
        }

    override fun component1(): T = value

    override fun component2(): (T) -> Unit = { value = it }

}
