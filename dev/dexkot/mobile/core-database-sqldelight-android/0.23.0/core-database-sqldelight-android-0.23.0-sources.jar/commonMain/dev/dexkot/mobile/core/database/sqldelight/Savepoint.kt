package dev.dexkot.mobile.core.database.sqldelight

import app.cash.sqldelight.db.SqlDriver
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

internal class Savepoint(
    private val name: String = generateRandomName(),
    private val sqlDriver: SqlDriver
) {

    suspend fun start() {
        sqlDriver.execute(null, "SAVEPOINT $name;", 0).await()
    }

    suspend fun release() {
        sqlDriver.execute(null, "RELEASE SAVEPOINT $name;", 0).await()
    }

    suspend fun rollback() {
        sqlDriver.execute(null, ";ROLLBACK TO $name;", 0).await()
    }

    private companion object {

        @OptIn(ExperimentalUuidApi::class)
        fun generateRandomName(): String {
            return "savepoint_${Uuid.random().toString().replace("-","")}"
        }

    }

}
