package dev.dexkot.mobile.core.database.sqldelight

import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext

/**
 * Marks the transaction in progress inside the coroutine context.
 *
 * [TransactionFactory] finds it with `coroutineContext[TransactionContextElement]` to decide that a
 * nested `withTransaction` must join the outer one. Because it is a regular context element, it is
 * inherited across a `withContext` — which is why a data source can do
 * `withContext(Dispatchers.IO) { withTransaction { ... } }` and the nesting is still detected.
 *
 * Reaching the transaction from *non-suspend* code is handled separately by
 * [transactionThreadContextElement], which mirrors it into a thread local exposed through [current].
 */
internal class TransactionContextElement(
    val transaction: Transaction<*>
) : AbstractCoroutineContextElement(Key) {

    companion object Key : CoroutineContext.Key<TransactionContextElement> {

        fun current(): Transaction<*>? = currentThreadTransaction()
    }
}
