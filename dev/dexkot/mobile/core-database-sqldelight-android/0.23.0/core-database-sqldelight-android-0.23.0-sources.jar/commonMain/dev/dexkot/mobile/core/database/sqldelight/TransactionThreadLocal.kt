package dev.dexkot.mobile.core.database.sqldelight

/**
 * Per-thread storage for the transaction currently in progress.
 *
 * Backs [TransactionContextElement.current], which exposes the active transaction to non-suspend
 * code running on the transaction's thread — something `coroutineContext[Key]` cannot do, since it
 * is only reachable from suspend functions.
 *
 * `expect`/`actual` because the storage differs per platform: `java.lang.ThreadLocal` on JVM/Android
 * and a `@ThreadLocal` holder on Native. (kotlinx.coroutines' `ThreadContextElement`, the usual way
 * to mirror context into a thread local, is JVM-only, so [Transaction] sets and clears this binding
 * explicitly around the transaction block instead.)
 */
internal expect fun currentThreadTransaction(): Transaction<*>?

internal expect fun setCurrentThreadTransaction(value: Transaction<*>?)
