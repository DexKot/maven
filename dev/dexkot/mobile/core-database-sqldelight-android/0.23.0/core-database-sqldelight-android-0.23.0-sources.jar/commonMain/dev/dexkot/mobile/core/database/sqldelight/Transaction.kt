package dev.dexkot.mobile.core.database.sqldelight

import app.cash.sqldelight.SuspendingTransactionWithReturn
import app.cash.sqldelight.db.SqlDriver
import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.errors.ErrorEntity
import dev.dexkot.mobile.core.foundation.result.map
import dev.dexkot.mobile.core.database.transaction.ITransaction
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

internal class Transaction<Output>(
    private val dispatcher: CoroutineDispatcher,
    private val sqlDriver: SqlDriver,
    private val sqlTransaction: SuspendingTransactionWithReturn<ResultOf<Output>>
): ITransaction<Output> {

    override suspend fun rollback(failure: ResultOf.Failure<*>): Nothing {
        try {
            sqlTransaction.rollback(failure.map())
        } catch (ignored: Throwable) {
            throw RollbackException(failure = failure)
        }
    }

    override suspend fun <Out> execute(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out> {
        return withContext(asCoroutineContext()) {
            // Bind this transaction to the thread it runs on so non-suspend code invoked inside the
            // block can reach it via TransactionContextElement.current(). The block is confined to
            // the transaction's dedicated dispatcher, so the binding stays valid across suspensions;
            // the previous value is restored to keep nested transactions consistent.
            val previous = currentThreadTransaction()
            setCurrentThreadTransaction(this@Transaction)
            try {
                block()
            } catch (exception: RollbackException) {
                throw exception
            } catch (exception: Throwable) {
                rollback(
                    failure = ResultOf.Failure<Out>(
                        error = ErrorEntity.UnexpectedError(
                            exception = exception
                        )
                    )
                )
            } finally {
                setCurrentThreadTransaction(previous)
            }
        }
    }

    override suspend fun <Out> innerTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out> {
        return withContext(asCoroutineContext()) {
            val savepoint = Savepoint(sqlDriver = sqlDriver)
            try {
                savepoint.start()
                execute(block)
            } catch (exception: Throwable) {
                savepoint.rollback()
                throw exception
            } finally {
                savepoint.release()
            }
        }
    }

    private fun asCoroutineContext(): CoroutineContext {
        return dispatcher + TransactionContextElement(transaction = this)
    }

}
