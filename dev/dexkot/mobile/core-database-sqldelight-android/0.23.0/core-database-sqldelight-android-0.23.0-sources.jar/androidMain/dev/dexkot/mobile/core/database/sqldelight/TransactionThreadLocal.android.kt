package dev.dexkot.mobile.core.database.sqldelight

private val threadLocal = ThreadLocal<Transaction<*>?>()

internal actual fun currentThreadTransaction(): Transaction<*>? = threadLocal.get()

internal actual fun setCurrentThreadTransaction(value: Transaction<*>?) {
    threadLocal.set(value)
}
