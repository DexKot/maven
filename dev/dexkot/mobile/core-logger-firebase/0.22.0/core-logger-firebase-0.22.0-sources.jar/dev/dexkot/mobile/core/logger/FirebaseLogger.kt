package dev.dexkot.mobile.core.logger

import android.os.Bundle
import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import dev.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import dev.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import dev.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import dev.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import dev.dexkot.mobile.core.logger.events.ui.state.UiStateEvent
import dev.dexkot.mobile.core.logger.levels.Level
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics

class FirebaseLogger(
    private val analytics: FirebaseAnalytics,
    private val crashlytics: FirebaseCrashlytics
): ILogger {

    override fun setUserId(identifier: String) {
        analytics.setUserId(identifier)
        crashlytics.setUserId(identifier)
    }

    override fun removeUserId() {
        analytics.setUserId(null)
        crashlytics.setUserId("")
    }

    override fun setUserProperty(key: String, value: String?) {
        analytics.setUserProperty(key, value)
    }

    override fun removeUserProperty(key: String) {
        analytics.setUserProperty(key, null)
    }

    override fun log(event: LogEvent) {
        when (event) {
            is InteractionEvent -> analytics.logEvent(
                event.type,
                event.properties(),
            )
            is ScreenEvent -> analytics.logEvent(
                event.type,
                event.properties(),
            )
            is NavigationEvent -> analytics.logEvent(
                event.type,
                event.properties(),
            )
            is OperationEvent -> analytics.logEvent(
                event.type,
                event.properties(),
            )
            is PermissionEvent -> analytics.logEvent(
                event.type,
                event.properties(),
            )
            is IntentionEvent -> analytics.logEvent(
                event.type,
                event.properties(),
            )
            is UiStateEvent -> analytics.logEvent(
                event.type,
                event.properties(),
            )
        }
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) = Unit

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        message?.let { crashlytics.log(it) }
        params.forEach { param -> setCustomKey(param.key, param.value) }
        crashlytics.recordException(throwable)
    }

    private fun InteractionEvent.properties(): Bundle = buildBundle {
        putString("source", sourceComponent)
        putString("element_id", elementId)
        putString("interaction", interaction.value)
        extras.forEach { (key, value) -> putString("extra_$key", value) }
    }

    private fun ScreenEvent.properties(): Bundle = buildBundle {
        putString("source", sourceComponent)
        putString("action", action.value)
    }

    private fun NavigationEvent.properties(): Bundle = buildBundle {
        putString("source", sourceComponent)
        putString("navigation_id", navigationId)
        params.forEach { (key, value) -> putString("parameter_$key", value.toString()) }
    }

    private fun OperationEvent.properties(): Bundle = buildBundle {
        putString("source", sourceComponent)
        putString("operation_id", operationId)
        putString("status", status.value)
        params.forEach { (key, value) -> putString("parameter_$key", value) }
    }

    private fun PermissionEvent.properties(): Bundle = buildBundle {
        putString("source", sourceComponent)
        permissions.forEach { (key, value) -> putString("permission_$key", value.value) }
    }

    private fun IntentionEvent.properties(): Bundle = buildBundle {
        putString("source", sourceComponent)
        putString("intention_id", intentionId)
        params.forEach { (key, value) -> putString("parameter_$key", value) }
    }

    private fun UiStateEvent.properties(): Bundle = buildBundle {
        putString("source", sourceComponent)
        putString("element_id", elementId)
        putString("state", state.value)
        extras.forEach { (key, value) -> putString("extra_$key", value) }
    }

    private fun buildBundle(block: Bundle.() -> Unit): Bundle = Bundle().apply(block)

    private fun setCustomKey(key: String, value: Any) {
        when (value) {
            is String -> crashlytics.setCustomKey(key, value)
            is Boolean -> crashlytics.setCustomKey(key, value)
            is Int -> crashlytics.setCustomKey(key, value)
            is Long -> crashlytics.setCustomKey(key, value)
            is Float -> crashlytics.setCustomKey(key, value)
            is Double -> crashlytics.setCustomKey(key, value)
            else -> crashlytics.setCustomKey(key, value.toString())
        }
    }

}
