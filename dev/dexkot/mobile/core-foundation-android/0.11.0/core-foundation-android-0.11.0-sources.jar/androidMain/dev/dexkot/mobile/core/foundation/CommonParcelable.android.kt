package dev.dexkot.mobile.core.foundation

actual typealias CommonParcelable = android.os.Parcelable
