package dev.dexkot.mobile.core.foundation.data.preferences

class SavePreferencesException: RuntimeException(
    "Error while saving preferences."
)
