package dev.dexkot.mobile.core.foundation.data.policies

enum class CacheFetchPolicy {

    /**
     * Returns values from the cache, or throws an error if not available. It won't initiate a fetch.
     */
    CACHE_ONLY,

    /**
     * Ignore whether the cache has a value or not and fetch the most up-to-date data. This will return an error if the fetch request fails
     */
    FETCH_CURRENT,

    /**
     * Returns the cached data if available. If not available, fetches up-to-date data.
     */
    CACHED_OR_FETCHED,

    /**
     * Fetches the most up-to-date data and returns it. If the fetch fails, it returns the cached data if available.
     */
    FETCHED_OR_CACHED

}