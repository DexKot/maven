package dev.dexkot.mobile.core.foundation

expect interface CommonParcelable
