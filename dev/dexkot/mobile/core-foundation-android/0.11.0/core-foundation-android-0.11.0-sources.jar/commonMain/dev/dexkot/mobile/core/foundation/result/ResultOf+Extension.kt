package dev.dexkot.mobile.core.foundation.result

import dev.dexkot.mobile.core.foundation.errors.ErrorEntity

/**
 * This function simplifies getting the data from a ResultOf without having to check if it is a Success or a Failure.
 */
fun <Data> ResultOf<Data>.unwrap(): Data? {
    return when (this) {
        is ResultOf.Success -> data
        is ResultOf.Failure -> null
    }
}

/**
 * This function simplifies the logic of fetching a value from a ResultOf and using a default value if the result has no data.
 */
fun <Data> ResultOf<Data>.getOrDefault(
    defaultValue: Data
): Data {
    return unwrap() ?: defaultValue
}

/**
 * This function simplifies the logic of fetching a value from a ResultOf and using a default value if the result has no data.
 */
fun <Data, Other> ResultOf<Data>.map(converter: (Data) -> Other): ResultOf<Other> {
    return when (this) {
        is ResultOf.Success -> map(converter = converter)
        is ResultOf.Failure -> map()
    }
}

/**
 * This function transforms a success result into another success result with a different data type.
 */
fun <Data, Other> ResultOf.Success<Data>.map(converter: (Data) -> Other): ResultOf<Other> {
    return ResultOf.Success(data = converter(this.data))
}

/**
 * This function transforms a failure result into another failure result with a different data type.
 */
fun <Other> ResultOf.Failure<*>.map(): ResultOf.Failure<Other> {
    return ResultOf.Failure(error = this.error)
}

/**
 * This function returns a success result with the given data.
 */
fun <T> successOf(data: T): ResultOf.Success<T> {
    return ResultOf.Success(data)
}

/**
 * This function returns a success result with no data.
 */
fun successOf(): ResultOf.Success<Unit> {
    return ResultOf.Success(Unit)
}

/**
 * This function returns a failure result with the given exception.
 */
fun <T> failureOf(throwable: Throwable? = null): ResultOf.Failure<T> {
    return ResultOf.Failure(ErrorEntity.UnexpectedError(throwable))
}

/**
 * This function returns a failure result with the given error.
 */
fun <T> failureOf(error: ErrorEntity): ResultOf.Failure<T> {
    return ResultOf.Failure(error)
}