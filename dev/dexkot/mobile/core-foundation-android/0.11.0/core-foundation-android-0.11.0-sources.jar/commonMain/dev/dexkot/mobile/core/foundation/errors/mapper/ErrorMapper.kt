package dev.dexkot.mobile.core.foundation.errors.mapper

import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.errors.ErrorEntity
import dev.dexkot.mobile.core.foundation.errors.unexpectedError
import dev.dexkot.mobile.core.foundation.result.failureOf

interface ErrorMapper {

    /**
     * Handles the given [Throwable] and returns a [ResultOf.Failure] containing an [ErrorEntity].
     *
     * @param T The type of the result.
     * @param throwable The error to handle.
     * @return A [ResultOf.Failure] containing the mapped [ErrorEntity].
     */
    fun <T> handle(
        throwable: Throwable
    ): ResultOf.Failure<T> {
        val error = map(throwable)
        return if (error != null)
            failureOf(error)
        else
            failureOf(unexpectedError(throwable))
    }

    /**
     * Maps the given [Throwable] to a [ErrorEntity].
     *
     * @param throwable The error to map.
     * @return The mapped [ErrorEntity].
     */
    fun map(
        throwable: Throwable
    ): ErrorEntity?

    /**
     * This operator (+) allows us to concatenate two or more [ErrorMapper] into a chain of mappers [ErrorMapperChain].
     *
     * val completeMapper = firstMapper + secondMapper + .... + lastMapper
     *
     * If the firstMapper does not know how to map a [Throwable], then the secondMapper is invoked, and the third... until the last one.
     * If the lastMapper can not map the [Throwable], then return a [ResultOf.Failure] with an [ErrorEntity.UnexpectedError].
     */
    operator fun plus(
        otherMapper: ErrorMapper
    ): ErrorMapper {
        return ErrorMapperChain(
            head = this,
            tail = otherMapper
        )
    }

}