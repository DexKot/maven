package dev.dexkot.mobile.core.foundation.coroutines

import kotlinx.coroutines.CoroutineDispatcher

/**
 * Cross-platform set of coroutine dispatchers.
 *
 * kotlinx.coroutines only exposes [kotlinx.coroutines.Dispatchers.IO] as public API on the JVM
 * (it is `internal` on Native), so this abstraction provides an `io` dispatcher on every platform:
 * `Dispatchers.IO` on Android and a GCD global-queue dispatcher on iOS.
 */
interface PlatformDispatcher {
    val main: CoroutineDispatcher
    val io: CoroutineDispatcher
    val default: CoroutineDispatcher
    val unconfined: CoroutineDispatcher
}

expect object PlatformDispatchers : PlatformDispatcher {
    override val main: CoroutineDispatcher
    override val io: CoroutineDispatcher
    override val default: CoroutineDispatcher
    override val unconfined: CoroutineDispatcher
}
