package dev.dexkot.mobile.core.foundation

actual interface CommonParcelable
