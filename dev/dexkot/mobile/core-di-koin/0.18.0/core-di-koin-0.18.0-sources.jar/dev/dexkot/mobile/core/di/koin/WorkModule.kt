package dev.dexkot.mobile.core.di.koin

import androidx.work.WorkManager
import dev.dexkot.mobile.core.work.data.config.WorkTypeConfigFactory
import dev.dexkot.mobile.core.work.data.executor.WorkExecutorFactory
import dev.dexkot.mobile.core.work.data.notification.WorkNotificationFactory
import dev.dexkot.mobile.core.work.data.worker.GenericWorkManagerWorker
import dev.dexkot.mobile.core.work.domain.config.IWorkTypeConfigFactory
import dev.dexkot.mobile.core.work.domain.config.IWorkTypeConfigProvider
import dev.dexkot.mobile.core.work.domain.constraint.ConstraintChangeListener
import dev.dexkot.mobile.core.work.domain.constraint.ConstraintChecker
import dev.dexkot.mobile.core.work.domain.executor.IWorkExecutorFactory
import dev.dexkot.mobile.core.work.domain.executor.IWorkExecutorProvider
import dev.dexkot.mobile.core.work.domain.notification.IWorkNotificationFactory
import dev.dexkot.mobile.core.work.domain.notification.IWorkNotificationProvider
import dev.dexkot.mobile.core.work.domain.usecase.ICancelWorkUseCase
import dev.dexkot.mobile.core.work.domain.usecase.IObserveWorkStatusUseCase
import dev.dexkot.mobile.core.work.domain.usecase.IScheduleWorkUseCase
import dev.dexkot.mobile.core.work.domain.usecase.CancelWorkUseCase
import dev.dexkot.mobile.core.work.domain.usecase.ObserveWorkStatusUseCase
import dev.dexkot.mobile.core.work.domain.usecase.ScheduleWorkUseCase
import dev.dexkot.mobile.core.work.domain.worker.WorkerCoroutineContextFactory
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.workmanager.dsl.worker
import org.koin.dsl.module

/**
 * Registra el grafo completo de `core-work` (WorkManager, factories, worker genérico y use cases).
 *
 * Es wiring invariante — no tiene nada configurable por app. Los providers pluggables
 * ([IWorkTypeConfigProvider], [IWorkExecutorProvider], [IWorkNotificationProvider]) los registra
 * la app / feature modules; este módulo solo los colecta con `getAll`.
 *
 * El consumidor debe seguir llamando `workManagerFactory()` en `startKoin` (instala el
 * `KoinWorkerFactory`); este módulo aporta las definiciones + el `worker`.
 */
fun workModule() = module {

    single { WorkManager.getInstance(androidContext()) }

    single<IWorkTypeConfigFactory> {
        WorkTypeConfigFactory(delegates = getAll<IWorkTypeConfigProvider>())
    }
    single<IWorkExecutorFactory> {
        WorkExecutorFactory(providers = getAll<IWorkExecutorProvider>())
    }
    single<IWorkNotificationFactory> {
        WorkNotificationFactory(providers = getAll<IWorkNotificationProvider>())
    }

    worker {
        GenericWorkManagerWorker(
            context = get(),
            params = get(),
            executorFactory = get(),
            notificationFactory = get(),
            permissionChecker = get(),
            coroutineContextFactory = getOrNull<WorkerCoroutineContextFactory>()
        )
    }

    single<IScheduleWorkUseCase> {
        ScheduleWorkUseCase(workManager = get(), configProvider = get())
    }
    single<ICancelWorkUseCase> {
        CancelWorkUseCase(context = androidContext(), workManager = get())
    }
    single { ConstraintChecker(context = androidContext()) }
    single { ConstraintChangeListener(context = androidContext()) }
    single<IObserveWorkStatusUseCase> {
        ObserveWorkStatusUseCase(
            workManager = get(),
            configFactory = get(),
            constraintChecker = get(),
            constraintChangeListener = get()
        )
    }

}
