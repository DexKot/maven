package dev.dexkot.mobile.core.di.koin

import dev.dexkot.mobile.core.logger.ConsoleLogger
import dev.dexkot.mobile.core.logger.FirebaseLogger
import dev.dexkot.mobile.core.logger.ILogger
import dev.dexkot.mobile.core.logger.PostHogLogger
import dev.dexkot.mobile.core.logger.context.LoggerContextElement
import dev.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor as ILogicLoggerInteractor
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor as IUiLoggerInteractor
import dev.dexkot.mobile.core.logger.logicInteractor
import dev.dexkot.mobile.core.logger.uiInteractor
import org.koin.dsl.module

/**
 * Provee cada logger por separado (como su tipo concreto) y el interactor lógico "principal".
 *
 * DexKot NO compone el [ILogger]: eso es decisión de la app. La app debe registrar su propio
 * `single<ILogger> { ... }` combinando los loggers que le interesen, por ejemplo:
 *
 * ```kotlin
 * single<ILogger> { get<ConsoleLogger>() + get<FirebaseLogger>() + get<PostHogLogger>() }
 * ```
 *
 * El interactor lógico sí lo provee el core porque además hace [LoggerContextElement.setDefault],
 * un detalle interno que no debería filtrarse a la app. Consume el `ILogger` que la app compone.
 *
 * @param consoleLoggerTag tag con el que loguea el [ConsoleLogger] (default "Console").
 * @param logicSourceComponent sourceComponent del interactor lógico principal (default "app").
 */
fun loggerModule(
    consoleLoggerTag: String = "Console",
    logicSourceComponent: String = "app",
) = module {

    single { ConsoleLogger(tag = consoleLoggerTag) }

    single { FirebaseLogger() }

    single { PostHogLogger() }

    single<ILogicLoggerInteractor>(createdAtStart = true) {
        get<ILogger>().logicInteractor(logicSourceComponent).also {
            LoggerContextElement.setDefault(it)
        }
    }

    factory<IUiLoggerInteractor> { parameters ->
        get<ILogger>().uiInteractor(sourceComponent = parameters.get())
    }

}
