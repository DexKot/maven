package dev.dexkot.mobile.core.di.koin

import android.content.Context
import dev.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import dev.dexkot.mobile.core.ui.navigation.action.INavActionFactory
import dev.dexkot.mobile.core.ui.navigation.action.NavActionDispatcher
import dev.dexkot.mobile.core.ui.preferences.IUiPreferences
import dev.dexkot.mobile.core.ui.preferences.UiPreferences
import dev.dexkot.mobile.core.ui.resources.IResourceProvider
import dev.dexkot.mobile.core.ui.resources.ResourceProvider
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val UiModule = module {

    single<INavActionDispatcher> {
        NavActionDispatcher(
            factories = getAll<INavActionFactory<*>>()
        )
    }

    single<IUiPreferences> {
        UiPreferences(
            sharedPreferences = androidContext()
                .getSharedPreferences("dev.dexkot.ui.preferences", Context.MODE_PRIVATE)
        )
    }

    factory<IResourceProvider> {
        ResourceProvider(
            context = get()
        )
    }

}
