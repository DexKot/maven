package dev.dexkot.mobile.core.di.koin

import org.koin.core.module.Module

val CoreModule: List<Module> = listOf(
    LoggerModule,
    PermissionModule,
    RemoteConfigModule,
    UiModule
)
