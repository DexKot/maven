package dev.dexkot.mobile.core.di.koin

import dev.dexkot.mobile.core.logger.ConsoleLogger
import dev.dexkot.mobile.core.logger.FirebaseLogger
import dev.dexkot.mobile.core.logger.ILogger
import dev.dexkot.mobile.core.logger.PostHogLogger
import dev.dexkot.mobile.core.logger.composed.plus
import dev.dexkot.mobile.core.logger.context.LoggerContextElement
import dev.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor as ILogicLoggerInteractor
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor as IUiLoggerInteractor
import dev.dexkot.mobile.core.logger.logicInteractor
import dev.dexkot.mobile.core.logger.uiInteractor
import com.google.firebase.Firebase
import com.google.firebase.analytics.analytics
import com.google.firebase.crashlytics.crashlytics
import com.posthog.PostHog
import org.koin.core.qualifier.named
import org.koin.dsl.module

fun consoleLogger() = named("console_logger")
fun firebaseLogger() = named("firebase_logger")
fun postHogLogger() = named("posthog_logger")

val LoggerModule = module {

    single<ILogger>(consoleLogger()) {
        ConsoleLogger()
    }

    single<ILogger>(firebaseLogger()) {
        FirebaseLogger(
            analytics = Firebase.analytics,
            crashlytics = Firebase.crashlytics
        )
    }

    single<ILogger>(postHogLogger()) {
        PostHogLogger(PostHog)
    }

    single<ILogger> {
        get<ILogger>(consoleLogger()) +
            get<ILogger>(firebaseLogger()) +
            get<ILogger>(postHogLogger())
    }

    single<ILogicLoggerInteractor>(createdAtStart = true) {
        get<ILogger>().logicInteractor("app").also {
            LoggerContextElement.setDefault(it)
        }
    }

    factory<IUiLoggerInteractor> { parameters ->
        get<ILogger>().uiInteractor(sourceComponent = parameters.get())
    }

}
