package dev.dexkot.mobile.core.di.koin

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import androidx.activity.result.ActivityResultLauncher
import dev.dexkot.mobile.core.permission.checker.IPermissionChecker
import dev.dexkot.mobile.core.permission.checker.PermissionChecker
import dev.dexkot.mobile.core.permission.controller.PermissionController
import org.koin.android.ext.koin.androidContext
import org.koin.core.qualifier.named
import org.koin.dsl.module

fun permissionPreferences() = named("permission_preferences")

val PermissionModule = module {

    single<IPermissionChecker> {
        PermissionChecker(context = androidContext())
    }

    single<SharedPreferences>(permissionPreferences()) {
        androidContext()
            .getSharedPreferences("dev.dexkot.permissions.preferences", Context.MODE_PRIVATE)
    }

    factory { (
        activity: Activity,
        singlePermissionLauncher: ActivityResultLauncher<String>,
        multiplePermissionsLauncher: ActivityResultLauncher<Array<String>>
    ) ->
        PermissionController(
            activity = activity,
            preferences = get(permissionPreferences()),
            singlePermissionLauncher = singlePermissionLauncher,
            multiplePermissionsLauncher = multiplePermissionsLauncher
        )
    }

}
