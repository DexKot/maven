package dev.dexkot.mobile.core.di.koin

import org.koin.core.module.Module

/**
 * Agrupa todos los módulos Koin del core.
 *
 * Recordá que el logger no compone un [dev.dexkot.mobile.core.logger.ILogger]: la app debe
 * registrar su propio `single<ILogger> { ... }` (ver [loggerModule]).
 *
 * @param consoleLoggerTag tag del ConsoleLogger (default "Console").
 * @param logicSourceComponent sourceComponent del interactor lógico principal (default "app").
 * @param permissionPreferencesName nombre del SharedPreferences de permisos (ver [permissionModule]).
 */
fun coreModule(
    consoleLoggerTag: String = "Console",
    logicSourceComponent: String = "app",
    permissionPreferencesName: String = "dev.dexkot.permissions.preferences",
): List<Module> = listOf(
    loggerModule(
        consoleLoggerTag = consoleLoggerTag,
        logicSourceComponent = logicSourceComponent
    ),
    permissionModule(
        preferencesName = permissionPreferencesName
    ),
    RemoteConfigModule,
    UiModule
)
