package dev.dexkot.mobile.core.di.koin

import dev.dexkot.mobile.core.remoteconfig.handler.FirebaseRemoteConfigHandler
import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import dev.dexkot.mobile.core.remoteconfig.handler.PostHogRemoteConfigHandler
import dev.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import dev.dexkot.mobile.core.remoteconfig.provider.RemoteConfigProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.koin.core.qualifier.named
import org.koin.dsl.module

fun firebaseRemoteConfig() = named("firebase_remote_config")
fun postHogRemoteConfig() = named("posthog_remote_config")
internal fun remoteConfigCoroutineScope() = named("remote_config_coroutine_scope")

/**
 * Provee los handlers (Firebase/PostHog, con named) y el [IRemoteConfigProvider].
 *
 * @param dispatcher dispatcher del `CoroutineScope` interno (default [Dispatchers.Default]).
 * Útil para inyectar un `TestDispatcher` en tests.
 */
fun remoteConfigModule(
    dispatcher: CoroutineDispatcher = Dispatchers.Default
) = module {

    single<CoroutineScope>(remoteConfigCoroutineScope()) {
        CoroutineScope(SupervisorJob() + dispatcher)
    }

    // Los handlers son `single` y no `factory` porque tienen estado: cada instancia mantiene sus
    // propios StateFlow por clave. Con `factory`, resolver el handler desde dos puntos repartía
    // instancias distintas y un `sync()` sobre una no actualizaba los flows que observaba la otra.
    //
    // No limita nada: el cliente que envuelven habla con un SDK que ya es singleton de proceso, y
    // dos handlers independientes del mismo backend no son una configuración válida.
    //
    // Ojo con los parámetros inyectados: se aplican en la primera creación. Resolver el mismo
    // qualifier con parámetros distintos devuelve la instancia original y los ignora.
    single<IRemoteConfigHandler>(firebaseRemoteConfig()) { parameters ->
        FirebaseRemoteConfigHandler(
            syncTimeOut = parameters.get(),
            serializer = parameters.get()
        )
    }

    single<IRemoteConfigHandler>(postHogRemoteConfig()) { parameters ->
        PostHogRemoteConfigHandler(
            serializer = parameters.get()
        )
    }

    factory<IRemoteConfigProvider> {
        RemoteConfigProvider(
            remoteConfigHandler = get()
        )
    }

}
