package dev.dexkot.mobile.core.di.koin

import org.koin.core.module.Module

/**
 * Agrupa los módulos Koin Android del core (permission, remote config y ui).
 *
 * El DI de logger ya no vive acá: se migró al módulo multiplataforma `core-logger-di-koin`
 * (`loggerModule()`), que los consumidores KMP pueden incluir directamente.
 *
 * @param permissionPreferencesName nombre del SharedPreferences de permisos (ver [permissionModule]).
 * @param uiPreferencesName nombre del SharedPreferences de UI preferences (ver [uiModule]).
 */
fun coreModule(
    permissionPreferencesName: String = "dev.dexkot.permissions.preferences",
    uiPreferencesName: String = "dev.dexkot.ui.preferences",
): List<Module> = listOf(
    permissionModule(
        preferencesName = permissionPreferencesName
    ),
    remoteConfigModule(),
    uiModule(
        preferencesName = uiPreferencesName
    )
)
