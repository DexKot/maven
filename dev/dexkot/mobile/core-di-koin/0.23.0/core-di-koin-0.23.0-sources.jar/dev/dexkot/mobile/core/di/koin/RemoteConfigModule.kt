package dev.dexkot.mobile.core.di.koin

import dev.dexkot.mobile.core.remoteconfig.handler.FirebaseRemoteConfigHandler
import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import dev.dexkot.mobile.core.remoteconfig.handler.PostHogRemoteConfigHandler
import dev.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import dev.dexkot.mobile.core.remoteconfig.provider.RemoteConfigProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.koin.core.qualifier.named
import org.koin.dsl.module

fun firebaseRemoteConfig() = named("firebase_remote_config")
fun postHogRemoteConfig() = named("posthog_remote_config")
internal fun remoteConfigCoroutineScope() = named("remote_config_coroutine_scope")

/**
 * Provee los handlers (Firebase/PostHog, con named) y el [IRemoteConfigProvider].
 *
 * @param dispatcher dispatcher del `CoroutineScope` interno (default [Dispatchers.Default]).
 * Útil para inyectar un `TestDispatcher` en tests.
 */
fun remoteConfigModule(
    dispatcher: CoroutineDispatcher = Dispatchers.Default
) = module {

    single<CoroutineScope>(remoteConfigCoroutineScope()) {
        CoroutineScope(SupervisorJob() + dispatcher)
    }

    factory<IRemoteConfigHandler>(firebaseRemoteConfig()) { parameters ->
        FirebaseRemoteConfigHandler(
            syncTimeOut = parameters.get(),
            serializer = parameters.get()
        )
    }

    factory<IRemoteConfigHandler>(postHogRemoteConfig()) { parameters ->
        PostHogRemoteConfigHandler(
            serializer = parameters.get()
        )
    }

    factory<IRemoteConfigProvider> {
        RemoteConfigProvider(
            remoteConfigHandler = get()
        )
    }

}
