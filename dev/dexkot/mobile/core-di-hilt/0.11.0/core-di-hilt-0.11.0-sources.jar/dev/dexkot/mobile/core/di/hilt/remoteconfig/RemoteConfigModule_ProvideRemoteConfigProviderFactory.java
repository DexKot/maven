package dev.dexkot.mobile.core.di.hilt.remoteconfig;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler;
import dev.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RemoteConfigModule_ProvideRemoteConfigProviderFactory implements Factory<IRemoteConfigProvider> {
  private final Provider<IRemoteConfigHandler> handlerProvider;

  public RemoteConfigModule_ProvideRemoteConfigProviderFactory(
      Provider<IRemoteConfigHandler> handlerProvider) {
    this.handlerProvider = handlerProvider;
  }

  @Override
  public IRemoteConfigProvider get() {
    return provideRemoteConfigProvider(handlerProvider.get());
  }

  public static RemoteConfigModule_ProvideRemoteConfigProviderFactory create(
      Provider<IRemoteConfigHandler> handlerProvider) {
    return new RemoteConfigModule_ProvideRemoteConfigProviderFactory(handlerProvider);
  }

  public static IRemoteConfigProvider provideRemoteConfigProvider(IRemoteConfigHandler handler) {
    return Preconditions.checkNotNullFromProvides(RemoteConfigModule.INSTANCE.provideRemoteConfigProvider(handler));
  }
}
