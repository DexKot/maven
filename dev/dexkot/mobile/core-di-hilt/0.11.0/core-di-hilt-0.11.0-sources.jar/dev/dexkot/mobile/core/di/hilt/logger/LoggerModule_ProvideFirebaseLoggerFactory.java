package dev.dexkot.mobile.core.di.hilt.logger;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.logger.ILogger;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dev.dexkot.mobile.core.di.hilt.qualifier.FirebaseLoggerQualifier")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class LoggerModule_ProvideFirebaseLoggerFactory implements Factory<ILogger> {
  @Override
  public ILogger get() {
    return provideFirebaseLogger();
  }

  public static LoggerModule_ProvideFirebaseLoggerFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ILogger provideFirebaseLogger() {
    return Preconditions.checkNotNullFromProvides(LoggerModule.INSTANCE.provideFirebaseLogger());
  }

  private static final class InstanceHolder {
    static final LoggerModule_ProvideFirebaseLoggerFactory INSTANCE = new LoggerModule_ProvideFirebaseLoggerFactory();
  }
}
