package dev.dexkot.mobile.core.di.hilt.ui;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.ui.resources.IResourceProvider;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("dagger.hilt.android.qualifiers.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UiModule_ProvideResourceProviderFactory implements Factory<IResourceProvider> {
  private final Provider<Context> contextProvider;

  public UiModule_ProvideResourceProviderFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public IResourceProvider get() {
    return provideResourceProvider(contextProvider.get());
  }

  public static UiModule_ProvideResourceProviderFactory create(Provider<Context> contextProvider) {
    return new UiModule_ProvideResourceProviderFactory(contextProvider);
  }

  public static IResourceProvider provideResourceProvider(Context context) {
    return Preconditions.checkNotNullFromProvides(UiModule.INSTANCE.provideResourceProvider(context));
  }
}
