package dev.dexkot.mobile.core.di.hilt.ui;

import android.content.Context;
import android.content.SharedPreferences;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dev.dexkot.mobile.core.di.hilt.qualifier.UiPreferencesQualifier",
    "dagger.hilt.android.qualifiers.ApplicationContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UiModule_ProvideUiSharedPreferencesFactory implements Factory<SharedPreferences> {
  private final Provider<Context> contextProvider;

  public UiModule_ProvideUiSharedPreferencesFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public SharedPreferences get() {
    return provideUiSharedPreferences(contextProvider.get());
  }

  public static UiModule_ProvideUiSharedPreferencesFactory create(
      Provider<Context> contextProvider) {
    return new UiModule_ProvideUiSharedPreferencesFactory(contextProvider);
  }

  public static SharedPreferences provideUiSharedPreferences(Context context) {
    return Preconditions.checkNotNullFromProvides(UiModule.INSTANCE.provideUiSharedPreferences(context));
  }
}
