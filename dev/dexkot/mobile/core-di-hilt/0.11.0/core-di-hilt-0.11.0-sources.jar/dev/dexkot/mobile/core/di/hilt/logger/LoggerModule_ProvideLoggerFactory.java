package dev.dexkot.mobile.core.di.hilt.logger;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.logger.ILogger;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dev.dexkot.mobile.core.di.hilt.qualifier.ComposedLoggerQualifier")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class LoggerModule_ProvideLoggerFactory implements Factory<ILogger> {
  private final Provider<ILogger> loggerProvider;

  public LoggerModule_ProvideLoggerFactory(Provider<ILogger> loggerProvider) {
    this.loggerProvider = loggerProvider;
  }

  @Override
  public ILogger get() {
    return provideLogger(loggerProvider.get());
  }

  public static LoggerModule_ProvideLoggerFactory create(Provider<ILogger> loggerProvider) {
    return new LoggerModule_ProvideLoggerFactory(loggerProvider);
  }

  public static ILogger provideLogger(ILogger logger) {
    return Preconditions.checkNotNullFromProvides(LoggerModule.INSTANCE.provideLogger(logger));
  }
}
