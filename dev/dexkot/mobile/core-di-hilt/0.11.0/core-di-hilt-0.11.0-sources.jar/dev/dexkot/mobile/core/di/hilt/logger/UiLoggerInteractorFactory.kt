package dev.dexkot.mobile.core.di.hilt.logger

import dev.dexkot.mobile.core.logger.ILogger
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor as IUiLoggerInteractor
import dev.dexkot.mobile.core.logger.uiInteractor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton

interface IUiLoggerInteractorFactory {
    fun create(sourceComponent: String): IUiLoggerInteractor
}

internal class UiLoggerInteractorFactory @Inject constructor(
    private val logger: ILogger
) : IUiLoggerInteractorFactory {
    override fun create(sourceComponent: String): IUiLoggerInteractor {
        return logger.uiInteractor(sourceComponent)
    }
}

@Module
@InstallIn(SingletonComponent::class)
object UiLoggerInteractorModule {

    @Provides
    @Singleton
    fun provideUiLoggerInteractorFactory(
        logger: ILogger
    ): IUiLoggerInteractorFactory = UiLoggerInteractorFactory(logger)

}
