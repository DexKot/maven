package dev.dexkot.mobile.core.di.hilt.remoteconfig;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.serialization.json.Json;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "dev.dexkot.mobile.core.di.hilt.qualifier.FirebaseRemoteConfigQualifier",
    "dev.dexkot.mobile.core.di.hilt.qualifier.RemoteConfigCoroutineScope"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RemoteConfigModule_ProvideFirebaseRemoteConfigHandlerFactory implements Factory<IRemoteConfigHandler> {
  private final Provider<CoroutineScope> coroutineScopeProvider;

  private final Provider<Json> serializerProvider;

  public RemoteConfigModule_ProvideFirebaseRemoteConfigHandlerFactory(
      Provider<CoroutineScope> coroutineScopeProvider, Provider<Json> serializerProvider) {
    this.coroutineScopeProvider = coroutineScopeProvider;
    this.serializerProvider = serializerProvider;
  }

  @Override
  public IRemoteConfigHandler get() {
    return provideFirebaseRemoteConfigHandler(coroutineScopeProvider.get(), serializerProvider.get());
  }

  public static RemoteConfigModule_ProvideFirebaseRemoteConfigHandlerFactory create(
      Provider<CoroutineScope> coroutineScopeProvider, Provider<Json> serializerProvider) {
    return new RemoteConfigModule_ProvideFirebaseRemoteConfigHandlerFactory(coroutineScopeProvider, serializerProvider);
  }

  public static IRemoteConfigHandler provideFirebaseRemoteConfigHandler(
      CoroutineScope coroutineScope, Json serializer) {
    return Preconditions.checkNotNullFromProvides(RemoteConfigModule.INSTANCE.provideFirebaseRemoteConfigHandler(coroutineScope, serializer));
  }
}
