package dev.dexkot.mobile.core.di.hilt.logger;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.logger.ILogger;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dev.dexkot.mobile.core.di.hilt.qualifier.ConsoleLoggerQualifier")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class LoggerModule_ProvideConsoleLoggerFactory implements Factory<ILogger> {
  @Override
  public ILogger get() {
    return provideConsoleLogger();
  }

  public static LoggerModule_ProvideConsoleLoggerFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ILogger provideConsoleLogger() {
    return Preconditions.checkNotNullFromProvides(LoggerModule.INSTANCE.provideConsoleLogger());
  }

  private static final class InstanceHolder {
    static final LoggerModule_ProvideConsoleLoggerFactory INSTANCE = new LoggerModule_ProvideConsoleLoggerFactory();
  }
}
