package dev.dexkot.mobile.core.di.hilt.logger;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.logger.ILogger;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UiLoggerInteractorFactory_Factory implements Factory<UiLoggerInteractorFactory> {
  private final Provider<ILogger> loggerProvider;

  public UiLoggerInteractorFactory_Factory(Provider<ILogger> loggerProvider) {
    this.loggerProvider = loggerProvider;
  }

  @Override
  public UiLoggerInteractorFactory get() {
    return newInstance(loggerProvider.get());
  }

  public static UiLoggerInteractorFactory_Factory create(Provider<ILogger> loggerProvider) {
    return new UiLoggerInteractorFactory_Factory(loggerProvider);
  }

  public static UiLoggerInteractorFactory newInstance(ILogger logger) {
    return new UiLoggerInteractorFactory(logger);
  }
}
