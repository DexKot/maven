package dev.dexkot.mobile.core.di.hilt.ui;

import android.content.SharedPreferences;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.ui.preferences.IUiPreferences;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dev.dexkot.mobile.core.di.hilt.qualifier.UiPreferencesQualifier")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UiModule_ProvideUiPreferencesFactory implements Factory<IUiPreferences> {
  private final Provider<SharedPreferences> sharedPreferencesProvider;

  public UiModule_ProvideUiPreferencesFactory(
      Provider<SharedPreferences> sharedPreferencesProvider) {
    this.sharedPreferencesProvider = sharedPreferencesProvider;
  }

  @Override
  public IUiPreferences get() {
    return provideUiPreferences(sharedPreferencesProvider.get());
  }

  public static UiModule_ProvideUiPreferencesFactory create(
      Provider<SharedPreferences> sharedPreferencesProvider) {
    return new UiModule_ProvideUiPreferencesFactory(sharedPreferencesProvider);
  }

  public static IUiPreferences provideUiPreferences(SharedPreferences sharedPreferences) {
    return Preconditions.checkNotNullFromProvides(UiModule.INSTANCE.provideUiPreferences(sharedPreferences));
  }
}
