package dev.dexkot.mobile.core.di.hilt.remoteconfig;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dev.dexkot.mobile.core.di.hilt.qualifier.FirebaseRemoteConfigQualifier")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RemoteConfigModule_ProvideRemoteConfigHandlerFactory implements Factory<IRemoteConfigHandler> {
  private final Provider<IRemoteConfigHandler> handlerProvider;

  public RemoteConfigModule_ProvideRemoteConfigHandlerFactory(
      Provider<IRemoteConfigHandler> handlerProvider) {
    this.handlerProvider = handlerProvider;
  }

  @Override
  public IRemoteConfigHandler get() {
    return provideRemoteConfigHandler(handlerProvider.get());
  }

  public static RemoteConfigModule_ProvideRemoteConfigHandlerFactory create(
      Provider<IRemoteConfigHandler> handlerProvider) {
    return new RemoteConfigModule_ProvideRemoteConfigHandlerFactory(handlerProvider);
  }

  public static IRemoteConfigHandler provideRemoteConfigHandler(IRemoteConfigHandler handler) {
    return Preconditions.checkNotNullFromProvides(RemoteConfigModule.INSTANCE.provideRemoteConfigHandler(handler));
  }
}
