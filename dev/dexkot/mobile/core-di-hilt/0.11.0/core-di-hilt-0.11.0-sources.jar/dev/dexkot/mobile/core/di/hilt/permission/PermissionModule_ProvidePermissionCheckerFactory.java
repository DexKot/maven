package dev.dexkot.mobile.core.di.hilt.permission;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.permission.checker.IPermissionChecker;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dagger.hilt.android.qualifiers.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PermissionModule_ProvidePermissionCheckerFactory implements Factory<IPermissionChecker> {
  private final Provider<Context> contextProvider;

  public PermissionModule_ProvidePermissionCheckerFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public IPermissionChecker get() {
    return providePermissionChecker(contextProvider.get());
  }

  public static PermissionModule_ProvidePermissionCheckerFactory create(
      Provider<Context> contextProvider) {
    return new PermissionModule_ProvidePermissionCheckerFactory(contextProvider);
  }

  public static IPermissionChecker providePermissionChecker(Context context) {
    return Preconditions.checkNotNullFromProvides(PermissionModule.INSTANCE.providePermissionChecker(context));
  }
}
