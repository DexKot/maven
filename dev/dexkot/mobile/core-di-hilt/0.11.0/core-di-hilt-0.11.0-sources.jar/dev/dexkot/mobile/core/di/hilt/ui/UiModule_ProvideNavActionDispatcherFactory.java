package dev.dexkot.mobile.core.di.hilt.ui;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher;
import dev.dexkot.mobile.core.ui.navigation.action.INavActionFactory;
import java.util.Set;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UiModule_ProvideNavActionDispatcherFactory implements Factory<INavActionDispatcher> {
  private final Provider<Set<INavActionFactory<?>>> factoriesProvider;

  public UiModule_ProvideNavActionDispatcherFactory(
      Provider<Set<INavActionFactory<?>>> factoriesProvider) {
    this.factoriesProvider = factoriesProvider;
  }

  @Override
  public INavActionDispatcher get() {
    return provideNavActionDispatcher(factoriesProvider.get());
  }

  public static UiModule_ProvideNavActionDispatcherFactory create(
      Provider<Set<INavActionFactory<?>>> factoriesProvider) {
    return new UiModule_ProvideNavActionDispatcherFactory(factoriesProvider);
  }

  public static INavActionDispatcher provideNavActionDispatcher(
      Set<INavActionFactory<?>> factories) {
    return Preconditions.checkNotNullFromProvides(UiModule.INSTANCE.provideNavActionDispatcher(factories));
  }
}
