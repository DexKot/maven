package dev.dexkot.mobile.core.di.hilt.remoteconfig;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.serialization.json.Json;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RemoteConfigModule_ProvideSerializerFactory implements Factory<Json> {
  @Override
  public Json get() {
    return provideSerializer();
  }

  public static RemoteConfigModule_ProvideSerializerFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static Json provideSerializer() {
    return Preconditions.checkNotNullFromProvides(RemoteConfigModule.INSTANCE.provideSerializer());
  }

  private static final class InstanceHolder {
    static final RemoteConfigModule_ProvideSerializerFactory INSTANCE = new RemoteConfigModule_ProvideSerializerFactory();
  }
}
