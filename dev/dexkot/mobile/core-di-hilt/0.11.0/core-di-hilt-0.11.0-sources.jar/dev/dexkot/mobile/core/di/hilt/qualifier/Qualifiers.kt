package dev.dexkot.mobile.core.di.hilt.qualifier

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ConsoleLoggerQualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class FirebaseLoggerQualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class PostHogLoggerQualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ComposedLoggerQualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class FirebaseRemoteConfigQualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class PostHogRemoteConfigQualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class RemoteConfigCoroutineScope

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class PermissionPreferences

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class UiPreferencesQualifier
