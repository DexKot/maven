package dev.dexkot.mobile.core.logger

import cocoapods.PostHog.PostHogSDK
import dev.dexkot.mobile.core.logger.levels.Level
import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSError
import platform.Foundation.NSLocalizedDescriptionKey

@OptIn(ExperimentalForeignApi::class)
internal actual class PostHogClient actual constructor() {

    private val postHog: PostHogSDK = PostHogSDK.shared()

    actual fun identify(distinctId: String) {
        postHog.identify(distinctId)
    }

    actual fun reset() {
        postHog.reset()
    }

    @Suppress("UNCHECKED_CAST")
    actual fun setPersonProperties(properties: Map<String, Any>) {
        postHog.setPersonPropertiesWithUserPropertiesToSet(properties as Map<Any?, *>)
    }

    @Suppress("UNCHECKED_CAST")
    actual fun capture(event: String, properties: Map<String, Any>) {
        postHog.captureWithEvent(event = event, properties = properties as Map<Any?, *>)
    }

    actual fun screen(screenTitle: String) {
        postHog.screenWithTitle(screenTitle = screenTitle, properties = null)
    }

    @Suppress("UNCHECKED_CAST")
    actual fun captureException(throwable: Throwable, properties: Map<String, Any>) {
        postHog.captureExceptionWithError(
            error = throwable.toNSError(),
            properties = properties as Map<Any?, *>,
        )
    }

    // PostHog iOS does not expose the internal SDK logger that the Android SDK does, so diagnostic
    // logs (not analytics events) go to the console, mirroring where Android's internal logger lands.
    actual fun diagnosticLog(level: Level, message: String, params: Map<String, Any>) {
        val suffix = if (params.isNotEmpty()) " $params" else ""
        println("[PostHog/${level.name}] $message$suffix")
    }

    private fun Throwable.toNSError(): NSError = NSError.errorWithDomain(
        domain = this::class.qualifiedName ?: "KotlinException",
        code = 0,
        userInfo = mapOf<Any?, Any?>(
            NSLocalizedDescriptionKey to (message ?: toString())
        )
    )
}
