package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.Status
import dev.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.Status as PermissionStatus
import dev.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import dev.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import dev.dexkot.mobile.core.logger.events.ui.screen.Action
import dev.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import dev.dexkot.mobile.core.logger.events.ui.state.UiStateEvent
import dev.dexkot.mobile.core.logger.levels.Level

/**
 * [ILogger] backed by PostHog.
 *
 * All event routing (which events become analytics captures, screens, or diagnostic logs) lives
 * here in common code; only the raw SDK calls are platform-specific, delegated to [PostHogClient]
 * (PostHog Android SDK on Android, PostHog iOS via cinterop on iOS).
 */
class PostHogLogger : ILogger {

    private val postHog = PostHogClient()

    override fun setUserId(identifier: String) {
        postHog.identify(identifier)
    }

    override fun removeUserId() {
        postHog.reset()
    }

    override fun setUserProperty(key: String, value: String?) {
        if (value == null) {
            removeUserProperty(key)
            return
        }
        postHog.setPersonProperties(properties = mapOf(key to value))
    }

    override fun removeUserProperty(key: String) {
        postHog.capture(
            event = "\$set",
            properties = mapOf("\$unset" to listOf(key)),
        )
    }

    override fun log(event: LogEvent) {
        when (event) {
            is InteractionEvent -> postHog.capture(
                event = "${event.sourceComponent}:${event.elementId}_${event.interaction.value}",
                properties = buildMap {
                    put("\$screen_name", event.sourceComponent)
                    put("element_id", event.elementId)
                    put("interaction", event.interaction.value)
                    event.extras.forEach { (key, value) -> put(key, value) }
                },
            )
            is ScreenEvent -> if (event.action == Action.Enter) {
                postHog.screen(screenTitle = event.sourceComponent)
            }
            is NavigationEvent -> postHog.diagnosticLog(
                Level.Info,
                "navigation: ${event.navigationId}",
                event.params,
            )
            is OperationEvent -> {
                postHog.diagnosticLog(
                    Level.Info,
                    "operation: ${event.operationId} [${event.status.value}]",
                    event.params,
                )
                if (event.isBusinessEvent && event.status == Status.Success) {
                    postHog.capture(
                        event = "${event.sourceComponent}:${event.operationId}",
                        properties = buildMap {
                            put("\$screen_name", event.sourceComponent)
                            put("status", event.status.value)
                            event.params.forEach { (key, value) -> put(key, value) }
                        },
                    )
                }
            }
            is PermissionEvent -> {
                postHog.diagnosticLog(
                    Level.Info,
                    "permission: ${event.permissions.map { "${it.key}=${it.value.value}" }}",
                    emptyMap(),
                )
                val isResult = event.permissions.any { it.value != PermissionStatus.Request }
                if (isResult) {
                    postHog.capture(
                        event = event.type,
                        properties = buildMap {
                            put("\$screen_name", event.sourceComponent)
                            event.permissions.forEach { (key, value) -> put(key, value.value) }
                        },
                    )
                }
            }
            is IntentionEvent -> postHog.diagnosticLog(
                Level.Info,
                "intention: ${event.intentionId}",
                event.params,
            )
            is UiStateEvent -> postHog.diagnosticLog(
                Level.Info,
                "${event.state.value}: ${event.elementId}",
                event.extras,
            )
        }
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        postHog.diagnosticLog(level, message, params)
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        postHog.captureException(
            throwable = throwable,
            properties = buildMap {
                message?.let { put("message", it) }
                putAll(params)
            },
        )
    }
}
