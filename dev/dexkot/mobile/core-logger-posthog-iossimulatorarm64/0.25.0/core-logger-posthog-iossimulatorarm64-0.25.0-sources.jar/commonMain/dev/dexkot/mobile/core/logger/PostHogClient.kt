package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.levels.Level

/**
 * Thin platform-specific access to the PostHog SDK. All event routing lives in [PostHogLogger]; this
 * only exposes the primitive calls, which differ between the PostHog Android and iOS SDKs.
 *
 * Uses the SDK singleton internally, so the constructor takes no arguments.
 */
internal expect class PostHogClient() {

    fun identify(distinctId: String)

    fun reset()

    fun setPersonProperties(properties: Map<String, Any>)

    fun capture(event: String, properties: Map<String, Any>)

    fun screen(screenTitle: String)

    fun captureException(throwable: Throwable, properties: Map<String, Any>)

    /**
     * Internal SDK-level diagnostic log (not an analytics event). Maps to PostHog's internal logger
     * on Android; on iOS — which does not expose an equivalent — it prints to the console.
     */
    fun diagnosticLog(level: Level, message: String, params: Map<String, Any>)
}
