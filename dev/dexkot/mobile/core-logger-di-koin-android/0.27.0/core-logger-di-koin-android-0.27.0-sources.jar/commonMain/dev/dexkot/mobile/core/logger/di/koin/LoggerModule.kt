package dev.dexkot.mobile.core.logger.di.koin

import dev.dexkot.mobile.core.logger.ConsoleLogger
import dev.dexkot.mobile.core.logger.FirebaseLogger
import dev.dexkot.mobile.core.logger.ILogger
import dev.dexkot.mobile.core.logger.PostHogLogger
import dev.dexkot.mobile.core.logger.context.LoggerContextElement
import dev.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor as ILogicLoggerInteractor
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor as IUiLoggerInteractor
import dev.dexkot.mobile.core.logger.logicInteractor
import dev.dexkot.mobile.core.logger.uiInteractor
import org.koin.core.module.Module
import org.koin.dsl.module

/**
 * Provee cada logger por separado (como su tipo concreto) y el interactor lógico "principal".
 *
 * Versión **multiplataforma** de lo que antes vivía Android-only en `core-di-koin.loggerModule()`.
 *
 * NO compone el [ILogger]: esa decisión es de la app, que registra su propio
 * `single<ILogger> { get<ConsoleLogger>() + get<FirebaseLogger>() + get<PostHogLogger>() }`
 * (envuelto como quiera). El interactor lógico sí lo provee acá porque además hace
 * [LoggerContextElement.setDefault], un detalle interno que no debería filtrarse a la app.
 *
 * @param consoleLoggerTag tag con el que loguea el [ConsoleLogger] (default "Console").
 * @param logicSourceComponent sourceComponent del interactor lógico principal (default "app").
 */
fun loggerModule(
    consoleLoggerTag: String = "Console",
    logicSourceComponent: String = "app",
): Module = module {

    single { ConsoleLogger(tag = consoleLoggerTag) }

    single { FirebaseLogger() }

    single { PostHogLogger() }

    single<ILogicLoggerInteractor>(createdAtStart = true) {
        get<ILogger>().logicInteractor(logicSourceComponent).also {
            LoggerContextElement.setDefault(it)
        }
    }

    factory<IUiLoggerInteractor> { parameters ->
        get<ILogger>().uiInteractor(sourceComponent = parameters.get())
    }

}
