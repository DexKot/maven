package dev.dexkot.mobile.core.permission.di.koin

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import androidx.activity.result.ActivityResultLauncher
import dev.dexkot.mobile.core.permission.checker.IPermissionChecker
import dev.dexkot.mobile.core.permission.checker.PermissionChecker
import dev.dexkot.mobile.core.permission.controller.PermissionController
import org.koin.android.ext.koin.androidContext
import org.koin.core.qualifier.named
import org.koin.dsl.module

fun permissionPreferences() = named("permission_preferences")

/**
 * Provee el checker, las prefs y el factory de [PermissionController].
 *
 * @param preferencesName nombre del `SharedPreferences` donde se persiste el tracking de permisos
 * (default `"dev.dexkot.permissions.preferences"`). La app puede pasar su propio nombre para no
 * resetear el tracking `permission_requested_*` de usuarios existentes al adoptar el módulo.
 */
fun permissionModule(
    preferencesName: String = "dev.dexkot.permissions.preferences"
) = module {

    single<IPermissionChecker> {
        PermissionChecker(context = androidContext())
    }

    single<SharedPreferences>(permissionPreferences()) {
        androidContext()
            .getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
    }

    factory { (
        activity: Activity,
        singlePermissionLauncher: ActivityResultLauncher<String>,
        multiplePermissionsLauncher: ActivityResultLauncher<Array<String>>
    ) ->
        PermissionController(
            activity = activity,
            preferences = get(permissionPreferences()),
            singlePermissionLauncher = singlePermissionLauncher,
            multiplePermissionsLauncher = multiplePermissionsLauncher
        )
    }

}
