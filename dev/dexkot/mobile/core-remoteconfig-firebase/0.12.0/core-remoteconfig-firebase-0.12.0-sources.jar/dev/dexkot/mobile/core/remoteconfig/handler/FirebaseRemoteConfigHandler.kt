package dev.dexkot.mobile.core.remoteconfig.handler

import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.errors.ErrorEntity
import dev.dexkot.mobile.core.foundation.result.getOrDefault
import dev.dexkot.mobile.core.logger.interactors.ddl.logger
import dev.dexkot.mobile.core.remoteconfig.error.ConfigNotFound
import com.google.android.gms.tasks.Tasks
import com.google.firebase.remoteconfig.ConfigUpdate
import com.google.firebase.remoteconfig.ConfigUpdateListener
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigException
import com.google.firebase.remoteconfig.get
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.util.Collections
import java.util.concurrent.TimeUnit

class FirebaseRemoteConfigHandler(
    private val firebaseRemoteConfig: FirebaseRemoteConfig,
    private val coroutineScope: CoroutineScope,
    private val syncTimeOut: Long,
    override val serializer: Json,
    private val expirationTime: Long = TimeUnit.MINUTES.toSeconds(1)
): IRemoteConfigHandler {

    private val boolFlows: MutableMap<String, MutableStateFlow<Boolean>> = Collections.synchronizedMap(mutableMapOf())
    private val longFlows: MutableMap<String, MutableStateFlow<Long>> = Collections.synchronizedMap(mutableMapOf())
    private val stringFlows: MutableMap<String, MutableStateFlow<String>> = Collections.synchronizedMap(mutableMapOf())

    init {
        firebaseRemoteConfig.addOnConfigUpdateListener(
            object : ConfigUpdateListener {
                override fun onUpdate(configUpdate : ConfigUpdate) {
                    firebaseRemoteConfig.activate()
                        .addOnSuccessListener {
                            updateFlows()
                        }
                        .addOnFailureListener { exception ->
                            logger {
                                error(
                                    throwable = exception,
                                    message = "Failed to activate the fetched remote configs"
                                )
                            }
                        }
                }

                override fun onError(error : FirebaseRemoteConfigException) {
                    logger {
                        error(
                            throwable = error,
                            message = "Config update error with code: ${error.code}"
                        )
                    }
                }
            }
        )
    }

    /**
     * Try to fetch and activate the firebase config in a forced way.
     *
     * A Success, means we fetched and activated new data, so remote config is up-dated.
     *
     * In case of Failure means that we could not fetch or activate new config data from Internet.
     */
    override suspend fun sync(): ResultOf<Boolean> {
        return withContext(Dispatchers.IO) {

            try {
                /** Start a task to fetch remote config with */
                val taskFetch = firebaseRemoteConfig.fetch(expirationTime)
                Tasks.await(taskFetch, syncTimeOut, TimeUnit.MILLISECONDS)

                if (taskFetch.isSuccessful) {
                    /** If the task finish successfully (i.e. if it could fetch config data from Internet) then activate the new values */
                    val taskActivate = firebaseRemoteConfig.activate()
                    taskActivate.await()
                    if (taskActivate.isSuccessful) {
                        updateFlows()
                        /** If the task finish successfully (i.e. we correctly activated new values) we return Success */
                        ResultOf.Success(taskActivate.result)
                    } else {
                        taskActivate.exception?.let { exception ->
                            logger {
                                error(
                                    throwable = exception,
                                    message = "Failed to activate the fetched remote configs"
                                )
                            }
                        }

                        /** If something went wrong, we return Failure **/
                        ResultOf.Failure(error = ErrorEntity.UnexpectedError(exception = taskActivate.exception))
                    }
                } else {
                    taskFetch.exception?.let { exception ->
                        logger {
                            error(
                                throwable = exception,
                                message = "Failed to fetch new remote configs"
                            )
                        }
                    }

                    /** If something went wrong, we return Failure **/
                    ResultOf.Failure(error = ErrorEntity.UnexpectedError(exception = taskFetch.exception))
                }
            } catch (exception: Exception) {
                logger {
                    error(
                        throwable = exception,
                        message = "Failed to sync remote configs"
                    )
                }

                /** If we had some error while trying to fetch config data, then return Failure **/
                ResultOf.Failure(error = ErrorEntity.UnexpectedError(exception = exception))
            }

        }
    }

    /**
     * Get a Boolean value from the remote config
     *
     * @param key The name of the config to get
     */
    override fun getBoolean(key: String): ResultOf<Boolean> {
        val configValue = firebaseRemoteConfig[key]

        return if (configValue.source != FirebaseRemoteConfig.VALUE_SOURCE_REMOTE) {
            ResultOf.Failure(ConfigNotFound(configKey = key))
        } else {
            try {
                ResultOf.Success(configValue.asString().toBoolean())
            } catch (exception: Exception) {
                logger {
                    error(
                        throwable = exception,
                        message = "Failed to parse boolean for key $key from remote config"
                    )
                }

                ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
            }
        }

    }

    /**
     * Get a String value from the remote config
     *
     * @param key The name of the config to get
     */
    override fun getString(key: String): ResultOf<String> {
        val configValue = firebaseRemoteConfig[key]

        return if (configValue.source != FirebaseRemoteConfig.VALUE_SOURCE_REMOTE) {
            ResultOf.Failure(ConfigNotFound(configKey = key))
        } else {
            try {
                ResultOf.Success(configValue.asString())
            } catch (exception: Exception) {
                logger {
                    error(
                        throwable = exception,
                        message = "Failed to parse string for key $key from remote config"
                    )
                }

                ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
            }
        }
    }

    /**
     * Get a Long value from the remote config
     *
     * @param key The name of the config to get
     */
    override fun getLong(key: String): ResultOf<Long> {
        val configValue = firebaseRemoteConfig[key]

        return if (configValue.source != FirebaseRemoteConfig.VALUE_SOURCE_REMOTE) {
            ResultOf.Failure(ConfigNotFound(configKey = key))
        } else {
            try {
                ResultOf.Success(configValue.asString().toLong())
            } catch (exception: Exception) {
                logger {
                    error(
                        throwable = exception,
                        message = "Failed to parse number for key $key from remote config"
                    )
                }

                ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
            }
        }
    }

    /**
     * Get a flow of Boolean values from the remote config
     *
     * @param key The name of the config to get
     * @param defaultValue The default value to return if the config is not found
     */
    override fun getBooleanFlow(
        key: String,
        defaultValue: Boolean
    ): StateFlow<Boolean> {
        return boolFlows.createFlow(key) { getBoolean(key).getOrDefault(defaultValue) }
    }

    /**
     * Get a flow of Long values from the remote config
     *
     * @param key The name of the config to get
     * @param defaultValue The default value to return if the config is not found
     */
    override fun getLongFlow(
        key: String,
        defaultValue: Long
    ): StateFlow<Long> {
        return longFlows.createFlow(key) { getLong(key).getOrDefault(defaultValue) }
    }

    /**
     * Get a flow of String values from the remote config
     *
     * @param key The name of the config to get
     * @param defaultValue The default value to return if the config is not found
     */
    override fun getStringFlow(
        key: String,
        defaultValue: String
    ): StateFlow<String> {
        return stringFlows.createFlow(key) { getString(key).getOrDefault(defaultValue) }
    }

    private fun updateFlows() {
        for ((key, flow) in boolFlows)
            flow.value = getBoolean(key).getOrDefault(flow.value)

        for ((key, flow) in longFlows)
            flow.value = getLong(key).getOrDefault(flow.value)

        for ((key, flow) in stringFlows)
            flow.value = getString(key).getOrDefault(flow.value)
    }

    private fun <T> MutableMap<String, MutableStateFlow<T>>.createFlow(
        key: String,
        getValue: () -> T
    ): StateFlow<T> {
        val existing = this[key]
        if (existing != null) return existing.asStateFlow()
        val flow = MutableStateFlow(getValue())
        this[key] = flow
        return flow.asStateFlow()
    }

}
