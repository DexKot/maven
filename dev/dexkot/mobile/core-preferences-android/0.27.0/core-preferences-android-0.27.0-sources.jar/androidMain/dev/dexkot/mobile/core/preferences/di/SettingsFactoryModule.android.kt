package dev.dexkot.mobile.core.preferences.di

import com.russhwolf.settings.SharedPreferencesSettings
import com.russhwolf.settings.Settings
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.Module
import org.koin.dsl.module

actual val settingsFactoryModule: Module = module {
    single<Settings.Factory> { SharedPreferencesSettings.Factory(androidContext()) }
}
