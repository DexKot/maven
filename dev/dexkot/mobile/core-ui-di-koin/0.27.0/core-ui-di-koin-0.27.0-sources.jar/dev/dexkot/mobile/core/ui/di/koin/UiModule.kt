package dev.dexkot.mobile.core.ui.di.koin

import android.content.Context
import dev.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import dev.dexkot.mobile.core.ui.navigation.action.INavActionFactory
import dev.dexkot.mobile.core.ui.navigation.action.NavActionDispatcher
import dev.dexkot.mobile.core.ui.preferences.IUiPreferences
import dev.dexkot.mobile.core.ui.preferences.UiPreferences
import dev.dexkot.mobile.core.ui.resources.IResourceProvider
import dev.dexkot.mobile.core.ui.resources.ResourceProvider
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

/**
 * Provee el dispatcher de nav actions, las UI preferences y el resource provider.
 *
 * @param preferencesName nombre del `SharedPreferences` de [UiPreferences]
 * (default `"dev.dexkot.ui.preferences"`). La app puede pasar su propio nombre para no resetear
 * las preferencias de UI de usuarios existentes al adoptar el módulo.
 */
fun uiModule(
    preferencesName: String = "dev.dexkot.ui.preferences"
) = module {

    single<INavActionDispatcher> {
        NavActionDispatcher(
            factories = getAll<INavActionFactory<*>>()
        )
    }

    single<IUiPreferences> {
        UiPreferences(
            sharedPreferences = androidContext()
                .getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
        )
    }

    factory<IResourceProvider> {
        ResourceProvider(
            context = get()
        )
    }

}
