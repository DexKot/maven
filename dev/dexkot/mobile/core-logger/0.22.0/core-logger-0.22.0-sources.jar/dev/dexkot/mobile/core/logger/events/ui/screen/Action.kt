package dev.dexkot.mobile.core.logger.events.ui.screen

enum class Action(
    val value: String,
) {

    Enter("enter"),
    Exit("exit");

}
