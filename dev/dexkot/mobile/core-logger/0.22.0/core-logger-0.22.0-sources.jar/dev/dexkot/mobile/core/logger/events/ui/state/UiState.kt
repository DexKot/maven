package dev.dexkot.mobile.core.logger.events.ui.state

enum class UiState(
    val value: String,
) {

    Show("show"),
    Hide("hide"),
    Expand("expand"),
    Collapse("collapse"),
    FocusCapture("focus_capture"),
    FocusRelease("focus_release");

}
