package dev.dexkot.mobile.core.logger

import android.util.Log
import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import dev.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import dev.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import dev.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import dev.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import dev.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import dev.dexkot.mobile.core.logger.events.ui.state.UiStateEvent
import dev.dexkot.mobile.core.logger.levels.Level

class ConsoleLogger(
    private val tag: String
) : ILogger {

    override fun setUserId(identifier: String) {
        Log.i(tag, "User id: $identifier")
    }

    override fun setUserProperty(key: String, value: String?) {
        Log.i(tag, "User property: $key = $value")
    }

    override fun removeUserId() {
        Log.i(tag, "User id deleted")
    }

    override fun removeUserProperty(key: String) {
        Log.i(tag, "User property $key deleted")
    }

    override fun log(event: LogEvent) {
        when (event) {
            is InteractionEvent -> Log.i(
                tag,
                "[${event.sourceComponent}] ${event.interaction.value}: ${event.elementId}" +
                    event.extras.ifNotEmpty { " $it" },
            )
            is ScreenEvent -> Log.i(
                tag,
                "[${event.sourceComponent}] screen: ${event.action.value}",
            )
            is NavigationEvent -> Log.i(
                tag,
                "[${event.sourceComponent}] navigation: ${event.navigationId}" +
                    event.params.ifNotEmpty { " $it" },
            )
            is OperationEvent -> Log.i(
                tag,
                "[${event.sourceComponent}] operation: ${event.operationId} [${event.status.value}]" +
                    event.params.ifNotEmpty { " $it" },
            )
            is PermissionEvent -> Log.i(
                tag,
                "[${event.sourceComponent}] permission: ${event.permissions.map { "${it.key}=${it.value.value}" }}",
            )
            is IntentionEvent -> Log.i(
                tag,
                "[${event.sourceComponent}] intention: ${event.intentionId}" +
                    event.params.ifNotEmpty { " $it" },
            )
            is UiStateEvent -> Log.i(
                tag,
                "[${event.sourceComponent}] ${event.state.value}: ${event.elementId}" +
                    event.extras.ifNotEmpty { " $it" },
            )
        }
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        val priority = when (level) {
            Level.Verbose -> Log.VERBOSE
            Level.Debug -> Log.DEBUG
            Level.Info -> Log.INFO
            Level.Warning -> Log.WARN
            Level.Error -> Log.ERROR
        }

        Log.println(priority, tag, "$message${params.ifNotEmpty { " $it" }}")
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        Log.e(tag, "$message${params.ifNotEmpty { " $it" }}", throwable)
    }

    private fun <K, V> Map<K, V>.ifNotEmpty(transform: (Map<K, V>) -> String): String {
        return if (isNotEmpty()) transform(this) else ""
    }

}
