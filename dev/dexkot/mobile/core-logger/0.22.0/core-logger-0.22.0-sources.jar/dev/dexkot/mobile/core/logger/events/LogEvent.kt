package dev.dexkot.mobile.core.logger.events

/**
 * A base class from which every analytic event should inherits. Every event must has a [type]
 * and a map with [parameters] data (it may be empty).
 *
 * @property type The type of the event (it may be "ui-interaction", "operation_confirm", etc).
 * @property parameters The extra data, which is a Map<String, Any>
 */
interface LogEvent {

    val type: String

    val parameters: Map<String, Any>

}
