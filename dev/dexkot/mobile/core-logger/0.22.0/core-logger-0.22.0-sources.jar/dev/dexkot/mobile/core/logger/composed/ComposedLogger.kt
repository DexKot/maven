package dev.dexkot.mobile.core.logger.composed

import dev.dexkot.mobile.core.logger.ILogger
import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.levels.Level

internal class ComposedLogger(
    private val loggers: List<ILogger>
): ILogger {

    override fun setUserId(identifier: String) {
        loggers.forEach { it.setUserId(identifier) }
    }

    override fun setUserProperty(key: String, value: String?) {
        loggers.forEach { it.setUserProperty(key, value) }
    }

    override fun removeUserId() {
        loggers.forEach { it.removeUserId() }
    }

    override fun removeUserProperty(key: String) {
        loggers.forEach { it.removeUserProperty(key) }
    }

    override fun log(event: LogEvent) {
        loggers.forEach { it.log(event) }
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        loggers.forEach { it.log(level, tag, message, params) }
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        loggers.forEach { it.log(throwable, message, params) }
    }

}
