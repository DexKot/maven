package dev.dexkot.mobile.core.logger.interactors.ui

import dev.dexkot.mobile.core.logger.events.ui.interaction.Interaction
import dev.dexkot.mobile.core.logger.events.ui.permission.Status
import dev.dexkot.mobile.core.logger.events.ui.state.UiState

interface ILoggerInteractor {

    fun enter()

    fun exit()

    fun navigate(
        navigationId: String,
        params: Map<String, String> = emptyMap()
    )

    fun permission(
        permissions: List<String>
    )

    fun permission(
        permissions: Map<String, Status>
    )

    fun interaction(
        elementId: String,
        interaction: Interaction,
        extras: Map<String, String> = emptyMap()
    )

    fun uiState(
        elementId: String,
        state: UiState,
        extras: Map<String, String> = emptyMap()
    )

    fun intention(
        intentionId: String,
        params: Map<String, String> = emptyMap()
    )

}
