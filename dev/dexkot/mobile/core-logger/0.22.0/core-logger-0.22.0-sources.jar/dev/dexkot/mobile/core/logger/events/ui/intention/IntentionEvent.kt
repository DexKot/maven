package dev.dexkot.mobile.core.logger.events.ui.intention

import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ui.Parameter

class IntentionEvent(
    val sourceComponent: String,
    val intentionId: String,
    val params: Map<String, String> = mapOf()
) : LogEvent {

    override val type: String = "ui_intention"

    override val parameters: Map<String, Any> = buildMap {
        put(Parameter.SOURCE_COMPONENT, sourceComponent)
        put(Parameter.INTENTION_ID, intentionId)
        params.forEach { (key, value) -> put("parameter_$key", value) }
    }

}
