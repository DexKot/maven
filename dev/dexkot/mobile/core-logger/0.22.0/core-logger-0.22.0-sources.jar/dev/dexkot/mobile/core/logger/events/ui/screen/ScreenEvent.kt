package dev.dexkot.mobile.core.logger.events.ui.screen

import dev.dexkot.mobile.core.logger.events.ui.Parameter
import dev.dexkot.mobile.core.logger.events.LogEvent

/**
 * This event represent some user interaction: the user click some button, tap some image,
 * scroll to the end of a list, etc.
 */
class ScreenEvent(
    val sourceComponent: String,
    val action: Action
): LogEvent {

    override val type: String = "ui_screen"

    override val parameters: Map<String, Any> = buildMap {
        put(Parameter.SOURCE_COMPONENT, sourceComponent)
        put(Parameter.ACTION, action.value)
    }

}

