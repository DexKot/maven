package dev.dexkot.mobile.core.logger

import dev.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor as ILogicLoggerInteractor
import dev.dexkot.mobile.core.logger.interactors.ddl.LoggerInteractor as LogicLoggerInteractor
import dev.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor as IUiLoggerInteractor
import dev.dexkot.mobile.core.logger.interactors.ui.LoggerInteractor as UiLoggerInteractor
import dev.dexkot.mobile.core.logger.levels.Level

fun ILogger.uiInteractor(sourceComponent: String): IUiLoggerInteractor {
    return UiLoggerInteractor(logger = this, sourceComponent = sourceComponent)
}

fun ILogger.logicInteractor(sourceComponent: String): ILogicLoggerInteractor {
    return LogicLoggerInteractor(logger = this, sourceComponent = sourceComponent)
}

/**
 * Log a simple message (like the ones logged in the console) with a [Level.Verbose] level.
 *
 * @param tag The tag of the message (usually the class name, but can be anything)
 * @param message The message to be logged
 * @param params A map of parameters to be logged with the message (for example, variable values)
 */
fun ILogger.verbose(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    log(Level.Verbose, tag, message, params)
}

/**
 * This is a shortcut to [verbose] method
 */
fun ILogger.v(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    verbose(tag, message, params)
}

/**
 * Log a simple message (like the ones logged in the console) with a [Level.Debug] level.
 *
 * @param tag The tag of the message (usually the class name, but can be anything)
 * @param message The message to be logged
 * @param params A map of parameters to be logged with the message (for example, variable values)
 */
fun ILogger.debug(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    log(Level.Debug, tag, message, params)
}

/**
 * This is a shortcut to [debug] method
 */
fun ILogger.d(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    debug(tag, message, params)
}

/**
 * Log a simple message (like the ones logged in the console) with a [Level.Info] level.
 *
 * @param tag The tag of the message (usually the class name, but can be anything)
 * @param message The message to be logged
 * @param params A map of parameters to be logged with the message (for example, variable values)
 */
fun ILogger.info(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    log(Level.Info, tag, message, params)
}

/**
 * This is a shortcut to [info] method
 */
fun ILogger.i(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    info(tag, message, params)
}

/**
 * Log a simple message (like the ones logged in the console) with a [Level.Warning] level.
 *
 * @param tag The tag of the message (usually the class name, but can be anything)
 * @param message The message to be logged
 * @param params A map of parameters to be logged with the message (for example, variable values)
 */
fun ILogger.warning(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    log(Level.Warning, tag, message, params)
}

/**
 * This is a shortcut to [warning] method
 */
fun ILogger.w(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    warning(tag, message, params)
}

/**
 * Log a simple message (like the ones logged in the console) with a [Level.Error] level.
 *
 * @param tag The tag of the message (usually the class name, but can be anything)
 * @param message The message to be logged
 * @param params A map of parameters to be logged with the message (for example, variable values)
 */
fun ILogger.error(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    log(Level.Error, tag, message, params)
}

/**
 * This is a shortcut to [error] method
 */
fun ILogger.e(tag: String, message: String, params: Map<String, Any> = emptyMap()) {
    error(tag, message, params)
}
