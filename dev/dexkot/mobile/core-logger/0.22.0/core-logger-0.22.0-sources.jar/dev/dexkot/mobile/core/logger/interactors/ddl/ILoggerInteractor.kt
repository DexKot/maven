package dev.dexkot.mobile.core.logger.interactors.ddl

import dev.dexkot.mobile.core.logger.events.ddl.operation.Status

interface ILoggerInteractor {

    fun verbose(
        message: String,
        params: Map<String, Any> = emptyMap()
    )

    fun debug(
        message: String,
        params: Map<String, Any> = emptyMap()
    )

    fun info(
        message: String,
        params: Map<String, Any> = emptyMap()
    )

    fun warning(
        message: String,
        params: Map<String, Any> = emptyMap()
    )

    fun error(
        message: String,
        params: Map<String, Any>
    )

    fun error(
        throwable: Throwable,
        message: String? = null,
        params: Map<String, Any> = emptyMap()
    )

    fun operation(
        operationId: String,
        result: Status,
        params: Map<String, String> = emptyMap(),
        isBusinessEvent: Boolean = false
    )

}
