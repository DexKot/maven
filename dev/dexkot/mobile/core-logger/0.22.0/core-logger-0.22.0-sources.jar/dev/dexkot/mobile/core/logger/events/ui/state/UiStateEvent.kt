package dev.dexkot.mobile.core.logger.events.ui.state

import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.events.ui.Parameter

class UiStateEvent(
    val sourceComponent: String,
    val elementId: String,
    val state: UiState,
    val extras: Map<String, String> = mapOf()
) : LogEvent {

    override val type: String = "ui_state"

    override val parameters: Map<String, Any> = buildMap {
        put(Parameter.SOURCE_COMPONENT, sourceComponent)
        put(Parameter.ELEMENT_ID, elementId)
        put(Parameter.STATE, state.value)
        extras.forEach { (key, value) -> put("extra_$key", value) }
    }

}
