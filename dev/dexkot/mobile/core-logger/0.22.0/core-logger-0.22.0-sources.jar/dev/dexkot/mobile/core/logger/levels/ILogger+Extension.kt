package dev.dexkot.mobile.core.logger.levels

import dev.dexkot.mobile.core.logger.ILogger

fun ILogger.withLevel(level: Level): ILogger {
    return LevelLogger(level, this)
}
