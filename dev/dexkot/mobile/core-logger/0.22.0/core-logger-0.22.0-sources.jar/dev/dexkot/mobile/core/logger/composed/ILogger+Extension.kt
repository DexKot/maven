package dev.dexkot.mobile.core.logger.composed

import dev.dexkot.mobile.core.logger.ILogger

operator fun ILogger.plus(logger: ILogger): ILogger {
    return ComposedLogger(listOf(this, logger))
}
