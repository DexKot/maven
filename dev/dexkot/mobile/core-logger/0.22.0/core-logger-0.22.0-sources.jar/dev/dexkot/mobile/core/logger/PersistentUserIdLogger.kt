package dev.dexkot.mobile.core.logger

import android.content.Context
import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.levels.Level
import androidx.core.content.edit

class PersistentUserIdLogger(
    context: Context,
    private val delegate: ILogger
) : ILogger {

    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    init {
        val cachedUserId = preferences.getString(KEY_USER_ID, null)
        if (cachedUserId != null) {
            delegate.setUserId(cachedUserId)
        }
    }

    override fun setUserId(identifier: String) {
        preferences.edit { putString(KEY_USER_ID, identifier) }
        delegate.setUserId(identifier)
    }

    override fun removeUserId() {
        preferences.edit { remove(KEY_USER_ID) }
        delegate.removeUserId()
    }

    override fun setUserProperty(key: String, value: String?) {
        delegate.setUserProperty(key, value)
    }

    override fun removeUserProperty(key: String) {
        delegate.removeUserProperty(key)
    }

    override fun log(event: LogEvent) {
        delegate.log(event)
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        delegate.log(level, tag, message, params)
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        delegate.log(throwable, message, params)
    }

    private companion object {
        const val PREFERENCES_NAME = "dev.dexkot.mobile.core.logger"
        const val KEY_USER_ID = "user_id"
    }
}
