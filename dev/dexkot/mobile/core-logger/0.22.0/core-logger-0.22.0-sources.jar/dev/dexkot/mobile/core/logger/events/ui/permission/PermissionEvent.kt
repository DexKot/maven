package dev.dexkot.mobile.core.logger.events.ui.permission

import dev.dexkot.mobile.core.logger.events.ui.Parameter
import dev.dexkot.mobile.core.logger.events.LogEvent

/**
 * This event represent some user interaction: the user click some button, tap some image,
 * scroll to the end of a list, etc.
 */
class PermissionEvent(
    val sourceComponent: String,
    val permissions: Map<String, Status>
): LogEvent {

    override val type: String = "ui_permission"

    override val parameters: Map<String, Any> = buildMap {
        put(Parameter.SOURCE_COMPONENT, sourceComponent)
        permissions.forEach { put("permission_${it.key}", it.value.value) }
    }

}

