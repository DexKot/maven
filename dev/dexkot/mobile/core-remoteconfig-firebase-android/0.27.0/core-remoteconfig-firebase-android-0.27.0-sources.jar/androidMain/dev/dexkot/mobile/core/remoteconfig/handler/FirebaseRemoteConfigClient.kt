package dev.dexkot.mobile.core.remoteconfig.handler

import com.google.firebase.Firebase
import com.google.firebase.remoteconfig.ConfigUpdate
import com.google.firebase.remoteconfig.ConfigUpdateListener
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigException
import com.google.firebase.remoteconfig.get
import com.google.firebase.remoteconfig.remoteConfig
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

internal actual class FirebaseRemoteConfigClient actual constructor() {

    private val config: FirebaseRemoteConfig = Firebase.remoteConfig

    actual suspend fun fetchAndActivate(expirationSeconds: Long, timeoutMillis: Long): Boolean {
        return withTimeout(timeoutMillis) {
            config.fetch(expirationSeconds).await()
            config.activate().await()
        }
    }

    actual fun remoteStringOrNull(key: String): String? {
        val value = config[key]
        return if (value.source == FirebaseRemoteConfig.VALUE_SOURCE_REMOTE) value.asString() else null
    }

    actual fun observeUpdates(onUpdate: () -> Unit, onError: (Throwable) -> Unit) {
        config.addOnConfigUpdateListener(
            object : ConfigUpdateListener {
                override fun onUpdate(configUpdate: ConfigUpdate) {
                    config.activate()
                        .addOnSuccessListener { onUpdate() }
                        .addOnFailureListener { exception -> onError(exception) }
                }

                override fun onError(error: FirebaseRemoteConfigException) {
                    onError(error)
                }
            }
        )
    }
}
