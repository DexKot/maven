package dev.dexkot.mobile.core.remoteconfig.handler

import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.result.failureOf
import dev.dexkot.mobile.core.foundation.result.map
import dev.dexkot.mobile.core.foundation.result.successOf
import dev.dexkot.mobile.core.logger.interactors.ddl.logger
import dev.dexkot.mobile.core.remoteconfig.flow.mapState
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.Json

inline fun <reified T> IRemoteConfigHandler.get(key: String): ResultOf<T> {
    return when (val stringResult = getString(key)) {
        is ResultOf.Success -> {
            try {
                if (stringResult.data.isEmpty())
                    successOf()
                val data = serializer.decodeFromString<T>(stringResult.data)
                successOf(data)
            } catch (exception: Exception) {
                failureOf(exception)
            }
        }
        is ResultOf.Failure -> {
            stringResult.map()
        }
    }
}

inline fun <reified T> IRemoteConfigHandler.getFlow(
    key: String,
    defaultValue: T
): StateFlow<T> {
    val originalFlow = getStringFlow(key, "")
    return originalFlow.mapState { stringValue ->
        try {
            if (stringValue.isEmpty())
                defaultValue
            else
                serializer.decodeFromString<T>(stringValue)
        } catch (exception: Exception) {
            logger {
                error(
                    throwable = exception,
                    message = "Failed to decode string with key $key from remote config"
                )
            }
            defaultValue
        }
    }
}
