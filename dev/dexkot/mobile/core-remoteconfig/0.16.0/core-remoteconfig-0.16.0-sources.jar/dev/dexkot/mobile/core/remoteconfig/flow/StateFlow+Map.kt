package dev.dexkot.mobile.core.remoteconfig.flow

import kotlinx.coroutines.ExperimentalForInheritanceCoroutinesApi
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.StateFlow

/**
 * `StateFlow.map` liviano y **sin `CoroutineScope`**: preserva el `StateFlow` caliente de origen
 * en lugar de degradarlo a un `Flow` frío (como haría `kotlinx.coroutines.flow.map`).
 *
 * - [StateFlow.value] se computa on-demand como `transform(source.value)`.
 * - En `collect` mapea cada emisión del origen.
 *
 * No usa `stateIn` (no requiere exponer un scope) y no deduplica sobre el valor mapeado:
 * simplemente mapea el `StateFlow` caliente que ya provee el handler.
 */
@OptIn(ExperimentalForInheritanceCoroutinesApi::class)
fun <T, R> StateFlow<T>.mapState(
    transform: (T) -> R
): StateFlow<R> = object : StateFlow<R> {

    override val value: R
        get() = transform(this@mapState.value)

    override val replayCache: List<R>
        get() = listOf(value)

    override suspend fun collect(collector: FlowCollector<R>): Nothing {
        this@mapState.collect { sourceValue ->
            collector.emit(transform(sourceValue))
        }
    }

}
