package dev.dexkot.mobile.core.remoteconfig.provider

import dev.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import kotlinx.coroutines.flow.StateFlow

interface IRemoteConfigProvider {

    val remoteConfigHandler: IRemoteConfigHandler

    fun getBoolean(
        key: String
    ): Boolean?

    fun getString(
        key: String
    ): String?

    fun getLong(
        key: String
    ): Long?

    fun getBoolean(
        key: String,
        defaultValue: Boolean = false
    ): Boolean

    fun getLong(
        key: String,
        defaultValue: Long = 0L
    ): Long

    fun getString(
        key: String,
        defaultValue: String = ""
    ): String

    fun getBooleanFlow(
        key: String,
        defaultValue: Boolean
    ): StateFlow<Boolean>

    fun getLongFlow(
        key: String,
        defaultValue: Long
    ): StateFlow<Long>

    fun getStringFlow(
        key: String,
        defaultValue: String
    ): StateFlow<String>

}
