package dev.dexkot.mobile.core.remoteconfig.provider

import dev.dexkot.mobile.core.foundation.result.getOrDefault
import dev.dexkot.mobile.core.foundation.result.unwrap
import dev.dexkot.mobile.core.remoteconfig.handler.get
import dev.dexkot.mobile.core.remoteconfig.handler.getFlow
import kotlinx.coroutines.flow.Flow

inline fun <reified T> IRemoteConfigProvider.get(
    key: String
): T? {
    return remoteConfigHandler.get<T>(key).unwrap()
}

inline fun <reified T> IRemoteConfigProvider.get(
    key: String,
    defaultValue: T
): T {
    return remoteConfigHandler.get<T>(key).getOrDefault(defaultValue)
}

inline fun <reified T> IRemoteConfigProvider.getFlow(
    key: String,
    defaultValue: T
): Flow<T> {
    return remoteConfigHandler.getFlow(key, defaultValue)
}