package dev.dexkot.mobile.core.remoteconfig.error

import dev.dexkot.mobile.core.foundation.errors.ErrorEntity
import dev.dexkot.mobile.core.foundation.errors.ErrorSeverity
import dev.dexkot.mobile.core.foundation.CommonParcelize

@CommonParcelize
class ConfigNotFound(
    val configKey: String
): ErrorEntity.BusinessError(
    exception = null,
    severity = ErrorSeverity.INFO
)
