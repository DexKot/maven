package dev.dexkot.mobile.core.remoteconfig.handler

import dev.dexkot.mobile.core.foundation.result.ResultOf
import dev.dexkot.mobile.core.foundation.result.failureOf
import dev.dexkot.mobile.core.foundation.result.map
import dev.dexkot.mobile.core.foundation.result.successOf
import dev.dexkot.mobile.core.logger.interactors.ddl.logger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.Json

inline fun <reified T> IRemoteConfigHandler.get(key: String): ResultOf<T> {
    return when (val stringResult = getString(key)) {
        is ResultOf.Success -> {
            try {
                if (stringResult.data.isEmpty())
                    successOf()
                val data = serializer.decodeFromString<T>(stringResult.data)
                successOf(data)
            } catch (exception: Exception) {
                failureOf(exception)
            }
        }
        is ResultOf.Failure -> {
            stringResult.map()
        }
    }
}

inline fun <reified T> IRemoteConfigHandler.getFlow(
    key: String,
    defaultValue: T
): Flow<T> {
    val originalFlow = getStringFlow(key, "")
    return originalFlow.map { stringValue ->
        try {
            if (stringValue.isEmpty())
                defaultValue
            else
                serializer.decodeFromString<T>(stringValue)
        } catch (exception: Exception) {
            logger {
                error(
                    throwable = exception,
                    message = "Failed to decode string with key $key from remote config"
                )
            }
            defaultValue
        }
    }
}
