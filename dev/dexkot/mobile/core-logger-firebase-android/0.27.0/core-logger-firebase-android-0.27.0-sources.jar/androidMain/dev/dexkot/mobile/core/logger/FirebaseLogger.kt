package dev.dexkot.mobile.core.logger

import android.os.Bundle
import dev.dexkot.mobile.core.logger.events.LogEvent
import dev.dexkot.mobile.core.logger.levels.Level
import com.google.firebase.Firebase
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.analytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.crashlytics.crashlytics

actual class FirebaseLogger actual constructor() : ILogger {

    private val analytics: FirebaseAnalytics = Firebase.analytics
    private val crashlytics: FirebaseCrashlytics = Firebase.crashlytics

    actual override fun setUserId(identifier: String) {
        analytics.setUserId(identifier)
        crashlytics.setUserId(identifier)
    }

    actual override fun removeUserId() {
        analytics.setUserId(null)
        crashlytics.setUserId("")
    }

    actual override fun setUserProperty(key: String, value: String?) {
        analytics.setUserProperty(key, value)
    }

    actual override fun removeUserProperty(key: String) {
        analytics.setUserProperty(key, null)
    }

    actual override fun log(event: LogEvent) {
        analytics.logEvent(event.type, event.firebaseParameters().toBundle())
    }

    actual override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) = Unit

    actual override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        message?.let { crashlytics.log(it) }
        params.forEach { param -> setCustomKey(param.key, param.value) }
        crashlytics.recordException(throwable)
    }

    private fun Map<String, String>.toBundle(): Bundle = Bundle().apply {
        forEach { (key, value) -> putString(key, value) }
    }

    private fun setCustomKey(key: String, value: Any) {
        when (value) {
            is String -> crashlytics.setCustomKey(key, value)
            is Boolean -> crashlytics.setCustomKey(key, value)
            is Int -> crashlytics.setCustomKey(key, value)
            is Long -> crashlytics.setCustomKey(key, value)
            is Float -> crashlytics.setCustomKey(key, value)
            is Double -> crashlytics.setCustomKey(key, value)
            else -> crashlytics.setCustomKey(key, value.toString())
        }
    }

}
