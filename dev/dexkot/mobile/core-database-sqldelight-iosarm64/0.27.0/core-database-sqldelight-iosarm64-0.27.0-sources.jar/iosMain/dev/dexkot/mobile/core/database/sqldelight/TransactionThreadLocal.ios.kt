package dev.dexkot.mobile.core.database.sqldelight

import kotlin.native.concurrent.ThreadLocal

@ThreadLocal
private var currentTransaction: Transaction<*>? = null

internal actual fun currentThreadTransaction(): Transaction<*>? = currentTransaction

internal actual fun setCurrentThreadTransaction(value: Transaction<*>?) {
    currentTransaction = value
}
