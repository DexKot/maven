package dev.dexkot.mobile.core.annotation

/**
 * Defines a mapping between an intention/use case parameter and its logged representation.
 *
 * @param logName The name used in log output (e.g., "script_id")
 * @param paramName The actual property/parameter name in code (e.g., "scriptId")
 *
 * Usage in @LogIntention:
 * ```
 * @LogIntention(
 *     identifier = "open_script",
 *     params = [LogParam(logName = "script_id", paramName = "scriptId")]
 * )
 * class OpenScript(val scriptId: Long): HomeIntention
 * ```
 *
 * Usage in @AutoLogUseCase:
 * ```
 * @AutoLogUseCase(
 *     identifier = "delete_script",
 *     params = [LogParam(logName = "script_id", paramName = "scriptId")]
 * )
 * interface IDeleteScriptUseCase {
 *     suspend operator fun invoke(scriptId: Long): ResultOf<Unit>
 * }
 * ```
 */
@Target(AnnotationTarget.ANNOTATION_CLASS)
@Retention(AnnotationRetention.SOURCE)
annotation class LogParam(
    val logName: String,
    val paramName: String
)