package dev.dexkot.mobile.core.annotation

/**
 * Marks an Intention subclass with logging metadata.
 *
 * When a ViewModel is annotated with @AutoLogViewModel, the KSP processor scans
 * the Intention type parameter's subclasses for this annotation to generate
 * intention logging in the ViewModel decorator.
 *
 * @param identifier The unique identifier for this intention in logs (e.g., "go_back", "create_script")
 * @param params Optional array of LogParam mappings for logging intention properties.
 *
 * Usage:
 * ```
 * sealed interface HomeIntention {
 *
 *     @AutoLogIntention("go_back")
 *     data object Back: HomeIntention
 *
 *     @AutoLogIntention(
 *         identifier = "open_script",
 *         params = [LogParam(logName = "script_id", paramName = "scriptId")]
 *     )
 *     class OpenScript(val scriptId: Long): HomeIntention
 * }
 * ```
 */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.SOURCE)
annotation class AutoLogIntention(
    val identifier: String,
    val params: Array<LogParam> = []
)
