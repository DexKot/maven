package dev.dexkot.mobile.core.annotation

@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.SOURCE)
annotation class AutoLogUseCase(
    val identifier: String,
    val params: Array<LogParam> = [],
    val captureEvent: Boolean = false
)
