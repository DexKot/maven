package dev.dexkot.mobile.core.annotation

@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.SOURCE)
annotation class AutoLogNavAction(
    val identifier: String,
    val params: Array<LogParam> = []
)
