package com.dexkot.mobile.core.ui.compose.logger

import com.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import com.dexkot.mobile.core.logger.events.ui.interaction.Interaction
import com.dexkot.mobile.core.logger.events.ui.permission.Status
import com.dexkot.mobile.core.logger.events.ui.state.UiState

object DummyLoggerInteractor: ILoggerInteractor {

    override fun enter() = Unit

    override fun exit() = Unit

    override fun navigate(navigationId: String, params: Map<String, String>) = Unit

    override fun permission(permissions: List<String>) = Unit

    override fun permission(permissions: Map<String, Status>) = Unit

    override fun interaction(
        elementId: String,
        interaction: Interaction,
        extras: Map<String, String>
    ) = Unit

    override fun uiState(
        elementId: String,
        state: UiState,
        extras: Map<String, String>
    ) = Unit

    override fun intention(intentionId: String, params: Map<String, String>) = Unit

}
