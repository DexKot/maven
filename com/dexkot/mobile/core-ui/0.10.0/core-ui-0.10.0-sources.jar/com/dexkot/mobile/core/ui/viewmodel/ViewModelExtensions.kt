package com.dexkot.mobile.core.ui.viewmodel

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue

@Composable
fun <Model, Intention> IViewModel<Model, Intention>.ModelUpdates(
    onUpdate: (Model) -> Unit
) {
    val model by model.collectAsState()
    LaunchedEffect(model){
        onUpdate(model)
    }
}
