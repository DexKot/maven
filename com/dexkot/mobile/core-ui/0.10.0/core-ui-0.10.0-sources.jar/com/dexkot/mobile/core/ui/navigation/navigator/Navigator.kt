package com.dexkot.mobile.core.ui.navigation.navigator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContract
import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavHostController
import androidx.navigation.NavOptionsBuilder
import androidx.navigation.navOptions
import com.dexkot.mobile.core.ui.navigation.navigator.INavigator.Companion.RESULT_KEY

class Navigator(
    private val launcher: ActivityResultLauncher<Intent>,
    override val navHostController: NavHostController,
    override val activity: FragmentActivity,
    override val deepLinkScheme: String,
): INavigator {

    override fun navigate(
        uri: Uri,
        args: Bundle?,
        builder: NavOptionsBuilder.() -> Unit
    ) {
        val normalized = uri.buildUpon()
            .fragment(null)
            .path(uri.path?.trimEnd('/')?.ifEmpty { null })
            .build()
        navHostController.navigate(
            deepLink = normalized,
            navOptions = navOptions(builder),
        )
        args?.let {
            navHostController.currentBackStackEntry?.savedStateHandle?.setNavArgs(it)
        }
    }

    override fun navigate(builder: Activity.() -> Intent) {
        navigate(activity.builder())
    }

    override fun navigate(intent: Intent) {
        activity.startActivity(intent)
    }

    override fun popBackStack(
        result: Bundle?
    ) {
        val internalBack = navHostController.popBackStack()
        if (internalBack) {
            result?.let {
                navHostController.currentBackStackEntry?.savedStateHandle?.setNavResult(it)
            }
        } else {
            val intent = Intent()
            result?.let { intent.putExtras(it) }
            activity.setResult(Activity.RESULT_OK, intent)
            activity.finish()
        }
    }

    override fun <Input,Output> navigateForResult(
        contract: ActivityResultContract<Input, Output>,
        launch: (Activity, (Input) -> Unit) -> Unit
    ) {
        launch(
            activity
        ) { input ->
            launcher.launch(contract.createIntent(activity, input))
        }
    }

    override fun onActivityResult(
        activityResult: ActivityResult
    ) {
        navHostController.currentBackStackEntry
            ?.savedStateHandle
            ?.setNavResult(bundleOf(RESULT_KEY to activityResult))
    }

}
