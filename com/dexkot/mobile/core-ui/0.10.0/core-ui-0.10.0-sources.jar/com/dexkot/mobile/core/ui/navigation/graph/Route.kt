package com.dexkot.mobile.core.ui.navigation.graph

import androidx.compose.runtime.Composable
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavDeepLink
import androidx.navigation.navDeepLink
import com.dexkot.mobile.core.ui.compose.transitions.DefaultTransitions
import com.dexkot.mobile.core.ui.compose.transitions.Transitions
import com.dexkot.mobile.core.ui.viewmodel.IScreenViewModel

open class Route<Model, Intention>(
    val identifier: String,
    val route: String,
    val deepLinks: List<NavDeepLink> = listOf(navDeepLink { uriPattern = route }),
    val arguments: List<NamedNavArgument> = listOf(),
    val viewModelFactory: @Composable () -> IScreenViewModel<Model, Intention>,
    val screenContent: @Composable (IScreenViewModel<Model, Intention>) -> Unit,
    val transitions: Transitions = DefaultTransitions
)
