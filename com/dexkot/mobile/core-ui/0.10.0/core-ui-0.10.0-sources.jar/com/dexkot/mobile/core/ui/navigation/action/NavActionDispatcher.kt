package com.dexkot.mobile.core.ui.navigation.action

import com.dexkot.mobile.core.ui.navigation.navigator.INavActionExecutor
import kotlin.reflect.KClass

class NavActionDispatcher(
    factories: List<INavActionFactory<*>>
) : INavActionDispatcher {

    private val factoryMap: Map<KClass<*>, INavActionFactory<*>> =
        factories.associateBy { it.actionType }

    @Suppress("UNCHECKED_CAST")
    override fun dispatch(action: INavAction): INavActionExecutor {
        val factory = factoryMap[action::class]
            ?: error("No INavActionFactory registered for ${action::class.qualifiedName}")
        return (factory as INavActionFactory<INavAction>).resolve(action)
    }

}
