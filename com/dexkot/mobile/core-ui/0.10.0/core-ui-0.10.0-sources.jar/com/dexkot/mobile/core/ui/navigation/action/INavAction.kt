package com.dexkot.mobile.core.ui.navigation.action

interface INavAction
