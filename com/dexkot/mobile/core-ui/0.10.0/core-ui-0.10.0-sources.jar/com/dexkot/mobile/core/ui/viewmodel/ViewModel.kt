package com.dexkot.mobile.core.ui.viewmodel

@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.CLASS)
annotation class ViewModel
