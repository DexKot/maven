package com.dexkot.mobile.core.ui.preferences

import android.content.SharedPreferences
import androidx.core.content.edit

fun SharedPreferences.setString(key: String, value: String) = edit { putString(key, value) }

fun SharedPreferences.setBoolean(key: String, value: Boolean) = edit { putBoolean(key, value) }

fun SharedPreferences.setFloat(key: String, value: Float) = edit { putFloat(key, value) }

fun SharedPreferences.setStringSet(key: String, value: Set<String>) = edit { putStringSet(key, value) }

fun SharedPreferences.delete(key: String) = edit { remove(key) }
