package com.dexkot.mobile.core.ui.compose.permission

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.dexkot.mobile.core.permission.Permission
import com.dexkot.mobile.core.permission.PermissionState

@Composable
fun rememberPermissionState(permission: Permission): State<PermissionState> {
    val controller = LocalPermissionController.current

    val state = remember { mutableStateOf(controller.getState(permission)) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, permission) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                state.value = controller.getState(permission)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    return state
}

@Composable
fun rememberPermissionsState(
    vararg permissions: Permission
): State<Map<Permission, PermissionState>> {
    val controller = LocalPermissionController.current
    val permissionList = remember { permissions.toList() }

    val states = remember {
        mutableStateOf(permissionList.associateWith { controller.getState(it) })
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, permissionList) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                states.value = permissionList.associateWith { controller.getState(it) }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    return states
}
