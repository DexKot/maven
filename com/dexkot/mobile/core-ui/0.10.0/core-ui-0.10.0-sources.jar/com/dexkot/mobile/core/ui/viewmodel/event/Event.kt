package com.dexkot.mobile.core.ui.viewmodel.event

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
class Event<T>(
    private var data: @RawValue T,
    private var hasBeenHandled: Boolean = false
): Parcelable {

    fun handle(): T? {
        return if (hasBeenHandled) {
            null
        } else {
            hasBeenHandled = true
            data
        }
    }

}
