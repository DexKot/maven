package com.dexkot.mobile.core.ui.viewmodel

import android.os.Bundle
import kotlinx.coroutines.flow.StateFlow

interface IViewModel<Model, Intention> {

    val model: StateFlow<Model>

    fun input(intent: Intention)

    fun onCreate(args: Bundle? = null) { }

    fun onResume(result: Bundle? = null) { }

    fun onStop() { }

}
