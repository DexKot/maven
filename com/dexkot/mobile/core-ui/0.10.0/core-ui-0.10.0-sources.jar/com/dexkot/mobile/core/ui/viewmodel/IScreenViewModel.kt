package com.dexkot.mobile.core.ui.viewmodel

import com.dexkot.mobile.core.ui.navigation.action.INavAction
import com.dexkot.mobile.core.ui.viewmodel.event.Event
import kotlinx.coroutines.flow.StateFlow

interface IScreenViewModel<Model, Intention> : IViewModel<Model, Intention> {

    val nav: StateFlow<Event<INavAction>?>

}
