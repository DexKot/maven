package com.dexkot.mobile.core.ui.preferences

import kotlinx.coroutines.flow.StateFlow

interface IUiPreferences {

    fun setBoolean(key: String, value: Boolean)

    fun getBoolean(key: String, defaultValue: Boolean = false): Boolean

    fun getBooleanFlow(
        key: String,
        defaultValue: Boolean = false
    ): StateFlow<Boolean>

    fun getString(key: String, defaultValue: String = ""): String

    fun setString(key: String, value: String)

    fun getStringFlow(
        key: String,
        defaultValue: String = ""
    ): StateFlow<String>

    fun getStringSet(key: String, defaultValue: Set<String> = emptySet()): Set<String>

    fun setStringSet(key: String, value: Set<String>)

    fun getStringSetFlow(
        key: String,
        defaultValue: Set<String> = emptySet()
    ): StateFlow<Set<String>>

    fun setFloat(key: String, value: Float)

    fun getFloat(key: String, defaultValue: Float = 0f): Float

    fun getFloatFlow(
        key: String,
        defaultValue: Float = 0f
    ): StateFlow<Float>

    fun remove(key: String)

}
