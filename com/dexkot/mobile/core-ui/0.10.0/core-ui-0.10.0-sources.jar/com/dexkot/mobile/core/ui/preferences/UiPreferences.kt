package com.dexkot.mobile.core.ui.preferences

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Collections

class UiPreferences(
    private val sharedPreferences: SharedPreferences,
): IUiPreferences {

    private val boolFlows: MutableMap<String, MutableStateFlow<Boolean>> = Collections.synchronizedMap(mutableMapOf())
    private val stringFlows: MutableMap<String, MutableStateFlow<String>> = Collections.synchronizedMap(mutableMapOf())
    private val stringSetFlows: MutableMap<String, MutableStateFlow<Set<String>>> = Collections.synchronizedMap(mutableMapOf())
    private val floatFlows: MutableMap<String, MutableStateFlow<Float>> = Collections.synchronizedMap(mutableMapOf())

    override fun setBoolean(key: String, value: Boolean) {
        sharedPreferences.setBoolean(key, value)
        boolFlows[key]?.value = value
    }

    override fun getBoolean(key: String, defaultValue: Boolean): Boolean {
        return sharedPreferences.getBoolean(key, defaultValue)
    }

    override fun getBooleanFlow(
        key: String,
        defaultValue: Boolean,
    ): StateFlow<Boolean> {
        return boolFlows.createFlow(key) { getBoolean(key, defaultValue) }
    }

    override fun setString(key: String, value: String) {
        sharedPreferences.setString(key, value)
        stringFlows[key]?.value = value
    }

    override fun getString(key: String, defaultValue: String): String {
        return sharedPreferences.getString(key, defaultValue) ?: defaultValue
    }

    override fun getStringFlow(
        key: String,
        defaultValue: String,
    ): StateFlow<String> {
        return stringFlows.createFlow(key) { getString(key, defaultValue) }
    }

    override fun getStringSet(
        key: String,
        defaultValue: Set<String>,
    ): Set<String> {
        return sharedPreferences.getStringSet(key, defaultValue) ?: defaultValue
    }

    override fun setStringSet(
        key: String,
        value: Set<String>,
    ) {
        sharedPreferences.setStringSet(key, value)
        stringSetFlows[key]?.value = value
    }

    override fun getStringSetFlow(
        key: String,
        defaultValue: Set<String>,
    ): StateFlow<Set<String>> {
        return stringSetFlows.createFlow(key) { getStringSet(key, defaultValue) }
    }

    override fun setFloat(key: String, value: Float) {
        sharedPreferences.setFloat(key, value)
        floatFlows[key]?.value = value
    }

    override fun getFloat(key: String, defaultValue: Float): Float {
        return sharedPreferences.getFloat(key, defaultValue)
    }

    override fun getFloatFlow(
        key: String,
        defaultValue: Float,
    ): StateFlow<Float> {
        return floatFlows.createFlow(key) { getFloat(key, defaultValue) }
    }

    override fun remove(key: String) {
        sharedPreferences.delete(key)
        boolFlows.remove(key)
        stringFlows.remove(key)
        stringSetFlows.remove(key)
        floatFlows.remove(key)
    }

    private fun <T> MutableMap<String, MutableStateFlow<T>>.createFlow(
        key: String,
        getValue: () -> T
    ): StateFlow<T> {
        val existing = this[key]
        if (existing != null) return existing.asStateFlow()
        val flow = MutableStateFlow(getValue())
        this[key] = flow
        return flow.asStateFlow()
    }

}
