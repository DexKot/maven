package com.dexkot.mobile.core.ui.compose.remoteconfig

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import com.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider

val LocalRemoteConfig = staticCompositionLocalOf<IRemoteConfigProvider> { DummyRemoteConfigProvider }

@Composable
fun RemoteConfig(
    remoteConfigProvider: IRemoteConfigProvider,
    content: @Composable () -> Unit
) {

    CompositionLocalProvider(
        LocalRemoteConfig provides remoteConfigProvider,
        content = content
    )

}
