package com.dexkot.mobile.core.ui.navigation.navigator

interface INavActionExecutor {

    operator fun invoke(navigator: INavigator)

}
