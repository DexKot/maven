package com.dexkot.mobile.core.ui.navigation.action

import com.dexkot.mobile.core.ui.navigation.navigator.INavActionExecutor

interface INavActionDispatcher {

    fun dispatch(action: INavAction): INavActionExecutor

}
