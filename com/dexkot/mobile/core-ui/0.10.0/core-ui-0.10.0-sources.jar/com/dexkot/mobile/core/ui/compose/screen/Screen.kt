package com.dexkot.mobile.core.ui.compose.screen

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.dexkot.mobile.core.logger.interactors.ui.ILoggerInteractor
import com.dexkot.mobile.core.permission.controller.IPermissionController
import com.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import com.dexkot.mobile.core.ui.compose.logger.LocalLogger
import com.dexkot.mobile.core.ui.compose.logger.Logger
import com.dexkot.mobile.core.ui.compose.navigation.NavigationSubscriber
import com.dexkot.mobile.core.ui.compose.permission.PermissionController
import com.dexkot.mobile.core.ui.compose.permission.withLogging
import com.dexkot.mobile.core.ui.compose.remoteconfig.RemoteConfig
import com.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import com.dexkot.mobile.core.ui.navigation.action.INavActionLogDecorator
import com.dexkot.mobile.core.ui.navigation.action.withLogging
import com.dexkot.mobile.core.ui.navigation.graph.Route
import com.dexkot.mobile.core.ui.navigation.navigator.INavigator

@Composable
internal fun <Model, Intention> Screen(
    route: Route<Model, Intention>,
    navigator: INavigator,
    permissionController: IPermissionController,
    dispatcher: INavActionDispatcher,
    remoteConfigProvider: IRemoteConfigProvider,
    loggerFactory: (sourceComponent: String) -> ILoggerInteractor,
    decorators: List<INavActionLogDecorator>
) {

    RemoteConfig(
        remoteConfigProvider = remoteConfigProvider
    ) {

        Logger(
            loggerInteractor = loggerFactory(route.identifier)
        ) {

            val logger = LocalLogger.current

            val loggedPermissionController = remember(permissionController, logger) {
                permissionController.withLogging(logger)
            }

            PermissionController(
                permissionController = loggedPermissionController
            ) {

                val loggingDispatcher = remember(dispatcher, logger) {
                    dispatcher.withLogging(logger, decorators)
                }

                val viewModel = route.viewModelFactory()

                NavigationSubscriber(
                    viewModel = viewModel,
                    navigator = navigator,
                    dispatcher = loggingDispatcher
                )

                route.screenContent(viewModel)

            }

        }

    }

}
