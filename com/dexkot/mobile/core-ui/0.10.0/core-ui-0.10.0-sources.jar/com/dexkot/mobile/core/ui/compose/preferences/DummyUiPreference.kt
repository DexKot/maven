package com.dexkot.mobile.core.ui.compose.preferences

import com.dexkot.mobile.core.ui.preferences.IUiPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object DummyUiPreference : IUiPreferences {

    override fun setBoolean(key: String, value: Boolean) = Unit

    override fun getBoolean(key: String, defaultValue: Boolean): Boolean = defaultValue

    override fun getBooleanFlow(key: String, defaultValue: Boolean): StateFlow<Boolean> {
        return MutableStateFlow(defaultValue).asStateFlow()
    }

    override fun setString(key: String, value: String) = Unit

    override fun getString(key: String, defaultValue: String): String = defaultValue

    override fun getStringFlow(key: String, defaultValue: String): StateFlow<String> {
        return MutableStateFlow(defaultValue).asStateFlow()
    }

    override fun getStringSet(key: String, defaultValue: Set<String>): Set<String> = defaultValue

    override fun setStringSet(key: String, value: Set<String>) = Unit

    override fun getStringSetFlow(key: String, defaultValue: Set<String>): StateFlow<Set<String>> {
        return MutableStateFlow(defaultValue).asStateFlow()
    }

    override fun setFloat(key: String, value: Float) = Unit

    override fun getFloat(key: String, defaultValue: Float): Float = defaultValue

    override fun getFloatFlow(key: String, defaultValue: Float): StateFlow<Float> {
        return MutableStateFlow(defaultValue).asStateFlow()
    }

    override fun remove(key: String) = Unit

}
