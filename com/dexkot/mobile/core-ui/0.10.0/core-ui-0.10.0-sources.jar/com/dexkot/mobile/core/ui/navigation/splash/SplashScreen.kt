package com.dexkot.mobile.core.ui.navigation.splash

import android.os.Bundle
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.NavHostController

internal fun NavHostController.splashScreen(
    route: String,
    removeSplash: () -> Unit
) {
    addOnDestinationChangedListener(
        object: NavController.OnDestinationChangedListener {
            override fun onDestinationChanged(
                controller: NavController,
                destination: NavDestination,
                arguments: Bundle?
            ) {
                if (!controller.containsRoute(route)) {
                    removeSplash()
                    controller.removeOnDestinationChangedListener(this)
                }
            }
        }
    )
}

private fun NavController.containsRoute(
    route: String
): Boolean {
    return try {
        getBackStackEntry(route)
        true
    } catch (ignored: Exception) {
        false
    }
}
