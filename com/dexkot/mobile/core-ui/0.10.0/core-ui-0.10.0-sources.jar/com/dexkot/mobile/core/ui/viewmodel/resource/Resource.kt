package com.dexkot.mobile.core.ui.viewmodel.resource

import android.os.Parcelable
import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
sealed class Resource<T>(
    open val data: @RawValue T? = null
): Parcelable {

    abstract fun <R> map(block: (data: T) -> R): Resource<R>

    abstract fun map(): Resource<Unit>

    abstract fun update(block: (data: T) -> T): Resource<T>

    class None<T>(
        override val data: @RawValue T? = null
    ): Resource<T>(
        data = data
    ) {
        override fun <R> map(block: (data: T) -> R): Resource<R> = None(data = data?.let(block))
        override fun map(): Resource<Unit> = None()
        override fun update(block: (data: T) -> T): Resource<T> = None(data = data?.let { block(it) })
    }

    fun toNone(): None<T> {
        return None()
    }

    class Loading<T>(
        override val data: @RawValue T? = null
    ): Resource<T>(
        data = data
    ) {
        override fun <R> map(block: (data: T) -> R): Resource<R> = Loading(data = data?.let(block))
        override fun map(): Resource<Unit> = Loading()
        override fun update(block: (data: T) -> T): Resource<T> = Loading(data = data?.let { block(it) })
    }

    fun toLoading(data: T? = this.data): Loading<T> {
        return Loading(data = data)
    }

    class Loaded<T>(
        override val data: @RawValue T
    ): Resource<T>() {
        override fun <R> map(block: (data: T) -> R): Resource<R> = Loaded(data = block(data))
        override fun map(): Resource<Unit> = Loaded(Unit)
        override fun update(block: (data: T) -> T): Resource<T> = Loaded(data = block(data))
    }

    fun toLoaded(data: T): Loaded<T> {
        return Loaded(data = data)
    }

    class Error<T>(
        override val data: @RawValue T? = null,
        val error: ErrorEntity
    ) : Resource<T>(
        data = data
    ) {
        override fun <R> map(block: (data: T) -> R): Resource<R> = Error(data = data?.let(block), error = error)
        override fun map(): Resource<Unit> = Error(error = error)
        override fun update(block: (data: T) -> T): Resource<T> = Error(data = data?.let { block(data) }, error = error)
    }

    fun toError(error: ErrorEntity): Error<T> {
        return Error(
            data = this.data,
            error = error
        )
    }
}
