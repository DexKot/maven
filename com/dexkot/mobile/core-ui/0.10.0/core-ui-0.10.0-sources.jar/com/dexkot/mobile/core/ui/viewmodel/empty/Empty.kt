package com.dexkot.mobile.core.ui.viewmodel.empty

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
object Empty: Parcelable
