package com.dexkot.mobile.core.ui.navigation.graph

interface IGraph {
    val route: String
    val startDestination: Route<*, *>
    val routes: List<Route<*, *>>
}

open class Graph(
    override val route: String,
    override val startDestination: Route<*, *>,
    override val routes: List<Route<*, *>>
): IGraph
