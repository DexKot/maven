package com.dexkot.mobile.core.ui.compose.permission

import android.app.Activity
import android.content.SharedPreferences
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import com.dexkot.mobile.core.permission.controller.IPermissionController
import com.dexkot.mobile.core.permission.controller.PermissionController

@Composable
fun rememberPermissionController(
    activity: Activity,
    preferences: SharedPreferences
): IPermissionController {
    lateinit var permissionController: PermissionController

    val singlePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionController.onSinglePermissionResult(granted)
    }

    val multiplePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grantedMap ->
        permissionController.onMultiplePermissionsResult(grantedMap)
    }

    permissionController = PermissionController(
        activity = activity,
        preferences = preferences,
        singlePermissionLauncher = singlePermissionLauncher,
        multiplePermissionsLauncher = multiplePermissionsLauncher
    )

    return permissionController
}
