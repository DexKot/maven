package com.dexkot.mobile.core.ui.compose.transitions

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically

val ModalTransition = Transitions(
    enterTransition = {
        slideInVertically(
            animationSpec = tween(durationMillis = 250, delayMillis = 100, easing = LinearOutSlowInEasing),
            initialOffsetY = { it },
        )
    },
    exitTransition = {
        fadeOut(animationSpec = tween(durationMillis = 350, delayMillis = 350))
    },
    popEnterTransition = {
        EnterTransition.None
    },
    popExitTransition = {
        slideOutVertically(
            animationSpec = tween(durationMillis = 250, delayMillis = 100, easing = FastOutLinearInEasing),
            targetOffsetY = { it },
        )
    }
)
