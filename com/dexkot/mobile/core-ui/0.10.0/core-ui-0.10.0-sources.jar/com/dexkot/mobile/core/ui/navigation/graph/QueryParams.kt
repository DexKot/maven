package com.dexkot.mobile.core.ui.navigation.graph

import android.net.Uri

fun createRoute(
    route: String,
    queryParams: Set<String>,
): String {
    var result = route
    queryParams.forEach {
        result = result.addQueryParameter(it)
    }
    return result
}

private fun String.addQueryParameter(
    key: String,
): String {
    val separator = if (!contains("?")) "?" else "&"
    return "$this$separator$key={$key}"
}

fun <T> String.queryParameter(
    key: String,
    value: T?,
): String = queryParameter(
    key = key,
    value = value?.toString(),
)

fun String.queryParameter(
    key: String,
    value: String?,
): String {
    val result = if (value == null) {
        replace(regex = Regex("&?$key=\\{$key\\}"), replacement = "")
    } else {
        replace(oldValue = "{$key}", newValue = Uri.encode(value))
    }
    return result.removeSuffix("?")
}
