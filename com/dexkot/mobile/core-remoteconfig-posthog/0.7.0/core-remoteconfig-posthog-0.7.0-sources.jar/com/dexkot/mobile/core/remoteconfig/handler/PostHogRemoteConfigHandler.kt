package com.dexkot.mobile.core.remoteconfig.handler

import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.result.ResultOf
import com.dexkot.mobile.core.foundation.result.getOrDefault
import com.dexkot.mobile.core.logger.interactors.ddl.logger
import com.dexkot.mobile.core.remoteconfig.error.ConfigNotFound
import com.posthog.PostHogInterface
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.util.Collections

class PostHogRemoteConfigHandler(
    private val postHog: PostHogInterface,
    private val coroutineScope: CoroutineScope,
    override val serializer: Json
) : IRemoteConfigHandler {

    private val boolFlows: MutableMap<String, MutableStateFlow<Boolean>> = Collections.synchronizedMap(mutableMapOf())
    private val longFlows: MutableMap<String, MutableStateFlow<Long>> = Collections.synchronizedMap(mutableMapOf())
    private val stringFlows: MutableMap<String, MutableStateFlow<String>> = Collections.synchronizedMap(mutableMapOf())

    override suspend fun sync(): ResultOf<Boolean> {
        return withContext(Dispatchers.IO) {
            try {
                val deferred = CompletableDeferred<Unit>()
                postHog.reloadFeatureFlags {
                    deferred.complete(Unit)
                }
                withTimeout(SYNC_TIMEOUT_MS) {
                    deferred.await()
                }
                updateFlows()
                ResultOf.Success(true)
            } catch (exception: Exception) {
                logger {
                    error(
                        throwable = exception,
                        message = "Failed to sync PostHog feature flags"
                    )
                }
                ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
            }
        }
    }

    override fun getBoolean(key: String): ResultOf<Boolean> {
        val value = postHog.getFeatureFlagPayload(key)
            ?: return ResultOf.Failure(ConfigNotFound(configKey = key))
        return try {
            when (value) {
                is Boolean -> ResultOf.Success(value)
                else -> ResultOf.Success(value.toString().toBoolean())
            }
        } catch (exception: Exception) {
            logger {
                error(
                    throwable = exception,
                    message = "Failed to parse boolean for key $key from PostHog"
                )
            }
            ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
        }
    }

    override fun getString(key: String): ResultOf<String> {
        val value = postHog.getFeatureFlagPayload(key)
            ?: return ResultOf.Failure(ConfigNotFound(configKey = key))
        return try {
            ResultOf.Success(value.asConfigString())
        } catch (exception: Exception) {
            logger {
                error(
                    throwable = exception,
                    message = "Failed to parse string for key $key from PostHog"
                )
            }
            ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
        }
    }

    override fun getLong(key: String): ResultOf<Long> {
        val value = postHog.getFeatureFlagPayload(key)
            ?: return ResultOf.Failure(ConfigNotFound(configKey = key))
        return try {
            when (value) {
                is Number -> ResultOf.Success(value.toLong())
                else -> ResultOf.Success(value.toString().toLong())
            }
        } catch (exception: Exception) {
            logger {
                error(
                    throwable = exception,
                    message = "Failed to parse long for key $key from PostHog"
                )
            }
            ResultOf.Failure(ErrorEntity.UnexpectedError(exception = exception))
        }
    }

    override fun getBooleanFlow(key: String, defaultValue: Boolean): StateFlow<Boolean> {
        return boolFlows.createFlow(key) { getBoolean(key).getOrDefault(defaultValue) }
    }

    override fun getLongFlow(key: String, defaultValue: Long): StateFlow<Long> {
        return longFlows.createFlow(key) { getLong(key).getOrDefault(defaultValue) }
    }

    override fun getStringFlow(key: String, defaultValue: String): StateFlow<String> {
        return stringFlows.createFlow(key) { getString(key).getOrDefault(defaultValue) }
    }

    private fun updateFlows() {
        for ((key, flow) in boolFlows)
            flow.value = getBoolean(key).getOrDefault(flow.value)

        for ((key, flow) in longFlows)
            flow.value = getLong(key).getOrDefault(flow.value)

        for ((key, flow) in stringFlows)
            flow.value = getString(key).getOrDefault(flow.value)
    }

    private fun <T> MutableMap<String, MutableStateFlow<T>>.createFlow(
        key: String,
        getValue: () -> T
    ): StateFlow<T> {
        val existing = this[key]
        if (existing != null) return existing.asStateFlow()
        val flow = MutableStateFlow(getValue())
        this[key] = flow
        return flow.asStateFlow()
    }

    private fun Any.asConfigString(): String = when (this) {
        is String -> this
        is Map<*, *>, is List<*> -> serializer.encodeToString(JsonElement.serializer(), toJsonElement())
        else -> toString()
    }

    companion object {
        private const val SYNC_TIMEOUT_MS = 15_000L
    }
}

private fun Any?.toJsonElement(): JsonElement = when (this) {
    null -> JsonNull
    is Boolean -> JsonPrimitive(this)
    is Number -> JsonPrimitive(this)
    is String -> JsonPrimitive(this)
    is Map<*, *> -> JsonObject(entries.associate { (k, v) -> k.toString() to v.toJsonElement() })
    is List<*> -> JsonArray(map { it.toJsonElement() })
    else -> JsonPrimitive(toString())
}
