package com.dexkot.mobile.core.di.hilt.remoteconfig;

import com.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.serialization.json.Json;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "com.dexkot.mobile.core.di.hilt.qualifier.PostHogRemoteConfigQualifier",
    "com.dexkot.mobile.core.di.hilt.qualifier.RemoteConfigCoroutineScope"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RemoteConfigModule_ProvidePostHogRemoteConfigHandlerFactory implements Factory<IRemoteConfigHandler> {
  private final Provider<CoroutineScope> coroutineScopeProvider;

  private final Provider<Json> serializerProvider;

  public RemoteConfigModule_ProvidePostHogRemoteConfigHandlerFactory(
      Provider<CoroutineScope> coroutineScopeProvider, Provider<Json> serializerProvider) {
    this.coroutineScopeProvider = coroutineScopeProvider;
    this.serializerProvider = serializerProvider;
  }

  @Override
  public IRemoteConfigHandler get() {
    return providePostHogRemoteConfigHandler(coroutineScopeProvider.get(), serializerProvider.get());
  }

  public static RemoteConfigModule_ProvidePostHogRemoteConfigHandlerFactory create(
      Provider<CoroutineScope> coroutineScopeProvider, Provider<Json> serializerProvider) {
    return new RemoteConfigModule_ProvidePostHogRemoteConfigHandlerFactory(coroutineScopeProvider, serializerProvider);
  }

  public static IRemoteConfigHandler providePostHogRemoteConfigHandler(
      CoroutineScope coroutineScope, Json serializer) {
    return Preconditions.checkNotNullFromProvides(RemoteConfigModule.INSTANCE.providePostHogRemoteConfigHandler(coroutineScope, serializer));
  }
}
