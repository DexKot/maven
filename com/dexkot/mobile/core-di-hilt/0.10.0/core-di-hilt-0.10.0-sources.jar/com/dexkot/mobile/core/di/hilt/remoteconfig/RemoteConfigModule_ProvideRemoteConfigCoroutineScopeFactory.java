package com.dexkot.mobile.core.di.hilt.remoteconfig;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("com.dexkot.mobile.core.di.hilt.qualifier.RemoteConfigCoroutineScope")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RemoteConfigModule_ProvideRemoteConfigCoroutineScopeFactory implements Factory<CoroutineScope> {
  @Override
  public CoroutineScope get() {
    return provideRemoteConfigCoroutineScope();
  }

  public static RemoteConfigModule_ProvideRemoteConfigCoroutineScopeFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CoroutineScope provideRemoteConfigCoroutineScope() {
    return Preconditions.checkNotNullFromProvides(RemoteConfigModule.INSTANCE.provideRemoteConfigCoroutineScope());
  }

  private static final class InstanceHolder {
    static final RemoteConfigModule_ProvideRemoteConfigCoroutineScopeFactory INSTANCE = new RemoteConfigModule_ProvideRemoteConfigCoroutineScopeFactory();
  }
}
