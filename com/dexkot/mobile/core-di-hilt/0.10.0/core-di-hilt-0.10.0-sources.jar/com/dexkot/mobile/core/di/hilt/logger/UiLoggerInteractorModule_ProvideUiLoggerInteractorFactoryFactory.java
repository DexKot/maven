package com.dexkot.mobile.core.di.hilt.logger;

import com.dexkot.mobile.core.logger.ILogger;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UiLoggerInteractorModule_ProvideUiLoggerInteractorFactoryFactory implements Factory<IUiLoggerInteractorFactory> {
  private final Provider<ILogger> loggerProvider;

  public UiLoggerInteractorModule_ProvideUiLoggerInteractorFactoryFactory(
      Provider<ILogger> loggerProvider) {
    this.loggerProvider = loggerProvider;
  }

  @Override
  public IUiLoggerInteractorFactory get() {
    return provideUiLoggerInteractorFactory(loggerProvider.get());
  }

  public static UiLoggerInteractorModule_ProvideUiLoggerInteractorFactoryFactory create(
      Provider<ILogger> loggerProvider) {
    return new UiLoggerInteractorModule_ProvideUiLoggerInteractorFactoryFactory(loggerProvider);
  }

  public static IUiLoggerInteractorFactory provideUiLoggerInteractorFactory(ILogger logger) {
    return Preconditions.checkNotNullFromProvides(UiLoggerInteractorModule.INSTANCE.provideUiLoggerInteractorFactory(logger));
  }
}
