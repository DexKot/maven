package com.dexkot.mobile.core.di.hilt.ui

import android.content.Context
import android.content.SharedPreferences
import com.dexkot.mobile.core.di.hilt.qualifier.UiPreferencesQualifier
import com.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import com.dexkot.mobile.core.ui.navigation.action.INavActionFactory
import com.dexkot.mobile.core.ui.navigation.action.NavActionDispatcher
import com.dexkot.mobile.core.ui.preferences.IUiPreferences
import com.dexkot.mobile.core.ui.preferences.UiPreferences
import com.dexkot.mobile.core.ui.resources.IResourceProvider
import com.dexkot.mobile.core.ui.resources.ResourceProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object UiModule {

    @Provides
    @Singleton
    fun provideNavActionDispatcher(
        factories: Set<@JvmSuppressWildcards INavActionFactory<*>>
    ): INavActionDispatcher = NavActionDispatcher(factories.toList())

    @Provides
    @Singleton
    @UiPreferencesQualifier
    fun provideUiSharedPreferences(
        @ApplicationContext context: Context
    ): SharedPreferences = context.getSharedPreferences(
        "com.dexkot.ui.preferences",
        Context.MODE_PRIVATE
    )

    @Provides
    @Singleton
    fun provideUiPreferences(
        @UiPreferencesQualifier sharedPreferences: SharedPreferences
    ): IUiPreferences = UiPreferences(sharedPreferences)

    @Provides
    fun provideResourceProvider(
        @ApplicationContext context: Context
    ): IResourceProvider = ResourceProvider(context)

}
