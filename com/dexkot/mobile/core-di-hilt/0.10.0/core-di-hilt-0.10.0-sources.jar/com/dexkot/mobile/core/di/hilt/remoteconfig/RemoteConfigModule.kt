package com.dexkot.mobile.core.di.hilt.remoteconfig

import com.dexkot.mobile.core.di.hilt.qualifier.FirebaseRemoteConfigQualifier
import com.dexkot.mobile.core.di.hilt.qualifier.PostHogRemoteConfigQualifier
import com.dexkot.mobile.core.di.hilt.qualifier.RemoteConfigCoroutineScope
import com.dexkot.mobile.core.remoteconfig.handler.FirebaseRemoteConfigHandler
import com.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import com.dexkot.mobile.core.remoteconfig.handler.PostHogRemoteConfigHandler
import com.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import com.dexkot.mobile.core.remoteconfig.provider.RemoteConfigProvider
import com.google.firebase.Firebase
import com.google.firebase.remoteconfig.remoteConfig
import com.posthog.PostHog
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.serialization.json.Json
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RemoteConfigModule {

    @Provides
    @Singleton
    @RemoteConfigCoroutineScope
    fun provideRemoteConfigCoroutineScope(): CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Provides
    @Singleton
    fun provideSerializer(): Json = Json { ignoreUnknownKeys = true }

    @Provides
    @Singleton
    @FirebaseRemoteConfigQualifier
    fun provideFirebaseRemoteConfigHandler(
        @RemoteConfigCoroutineScope coroutineScope: CoroutineScope,
        serializer: Json
    ): IRemoteConfigHandler = FirebaseRemoteConfigHandler(
        firebaseRemoteConfig = Firebase.remoteConfig,
        coroutineScope = coroutineScope,
        syncTimeOut = 10L,
        serializer = serializer
    )

    @Provides
    @Singleton
    @PostHogRemoteConfigQualifier
    fun providePostHogRemoteConfigHandler(
        @RemoteConfigCoroutineScope coroutineScope: CoroutineScope,
        serializer: Json
    ): IRemoteConfigHandler = PostHogRemoteConfigHandler(
        postHog = PostHog,
        coroutineScope = coroutineScope,
        serializer = serializer
    )

    @Provides
    @Singleton
    fun provideRemoteConfigHandler(
        @FirebaseRemoteConfigQualifier handler: IRemoteConfigHandler
    ): IRemoteConfigHandler = handler

    @Provides
    @Singleton
    fun provideRemoteConfigProvider(
        handler: IRemoteConfigHandler
    ): IRemoteConfigProvider = RemoteConfigProvider(
        remoteConfigHandler = handler
    )

}
