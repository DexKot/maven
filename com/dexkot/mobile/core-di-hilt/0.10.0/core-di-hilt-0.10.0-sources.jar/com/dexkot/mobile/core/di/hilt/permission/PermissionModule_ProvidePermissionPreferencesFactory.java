package com.dexkot.mobile.core.di.hilt.permission;

import android.content.Context;
import android.content.SharedPreferences;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "com.dexkot.mobile.core.di.hilt.qualifier.PermissionPreferences",
    "dagger.hilt.android.qualifiers.ApplicationContext"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PermissionModule_ProvidePermissionPreferencesFactory implements Factory<SharedPreferences> {
  private final Provider<Context> contextProvider;

  public PermissionModule_ProvidePermissionPreferencesFactory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public SharedPreferences get() {
    return providePermissionPreferences(contextProvider.get());
  }

  public static PermissionModule_ProvidePermissionPreferencesFactory create(
      Provider<Context> contextProvider) {
    return new PermissionModule_ProvidePermissionPreferencesFactory(contextProvider);
  }

  public static SharedPreferences providePermissionPreferences(Context context) {
    return Preconditions.checkNotNullFromProvides(PermissionModule.INSTANCE.providePermissionPreferences(context));
  }
}
