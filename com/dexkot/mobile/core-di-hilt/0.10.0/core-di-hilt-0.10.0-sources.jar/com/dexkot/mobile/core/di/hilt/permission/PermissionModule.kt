package com.dexkot.mobile.core.di.hilt.permission

import android.content.Context
import android.content.SharedPreferences
import com.dexkot.mobile.core.di.hilt.qualifier.PermissionPreferences
import com.dexkot.mobile.core.permission.checker.IPermissionChecker
import com.dexkot.mobile.core.permission.checker.PermissionChecker
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object PermissionModule {

    @Provides
    @Singleton
    fun providePermissionChecker(
        @ApplicationContext context: Context
    ): IPermissionChecker = PermissionChecker(context)

    @Provides
    @Singleton
    @PermissionPreferences
    fun providePermissionPreferences(
        @ApplicationContext context: Context
    ): SharedPreferences = context.getSharedPreferences(
        "com.dexkot.permissions.preferences",
        Context.MODE_PRIVATE
    )

}
