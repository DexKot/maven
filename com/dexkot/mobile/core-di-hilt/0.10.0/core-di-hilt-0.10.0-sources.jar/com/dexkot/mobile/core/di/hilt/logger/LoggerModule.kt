package com.dexkot.mobile.core.di.hilt.logger

import com.dexkot.mobile.core.di.hilt.qualifier.ComposedLoggerQualifier
import com.dexkot.mobile.core.di.hilt.qualifier.ConsoleLoggerQualifier
import com.dexkot.mobile.core.di.hilt.qualifier.FirebaseLoggerQualifier
import com.dexkot.mobile.core.di.hilt.qualifier.PostHogLoggerQualifier
import com.dexkot.mobile.core.logger.ConsoleLogger
import com.dexkot.mobile.core.logger.FirebaseLogger
import com.dexkot.mobile.core.logger.ILogger
import com.dexkot.mobile.core.logger.PostHogLogger
import com.dexkot.mobile.core.logger.composed.plus
import com.dexkot.mobile.core.logger.context.LoggerContextElement
import com.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor as ILogicLoggerInteractor
import com.dexkot.mobile.core.logger.logicInteractor
import com.google.firebase.Firebase
import com.google.firebase.analytics.analytics
import com.google.firebase.crashlytics.crashlytics
import com.posthog.PostHog
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object LoggerModule {

    @Provides
    @Singleton
    @ConsoleLoggerQualifier
    fun provideConsoleLogger(): ILogger = ConsoleLogger()

    @Provides
    @Singleton
    @FirebaseLoggerQualifier
    fun provideFirebaseLogger(): ILogger = FirebaseLogger(
        analytics = Firebase.analytics,
        crashlytics = Firebase.crashlytics
    )

    @Provides
    @Singleton
    @PostHogLoggerQualifier
    fun providePostHogLogger(): ILogger = PostHogLogger(PostHog)

    @Provides
    @Singleton
    @ComposedLoggerQualifier
    fun provideComposedLogger(
        @ConsoleLoggerQualifier console: ILogger,
        @FirebaseLoggerQualifier firebase: ILogger,
        @PostHogLoggerQualifier postHog: ILogger
    ): ILogger = console + firebase + postHog

    @Provides
    @Singleton
    fun provideLogger(
        @ComposedLoggerQualifier logger: ILogger
    ): ILogger = logger

    @Provides
    @Singleton
    fun provideLogicLoggerInteractor(
        logger: ILogger
    ): ILogicLoggerInteractor {
        return logger.logicInteractor("app").also {
            LoggerContextElement.setDefault(it)
        }
    }

}
