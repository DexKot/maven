package com.dexkot.mobile.core.di.hilt.logger;

import com.dexkot.mobile.core.logger.ILogger;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "com.dexkot.mobile.core.di.hilt.qualifier.ComposedLoggerQualifier",
    "com.dexkot.mobile.core.di.hilt.qualifier.ConsoleLoggerQualifier",
    "com.dexkot.mobile.core.di.hilt.qualifier.FirebaseLoggerQualifier",
    "com.dexkot.mobile.core.di.hilt.qualifier.PostHogLoggerQualifier"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class LoggerModule_ProvideComposedLoggerFactory implements Factory<ILogger> {
  private final Provider<ILogger> consoleProvider;

  private final Provider<ILogger> firebaseProvider;

  private final Provider<ILogger> postHogProvider;

  public LoggerModule_ProvideComposedLoggerFactory(Provider<ILogger> consoleProvider,
      Provider<ILogger> firebaseProvider, Provider<ILogger> postHogProvider) {
    this.consoleProvider = consoleProvider;
    this.firebaseProvider = firebaseProvider;
    this.postHogProvider = postHogProvider;
  }

  @Override
  public ILogger get() {
    return provideComposedLogger(consoleProvider.get(), firebaseProvider.get(), postHogProvider.get());
  }

  public static LoggerModule_ProvideComposedLoggerFactory create(Provider<ILogger> consoleProvider,
      Provider<ILogger> firebaseProvider, Provider<ILogger> postHogProvider) {
    return new LoggerModule_ProvideComposedLoggerFactory(consoleProvider, firebaseProvider, postHogProvider);
  }

  public static ILogger provideComposedLogger(ILogger console, ILogger firebase, ILogger postHog) {
    return Preconditions.checkNotNullFromProvides(LoggerModule.INSTANCE.provideComposedLogger(console, firebase, postHog));
  }
}
