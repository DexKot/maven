package com.dexkot.mobile.core.di.hilt.logger;

import com.dexkot.mobile.core.logger.ILogger;
import com.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class LoggerModule_ProvideLogicLoggerInteractorFactory implements Factory<ILoggerInteractor> {
  private final Provider<ILogger> loggerProvider;

  public LoggerModule_ProvideLogicLoggerInteractorFactory(Provider<ILogger> loggerProvider) {
    this.loggerProvider = loggerProvider;
  }

  @Override
  public ILoggerInteractor get() {
    return provideLogicLoggerInteractor(loggerProvider.get());
  }

  public static LoggerModule_ProvideLogicLoggerInteractorFactory create(
      Provider<ILogger> loggerProvider) {
    return new LoggerModule_ProvideLogicLoggerInteractorFactory(loggerProvider);
  }

  public static ILoggerInteractor provideLogicLoggerInteractor(ILogger logger) {
    return Preconditions.checkNotNullFromProvides(LoggerModule.INSTANCE.provideLogicLoggerInteractor(logger));
  }
}
