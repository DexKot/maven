package com.dexkot.mobile.core.foundation

actual interface CommonParcelable
