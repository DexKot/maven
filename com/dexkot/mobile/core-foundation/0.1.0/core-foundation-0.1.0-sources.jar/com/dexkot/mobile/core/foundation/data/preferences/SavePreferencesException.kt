package com.dexkot.mobile.core.foundation.data.preferences

import java.io.IOException

class SavePreferencesException: IOException(
    "Error while saving preferences."
)
