package com.dexkot.mobile.core.foundation.errors

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * This class represents an error (the cause for an operation to do not finish).
 *
 * @property severity It is the severity of the error. It may be used by views to know how critical is the error and how to present it to the user.
 * @property exception It is the exception that caused the error to occur (it may be null if the error was not caused by an exception)
 */
@Parcelize
sealed class ErrorEntity(
    open val severity: ErrorSeverity,
    open val exception: Throwable? = null
): Parcelable {

    /**
     * This error represents that the an error occurred in the device (for example, a memory error, or some unexpected result / condition).
     */
    class DeviceError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    /**
     * This unexpected error / situation occurred (i.e. we don't know what happened or how to "recover" from that situation).
     */
    class UnexpectedError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    /**
     * This error represents that the an error occurred when trying to communicate with a remote service (e.g. a network error or a connection error).
     */
    class NetworkError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    /**
     * This error represents that the requested data is not available because the data source has not been populated yet.
     */
    class NoData(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.WARN,
        exception = exception
    )

    /**
     * This class is an open class to be inherited in order to represent any error of business (e.g. CharacterDoesNotExist, etc.).
     * It is not expected to have a BusinessError instance but to have instances of child classes (that is why constructor is protected).
     */
    open class BusinessError protected constructor(
        override val exception: Throwable? = null,
        override val severity: ErrorSeverity
    ): ErrorEntity (
        severity = severity,
        exception = exception
    )

}
