package com.dexkot.mobile.core.foundation.errors

sealed class ErrorEntity(
    open val severity: ErrorSeverity,
    open val exception: Throwable? = null
) {

    class DeviceError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    class UnexpectedError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    class NetworkError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    class NoData(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.WARN,
        exception = exception
    )

    open class BusinessError protected constructor(
        override val exception: Throwable? = null,
        override val severity: ErrorSeverity
    ): ErrorEntity(
        severity = severity,
        exception = exception
    )

}
