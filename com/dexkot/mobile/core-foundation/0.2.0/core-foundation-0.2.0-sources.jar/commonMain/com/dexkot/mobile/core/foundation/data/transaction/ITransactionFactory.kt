package com.dexkot.mobile.core.foundation.data.transaction

import com.dexkot.mobile.core.foundation.result.ResultOf

interface ITransactionFactory {

    suspend fun <Out> withTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out>

}
