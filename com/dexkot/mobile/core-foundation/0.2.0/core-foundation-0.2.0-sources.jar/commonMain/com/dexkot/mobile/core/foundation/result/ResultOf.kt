package com.dexkot.mobile.core.foundation.result

import com.dexkot.mobile.core.foundation.errors.ErrorEntity

/**
 * This class represents the result of an operation executed in a repository.
 * It may be a Success or a Failure.
 *
 * @param Data The expected type of the result data if we have a Success result
 */
sealed interface ResultOf<out Data> {

    /**
     * This class represents a Success result of an operation executed in the domain
     *
     * @param Data The expected type of the result data if we have a Success result
     * @property data The result of the operation
     */
    class Success<Data>(
        val data: Data
    ): ResultOf<Data>

    /**
     * This class represents a Failure result of an operation executed in the domain
     *
     * @param Data The expected type of the result data if we have a Success result
     * @property error The error that caused the operation failure
     */
    class Failure<Data>(
        val error: ErrorEntity
    ): ResultOf<Data>

}
