package com.dexkot.mobile.core.foundation.errors

/**
 * The severity of an error
 *
 * @property INFO It is not actually an error, but it is a condition that does not allow the operation to finish its execution.
 * @property WARN It is a Warning, something that it is not ok, but it is not something to worry about, or it is something that the user can fix.
 * @property ERROR It is actually an error (some exception or unexpected condition) that does not allow the operation to finish its execution.
 */
enum class ErrorSeverity {
    INFO, WARN, ERROR
}
