package com.dexkot.mobile.core.foundation.errors.mapper

import com.dexkot.mobile.core.foundation.errors.ErrorEntity

/**
 * A chain of [ErrorMapper]s that maps a [Throwable] to an [ErrorEntity].
 *
 * This class allows for the composition of multiple error mappers, where the first mapper in the chain
 * attempts to map the error, and if it fails, the next mapper in the chain is invoked.
 * This is useful for creating a flexible error handling mechanism that can be extended with additional mappers as needed.
 *
 * @property head The first [ErrorMapper] in the chain that will attempt to map the error.
 * @property tail The second [ErrorMapper] in the chain that will be invoked if the first mapper fails to map the error.
 */
internal class ErrorMapperChain(
    private val head: ErrorMapper,
    private val tail: ErrorMapper
): ErrorMapper {

    override fun map(
        throwable: Throwable
    ): ErrorEntity? {
        var entity = this.head.map(throwable)

        if (entity == null)
            entity = this.tail.map(throwable)

        return entity
    }

}