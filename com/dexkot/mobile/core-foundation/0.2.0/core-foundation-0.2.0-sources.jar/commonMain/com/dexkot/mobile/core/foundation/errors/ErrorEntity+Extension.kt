package com.dexkot.mobile.core.foundation.errors

fun deviceError(
    throwable: Throwable? = null
) = ErrorEntity.DeviceError(
    exception = throwable
)

fun networkError(
    throwable: Throwable? = null
) = ErrorEntity.NetworkError(
    exception = throwable
)

fun unexpectedError(
    throwable: Throwable? = null
) = ErrorEntity.UnexpectedError(
    exception = throwable
)