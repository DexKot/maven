package com.dexkot.mobile.core.foundation

expect interface CommonParcelable
