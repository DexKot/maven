package com.dexkot.mobile.core.foundation.errors

import com.dexkot.mobile.core.foundation.CommonParcelable
import com.dexkot.mobile.core.foundation.CommonParcelize

@CommonParcelize
sealed class ErrorEntity(
    open val severity: ErrorSeverity,
    open val exception: Throwable? = null
) : CommonParcelable {

    class DeviceError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    class UnexpectedError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    class NetworkError(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.ERROR,
        exception = exception
    )

    class NoData(
        override val exception: Throwable? = null
    ): ErrorEntity(
        severity = ErrorSeverity.WARN,
        exception = exception
    )

    open class BusinessError protected constructor(
        override val exception: Throwable? = null,
        override val severity: ErrorSeverity
    ): ErrorEntity(
        severity = severity,
        exception = exception
    )

}
