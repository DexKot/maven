package com.dexkot.mobile.core.foundation.data.preferences

import android.content.SharedPreferences

fun SharedPreferences.Editor.save() {
    if (!commit())
        throw SavePreferencesException()
}
