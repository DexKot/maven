package com.dexkot.mobile.core.foundation.data.preferences

class SavePreferencesException: RuntimeException(
    "Error while saving preferences."
)
