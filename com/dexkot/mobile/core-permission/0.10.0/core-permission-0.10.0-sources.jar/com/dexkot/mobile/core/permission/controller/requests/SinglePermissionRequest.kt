package com.dexkot.mobile.core.permission.controller.requests

import com.dexkot.mobile.core.permission.Permission
import com.dexkot.mobile.core.permission.PermissionResult

internal data class SinglePermissionRequest(
    val permission: Permission,
    val rationaleBefore: Boolean,
    val callback: (PermissionResult) -> Unit
)
