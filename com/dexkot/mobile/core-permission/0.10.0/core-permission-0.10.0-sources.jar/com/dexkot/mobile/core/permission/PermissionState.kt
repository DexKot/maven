package com.dexkot.mobile.core.permission

/**
 * Represents the complete state of a permission, including metadata about request history.
 *
 * @property status The current permission status (Granted, Denied, or PermanentlyDenied)
 * @property requiresRationale Whether Android recommends showing a rationale before requesting.
 *                             This is true when the user has previously denied the permission.
 * @property isFirstTimeEver Whether this permission has never been requested since app installation.
 * @property isFirstTimeThisSession Whether this permission has not been requested in the current app session.
 */
data class PermissionState(
    val status: PermissionStatus,
    val requiresRationale: Boolean,
    val isFirstTimeEver: Boolean,
    val isFirstTimeThisSession: Boolean
) {
    /**
     * Convenience property to check if the permission is granted.
     */
    val isGranted: Boolean
        get() = status == PermissionStatus.Granted

    /**
     * Whether a permission request can be made.
     * Returns false if the permission is permanently denied.
     */
    val canRequest: Boolean
        get() = status != PermissionStatus.PermanentlyDenied

    /**
     * Whether a disclosure dialog should be shown before requesting.
     * This is true for first-time requests or when rationale is required.
     */
    val shouldShowDisclosure: Boolean
        get() = !isGranted && (isFirstTimeEver || requiresRationale)

    companion object {
        /**
         * Default state representing a granted permission.
         */
        val Granted = PermissionState(
            status = PermissionStatus.Granted,
            requiresRationale = false,
            isFirstTimeEver = false,
            isFirstTimeThisSession = false
        )

    }
}
