package com.dexkot.mobile.core.permission.controller

import android.app.Activity
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.activity.result.ActivityResultLauncher
import androidx.core.app.ActivityCompat
import androidx.core.content.edit
import com.dexkot.mobile.core.permission.Permission
import com.dexkot.mobile.core.permission.PermissionResult
import com.dexkot.mobile.core.permission.PermissionState
import com.dexkot.mobile.core.permission.PermissionStatus
import com.dexkot.mobile.core.permission.controller.requests.MultiplePermissionsRequest
import com.dexkot.mobile.core.permission.controller.requests.SinglePermissionRequest

/**
 * Implementation of [IPermissionController] that queries Android permission APIs
 * and handles permission requests.
 *
 * @param activity Activity for checking permissions and shouldShowRequestPermissionRationale.
 * @param preferences SharedPreferences for tracking "first time ever" requests.
 * @param singlePermissionLauncher Launcher for single permission requests.
 * @param multiplePermissionsLauncher Launcher for multiple permission requests.
 */
class PermissionController(
    private val activity: Activity,
    private val preferences: SharedPreferences,
    private val singlePermissionLauncher: ActivityResultLauncher<String>,
    private val multiplePermissionsLauncher: ActivityResultLauncher<Array<String>>
) : IPermissionController {

    private val requestedThisSession = mutableSetOf<Permission>()

    private var pendingSingleRequest: SinglePermissionRequest? = null
    private var pendingMultipleRequest: MultiplePermissionsRequest? = null
    
    override fun getState(permission: Permission): PermissionState {
        val granted = ActivityCompat.checkSelfPermission(activity, permission.key) == PackageManager.PERMISSION_GRANTED
        val rationale = shouldShowRationale(permission)
        val firstTimeEver = isFirstTimeEver(permission)
        val firstTimeSession = isFirstTimeThisSession(permission)

        val status = when {
            granted -> PermissionStatus.Granted
            // If rationale is false and it's not first time, user selected "Don't ask again"
            !rationale && !firstTimeSession -> PermissionStatus.PermanentlyDenied
            else -> PermissionStatus.Denied
        }

        return PermissionState(
            status = status,
            requiresRationale = rationale,
            isFirstTimeEver = firstTimeEver,
            isFirstTimeThisSession = firstTimeSession
        )
    }

    override fun requestPermission(permission: Permission, onResult: (PermissionResult) -> Unit) {
        val state = getState(permission)

        // If already granted, return immediately
        if (state.status == PermissionStatus.Granted) {
            onResult(PermissionResult.Granted)
            return
        }

        val rationaleBefore = shouldShowRationale(permission)
        pendingSingleRequest = SinglePermissionRequest(permission, rationaleBefore, onResult)
        singlePermissionLauncher.launch(permission.key)
    }

    override fun requestPermissions(
        permissions: List<Permission>,
        onResult: (Map<Permission, PermissionResult>) -> Unit
    ) {
        val states = permissions.associateWith { getState(it) }

        // Check if all permissions are either granted or permanently denied
        val allResolved = states.all {
            it.value.status == PermissionStatus.Granted
        }

        if (allResolved) {
            // Return results immediately without showing OS dialog
            val results = permissions.associateWith { permission ->
                when (states[permission]?.status) {
                    PermissionStatus.Granted -> PermissionResult.Granted
                    else -> PermissionResult.AutoDenied
                }
            }
            onResult(results)
            return
        }

        val rationalesBefore = permissions.associateWith { shouldShowRationale(it) }
        pendingMultipleRequest = MultiplePermissionsRequest(permissions, rationalesBefore, onResult)
        multiplePermissionsLauncher.launch(permissions.map { it.key }.toTypedArray())
    }

    /**
     * Called when the single permission launcher returns a result.
     * This should be invoked from the launcher callback in the Compose layer.
     */
    fun onSinglePermissionResult(granted: Boolean) {
        val request = pendingSingleRequest ?: return
        pendingSingleRequest = null

        markAsRequested(request.permission)
        val result = evaluateResult(request.permission, granted, request.rationaleBefore)
        request.callback(result)
    }

    /**
     * Called when the multiple permissions launcher returns a result.
     * This should be invoked from the launcher callback in the Compose layer.
     */
    fun onMultiplePermissionsResult(grantedMap: Map<String, Boolean>) {
        val request = pendingMultipleRequest ?: return
        pendingMultipleRequest = null

        val results = request.permissions.associateWith { permission ->
            val granted = grantedMap[permission.key] ?: false
            val rationaleBefore = request.rationalesBefore[permission] ?: false
            markAsRequested(permission)
            evaluateResult(permission, granted, rationaleBefore)
        }
        request.callback(results)
    }

    private fun markAsRequested(permission: Permission) {
        requestedThisSession.add(permission)
        preferences.edit {
            putBoolean(prefKey(permission), true)
        }
    }

    private fun evaluateResult(
        permission: Permission,
        granted: Boolean,
        rationaleBefore: Boolean
    ): PermissionResult {
        val rationaleAfter = shouldShowRationale(permission)
        return when {
            granted -> PermissionResult.Granted
            // If rationale was false before AND after the request, the OS auto-denied without showing dialog
            !rationaleBefore && !rationaleAfter -> PermissionResult.AutoDenied
            else -> PermissionResult.Denied
        }
    }

    private fun shouldShowRationale(permission: Permission): Boolean {
        return ActivityCompat.shouldShowRequestPermissionRationale(activity, permission.key)
    }

    private fun isFirstTimeEver(permission: Permission): Boolean {
        return !preferences.getBoolean(prefKey(permission), false)
    }

    private fun isFirstTimeThisSession(permission: Permission): Boolean {
        return permission !in requestedThisSession
    }

    private fun prefKey(permission: Permission): String {
        return "$PREF_KEY_PREFIX${permission.key}"
    }

    companion object {
        private const val PREF_KEY_PREFIX = "permission_requested_"
    }

}
