package com.dexkot.mobile.core.permission

/**
 * Represents the result of a permission request.
 */
sealed interface PermissionResult {
    /**
     * Permission was granted by the user.
     */
    data object Granted : PermissionResult

    /**
     * Permission was denied by the user, but can be requested again.
     */
    data object Denied : PermissionResult

    /**
     * Permission was not requested because it was already permanently denied.
     * The app should direct the user to Settings to grant this permission.
     */
    data object AutoDenied : PermissionResult
}
