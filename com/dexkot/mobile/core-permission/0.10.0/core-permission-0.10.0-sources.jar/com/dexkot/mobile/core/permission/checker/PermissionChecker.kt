package com.dexkot.mobile.core.permission.checker

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.dexkot.mobile.core.permission.Permission

/**
 * Simple implementation of [IPermissionChecker] that only requires Context.
 * Safe for use in ViewModels.
 *
 * @param context Application context for checking permission status.
 */
class PermissionChecker(
    private val context: Context
) : IPermissionChecker {

    override fun isGranted(permission: Permission): Boolean {
        return ContextCompat.checkSelfPermission(context, permission.key) ==
            PackageManager.PERMISSION_GRANTED
    }
}
