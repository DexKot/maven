package com.dexkot.mobile.core.sqldelight

import com.dexkot.mobile.core.foundation.result.ResultOf

internal class RollbackException(
    val failure: ResultOf.Failure<*>
): Exception()
