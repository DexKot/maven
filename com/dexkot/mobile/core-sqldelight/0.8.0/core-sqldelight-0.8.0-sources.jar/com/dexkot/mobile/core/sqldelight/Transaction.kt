package com.dexkot.mobile.core.sqldelight

import app.cash.sqldelight.SuspendingTransactionWithReturn
import app.cash.sqldelight.db.SqlDriver
import com.dexkot.mobile.core.foundation.result.ResultOf
import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.result.map
import com.dexkot.mobile.core.foundation.data.transaction.ITransaction
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

internal class Transaction<Output>(
    private val dispatcher: CoroutineDispatcher,
    private val sqlDriver: SqlDriver,
    private val sqlTransaction: SuspendingTransactionWithReturn<ResultOf<Output>>
): ITransaction<Output> {

    override suspend fun rollback(failure: ResultOf.Failure<*>): Nothing {
        try {
            sqlTransaction.rollback(failure.map())
        } catch (ignored: Throwable) {
            throw RollbackException(failure = failure)
        }
    }

    override suspend fun <Out> execute(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out> {
        return withContext(asCoroutineContext()) {
            try {
                block()
            } catch (exception: RollbackException) {
                throw exception
            } catch (exception: Throwable) {
                rollback(
                    failure = ResultOf.Failure<Out>(
                        error = ErrorEntity.UnexpectedError(
                            exception = exception
                        )
                    )
                )
            }
        }
    }

    override suspend fun <Out> innerTransaction(
        block: suspend ITransaction<*>.() -> ResultOf<Out>
    ): ResultOf<Out> {
        return withContext(asCoroutineContext()) {
            val savepoint = Savepoint(sqlDriver = sqlDriver)
            try {
                savepoint.start()
                execute(block)
            } catch (exception: Throwable) {
                savepoint.rollback()
                throw exception
            } finally {
                savepoint.release()
            }
        }
    }

    private fun asCoroutineContext(): CoroutineContext {
        return dispatcher + TransactionContextElement(transaction = this)
    }

}
