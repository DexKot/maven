package com.dexkot.mobile.core.work.domain.config.model.network

import androidx.work.NetworkType

/**
 * Converts framework-agnostic NetworkRequirement to WorkManager NetworkType.
 */
internal fun NetworkRequirement.toNetworkType(): NetworkType {
    return when (this) {
        NetworkRequirement.NONE -> NetworkType.NOT_REQUIRED
        NetworkRequirement.CONNECTED -> NetworkType.CONNECTED
        NetworkRequirement.UNMETERED -> NetworkType.UNMETERED
    }
}