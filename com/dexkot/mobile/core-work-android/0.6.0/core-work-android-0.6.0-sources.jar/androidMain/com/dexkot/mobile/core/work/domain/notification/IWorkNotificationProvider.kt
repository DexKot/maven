package com.dexkot.mobile.core.work.domain.notification

import com.dexkot.mobile.core.work.domain.executor.model.WorkProgressData

/**
 * Provider for creating work notifications for a specific work type.
 *
 * App module or feature modules can implement this interface to provide
 * notification content for their specific work types. This interface provides
 * two methods for creating notification content:
 * - [getNotification] for in-progress notifications
 * - [getCompletedNotification] for completion notifications
 *
 * Example implementation:
 * ```
 * class ScanWorkNotificationProvider(
 *     private val context: Context
 * ) : IWorkNotificationProvider {
 *
 *     override val workType: String = "scan_pdf"
 *
 *     override fun getChannelId(): String {
 *         return ScanWorkInProgressChannel.id
 *     }
 *
 *     override fun getCompletionChannelId(): String {
 *         return ScanWorkCompletionChannel.id
 *     }
 *
 *     override fun getNotification(
 *         progress: WorkProgressData
 *     ): NotificationContent {
 *         return NotificationContent(
 *             title = "Scanning PDF",
 *             text = "Page ${progress.current} of ${progress.total}",
 *             contentIntent = createPendingIntent()
 *         )
 *     }
 *
 *     override fun getCompletedNotification(
 *         progress: WorkProgressData,
 *         status: WorkCompletionStatus
 *     ): NotificationContent {
 *         return when (status) {
 *             WorkCompletionStatus.Success -> NotificationContent(
 *                 title = "Scan Complete",
 *                 text = "Successfully scanned ${progress.total} pages"
 *             )
 *             WorkCompletionStatus.Failed -> NotificationContent(
 *                 title = "Scan Failed",
 *                 text = "Failed to scan PDF"
 *             )
 *             WorkCompletionStatus.Retrying -> NotificationContent(
 *                 title = "Scan Interrupted",
 *                 text = "Retrying automatically..."
 *             )
 *         }
 *     }
 * }
 * ```
 */
interface IWorkNotificationProvider {

    /**
     * The type identifier for the work this provider handles.
     * This should match the work type used when scheduling work.
     *
     * Example: "scan_pdf", "export_pdf", etc.
     */
    val workType: String

    /**
     * Returns the notification channel ID for in-progress notifications.
     *
     * This should reference a notification channel that has been created
     * at app startup (e.g., via NotificationChannelInitializer).
     *
     * Return null if this work type should not show notifications during execution.
     *
     * @return Notification channel ID for in-progress notifications, or null to disable
     */
    fun getChannelId(): String?

    /**
     * Returns the notification channel ID for completion notifications.
     *
     * This should reference a notification channel that has been created
     * at app startup (e.g., via NotificationChannelInitializer).
     *
     * If null is returned, the completion notification will use the same
     * channel as in-progress notifications (from [getChannelId]).
     *
     * Override this method to use a separate channel with different importance
     * (e.g., IMPORTANCE_DEFAULT for alerts vs IMPORTANCE_LOW for silent progress).
     *
     * @return Notification channel ID for completion notifications, or null to use [getChannelId]
     */
    fun getCompletionChannelId(): String? = null

    /**
     * Creates notification content based on current work progress.
     *
     * Called whenever work progress is updated during execution.
     *
     * Use progress.metadata to access work-specific data like URIs,
     * script IDs, or other contextual information.
     *
     * @param progress Current work progress with metadata
     * @return Notification content to display
     */
    fun getNotification(
        progress: WorkProgressData
    ): NotificationContent

    /**
     * Creates notification content for work completion.
     *
     * Called when work finishes successfully, fails permanently, or is being retried.
     *
     * @param progress Final work progress with metadata
     * @param status The completion status indicating success, failure, or retry
     * @return Notification content to display
     */
    fun getCompletedNotification(
        progress: WorkProgressData,
        status: WorkCompletionStatus
    ): NotificationContent

}
