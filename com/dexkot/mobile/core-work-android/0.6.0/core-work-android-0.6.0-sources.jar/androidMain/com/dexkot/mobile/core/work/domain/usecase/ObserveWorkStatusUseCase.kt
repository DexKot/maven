package com.dexkot.mobile.core.work.domain.usecase

import androidx.work.WorkManager
import com.dexkot.mobile.core.work.domain.config.IWorkTypeConfigFactory
import com.dexkot.mobile.core.work.domain.constraint.ConstraintChangeListener
import com.dexkot.mobile.core.work.domain.constraint.ConstraintChecker
import com.dexkot.mobile.core.work.domain.executor.model.WorkStatus
import com.dexkot.mobile.core.work.domain.executor.model.toWorkStatus
import com.dexkot.mobile.core.work.domain.work.workTag
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlin.uuid.Uuid

/**
 * Implementation of [IObserveWorkStatusUseCase].
 *
 * This use case observes WorkManager's WorkInfo for a specific work instance
 * and maps it to [WorkStatus] domain model, automatically updating when
 * system constraints change.
 *
 * The use case:
 * 1. Constructs the work instance tag from workType and workId
 * 2. Observes WorkInfo updates from WorkManager using the tag
 * 3. Listens to system broadcasts for constraint changes (network, battery, storage, etc.)
 * 4. Combines both flows to re-evaluate status when either WorkInfo or constraints change
 * 5. Maps WorkInfo.State to WorkStatus (distinguishing between Queued and Blocked)
 *
 * @property workManager Android WorkManager instance
 * @property configFactory Factory for retrieving work type configurations
 * @property constraintChecker Checker for determining if constraints are met
 * @property constraintChangeListener Listener for system constraint changes
 */
internal class ObserveWorkStatusUseCase(
    private val workManager: WorkManager,
    private val configFactory: IWorkTypeConfigFactory,
    private val constraintChecker: ConstraintChecker,
    private val constraintChangeListener: ConstraintChangeListener
) : IObserveWorkStatusUseCase {

    /**
     * Observes the WorkManager status of a specific work instance.
     *
     * This flow emits whenever:
     * - WorkManager's WorkInfo changes (state transitions, progress updates)
     * - System constraints change (network, battery, storage, device idle)
     *
     * This ensures the UI accurately reflects whether work is blocked by constraints
     * or simply queued, even when constraints change while work is enqueued.
     *
     * @param workType The type of work (e.g., "scan_pdf")
     * @param workId The unique identifier for the work instance
     * @return Flow emitting WorkManager status updates (null if not scheduled)
     */
    override operator fun invoke(
        workType: String,
        workId: Uuid
    ): Flow<WorkStatus?> {
        // Construct the work instance tag (must match the format in ScheduleWorkUseCase)
        val workInstanceTag = workTag(workType, workId)

        // Observe WorkInfo by tag
        val workInfoFlow = workManager.getWorkInfosByTagFlow(workInstanceTag)

        // Observe constraint changes
        val constraintChangesFlow = constraintChangeListener.observeConstraintChanges()

        // Combine both flows - emit when either WorkInfo or constraints change
        return workInfoFlow.combine(constraintChangesFlow) { workInfoList, _ ->
            // Get the first work (should only be one per workId)
            val workInfo = workInfoList.firstOrNull()

            // Get work configuration to check constraints
            val workConfig = configFactory.getConfig(workType)

            // Check if all constraints are currently met
            // If config is not found, assume constraints are met (fallback behavior)
            val constraintsMet = workConfig?.let { constraintChecker.areConstraintsMet(it) } ?: true

            // Map WorkInfo.State to WorkStatus
            workInfo?.state?.toWorkStatus(constraintsMet = constraintsMet)
        }
    }

}
