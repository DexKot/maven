package com.dexkot.mobile.core.work.data.config

import com.dexkot.mobile.core.work.domain.config.IWorkTypeConfigProvider
import com.dexkot.mobile.core.work.domain.config.IWorkTypeConfigFactory
import com.dexkot.mobile.core.work.domain.config.model.WorkTypeConfig

/**
 * Provider that creates work type configurations by delegating to registered delegates.
 *
 * This provider maintains a map of work type identifiers to their corresponding
 * delegates. Each feature module registers an [com.dexkot.mobile.core.work.domain.config.IWorkTypeConfigProvider] that
 * provides configuration for a specific work type.
 *
 * This design avoids circular dependency issues that would occur if the provider
 * itself was collected via getAll().
 *
 * Example usage with Koin:
 * ```
 * // In feature modules (e.g., recognition, publisher):
 * val recognitionModule = module {
 *     factory<IWorkTypeConfigDelegate> {
 *         ScanWorkConfigDelegate()
 *     }
 * }
 *
 * val publisherModule = module {
 *     factory<IWorkTypeConfigDelegate> {
 *         PdfExportWorkConfigDelegate()
 *     }
 * }
 *
 * // In core:work module:
 * val workModule = module {
 *     // Provider automatically collects all registered delegates
 *     single<IWorkTypeConfigProvider> {
 *         WorkTypeConfigProvider(
 *             delegates = getAll<IWorkTypeConfigDelegate>()
 *         )
 *     }
 * }
 * ```
 *
 * @property delegates List of work type config delegates from feature modules
 */
internal class WorkTypeConfigFactory(
    delegates: List<IWorkTypeConfigProvider>
) : IWorkTypeConfigFactory {

    /**
     * Map of work type to delegate for efficient lookup.
     */
    private val delegateMap: Map<String, IWorkTypeConfigProvider> = delegates.associateBy { it.workType }

    /**
     * Returns configuration for the specified work type.
     *
     * Looks up the delegate for the given work type and retrieves its configuration.
     * If no delegate is registered for the work type, returns null.
     *
     * @param workType The work type identifier (e.g., "scan_pdf", "export_pdf")
     * @return Configuration for the work type, or null if workType is not supported
     */
    override fun getConfig(workType: String): WorkTypeConfig? {
        return delegateMap[workType]?.getConfig()
    }

}