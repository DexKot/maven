package com.dexkot.mobile.core.work.domain.notification

import android.app.PendingIntent
import androidx.annotation.DrawableRes

/**
 * Content for work notifications.
 *
 * Defines the text, icon, and interaction for a notification at a specific point in work execution.
 *
 * @property title Notification title
 * @property text Notification body text
 * @property iconResId Drawable resource ID for the notification icon
 * @property contentIntent Optional PendingIntent to launch when user taps the notification
 * @property progress Optional progress information for progress bar display
 */
data class NotificationContent(
    val title: String,
    val text: String,
    @param:DrawableRes val iconResId: Int,
    val contentIntent: PendingIntent? = null,
    val progress: Progress? = null
) {
    /**
     * Progress information for notification progress bar.
     *
     * @property current Current progress value
     * @property total Total/maximum progress value
     * @property indeterminate If true, shows an indeterminate progress bar
     */
    data class Progress(
        val current: Int,
        val total: Int,
        val indeterminate: Boolean = false
    )
}