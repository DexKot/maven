package com.dexkot.mobile.core.work.domain.constraint

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.PowerManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate

/**
 * Listens to system broadcasts for constraint changes.
 *
 * This class monitors system events that affect WorkManager constraints:
 * - Network connectivity changes
 * - Battery level and charging state changes
 * - Storage state changes
 * - Device idle mode changes (API 23+)
 *
 * When any of these constraints change, it emits a signal through a Flow
 * that can be used to re-evaluate constraint status.
 *
 * @param context Application context for registering broadcast receivers
 */
internal class ConstraintChangeListener(
    private val context: Context
) {

    /**
     * Creates a Flow that emits Unit whenever any constraint changes.
     *
     * This Flow will emit:
     * - Immediately upon collection (initial value)
     * - Whenever network connectivity changes
     * - Whenever battery state changes (charging, low battery)
     * - Whenever storage state changes
     * - Whenever device enters/exits idle mode (API 23+)
     *
     * The Flow uses conflate() to drop intermediate values if the collector
     * can't keep up, since we only care about triggering a re-check.
     *
     * @return Flow that emits Unit on constraint changes
     */
    @Suppress("DEPRECATION")
    fun observeConstraintChanges(): Flow<Unit> = callbackFlow {
        // Create a receiver that emits on any constraint change
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                // Emit signal that constraints may have changed
                trySend(Unit)
            }
        }

        // Build intent filter for all constraint-related broadcasts
        val intentFilter = IntentFilter().apply {
            // Network connectivity changes
            addAction(ConnectivityManager.CONNECTIVITY_ACTION)

            // Battery state changes
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_BATTERY_OKAY)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)

            // Storage state changes
            addAction(Intent.ACTION_DEVICE_STORAGE_LOW)
            addAction(Intent.ACTION_DEVICE_STORAGE_OK)

            // Device idle mode changes (API 23+)
            addAction(PowerManager.ACTION_DEVICE_IDLE_MODE_CHANGED)
        }

        // Register the receiver
        context.registerReceiver(receiver, intentFilter)

        // Emit initial value to trigger first check
        trySend(Unit)

        // Unregister when flow is cancelled
        awaitClose {
            context.unregisterReceiver(receiver)
        }
    }.conflate() // Drop intermediate values if collector is slow

}
