package com.dexkot.mobile.core.work.domain.notification

import kotlin.uuid.Uuid

/**
 * Utility for generating consistent notification IDs for work instances.
 *
 * This ensures that both the worker (when showing notifications) and the cancel use case
 * (when dismissing notifications) use the same notification ID generation logic.
 *
 * Each work instance has two types of notifications:
 * - In-progress notification: Shown while work is executing (foreground service)
 * - Completion notification: Shown after work completes (success or failure)
 *
 * The notification IDs are derived from the work ID to ensure uniqueness across
 * different work instances.
 */
internal object WorkNotificationId {

    /**
     * Generates the notification ID for in-progress work notifications.
     *
     * This ID is used for the foreground service notification that shows
     * work progress while the work is executing.
     *
     * @param workId The unique identifier for the work instance
     * @return A unique notification ID for the in-progress notification
     */
    fun inProgress(workId: Uuid): Int {
        return "$workId-in-progress".hashCode()
    }

    /**
     * Generates the notification ID for completion notifications.
     *
     * This ID is used for the notification that appears after work completes,
     * whether it succeeded or failed.
     *
     * @param workId The unique identifier for the work instance
     * @return A unique notification ID for the completion notification
     */
    fun completed(workId: Uuid): Int {
        return "$workId-completed".hashCode()
    }
}
