package com.dexkot.mobile.core.work.data.executor

import com.dexkot.mobile.core.work.domain.executor.IWorkExecutor
import com.dexkot.mobile.core.work.domain.executor.IWorkExecutorFactory
import com.dexkot.mobile.core.work.domain.executor.IWorkExecutorProvider
import kotlin.uuid.Uuid

/**
 * Factory that creates work executors by delegating to registered providers.
 *
 * This factory maintains a map of work type identifiers to their corresponding
 * providers. Each feature module registers an [IWorkExecutorProvider] that
 * handles creation of executors for a specific work type.
 *
 * This design avoids circular dependency issues that would occur if the factory
 * itself was collected via getAll().
 *
 * Example usage with Koin:
 * ```
 * // In feature modules (e.g., recognition, publisher):
 * val recognitionModule = module {
 *     factory<IWorkExecutorProvider> {
 *         ScanWorkExecutorProvider(
 *             context = androidContext(),
 *             // ... other dependencies
 *         )
 *     }
 * }
 *
 * val publisherModule = module {
 *     factory<IWorkExecutorProvider> {
 *         PdfExportWorkExecutorProvider(
 *             // ... dependencies
 *         )
 *     }
 * }
 *
 * // In core:work module:
 * val workModule = module {
 *     // Factory automatically collects all registered providers
 *     single<IWorkExecutorFactory> {
 *         WorkExecutorFactory(
 *             providers = getAll<IWorkExecutorProvider>()
 *         )
 *     }
 * }
 * ```
 *
 * @property providers List of work executor providers from feature modules
 */
internal class WorkExecutorFactory(
    providers: List<IWorkExecutorProvider>
) : IWorkExecutorFactory {

    /**
     * Map of work type to provider for efficient lookup.
     */
    private val providerMap: Map<String, IWorkExecutorProvider> = providers.associateBy { it.workType }

    /**
     * Creates an executor for the specified work type and ID.
     *
     * Looks up the provider for the given work type and delegates creation to it.
     * If no provider is registered for the work type, returns null.
     *
     * @param workType The type identifier (e.g., "scan_work", "pdf_export")
     * @param workId The unique work instance ID
     * @return Executor instance, or null if workType is not supported
     */
    override fun create(workType: String, workId: Uuid): IWorkExecutor? {
        return providerMap[workType]?.create(workId)
    }

}