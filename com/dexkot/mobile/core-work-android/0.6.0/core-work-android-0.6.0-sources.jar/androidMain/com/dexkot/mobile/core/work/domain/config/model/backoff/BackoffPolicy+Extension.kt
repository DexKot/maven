package com.dexkot.mobile.core.work.domain.config.model.backoff

/**
 * Converts framework-agnostic BackoffPolicy to WorkManager BackoffPolicy.
 */
internal fun BackoffPolicy.toWorkManagerBackoffPolicy(): androidx.work.BackoffPolicy {
    return when (this) {
        BackoffPolicy.EXPONENTIAL -> androidx.work.BackoffPolicy.EXPONENTIAL
        BackoffPolicy.LINEAR -> androidx.work.BackoffPolicy.LINEAR
    }
}