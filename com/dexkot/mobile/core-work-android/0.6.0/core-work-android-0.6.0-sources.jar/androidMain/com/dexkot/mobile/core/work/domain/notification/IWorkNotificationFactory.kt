package com.dexkot.mobile.core.work.domain.notification

/**
 * Factory for retrieving work notification providers.
 *
 * This is the main interface for accessing work notification providers. The implementation
 * ([com.dexkot.mobile.core.work.data.notification.WorkNotificationFactory]) aggregates multiple [IWorkNotificationProvider] instances
 * from the app module or feature modules and provides lookup by work type.
 *
 * App/feature modules should implement [IWorkNotificationProvider] instead of this interface
 * to avoid circular dependency issues during dependency injection.
 *
 * Example implementation (internal to core:work):
 * ```
 * class WorkNotificationFactory(
 *     providers: List<IWorkNotificationProvider>
 * ) : IWorkNotificationFactory {
 *     private val providerMap = providers.associateBy { it.workType }
 *
 *     override fun create(workType: String): IWorkNotificationProvider? {
 *         return providerMap[workType]
 *     }
 * }
 * ```
 *
 * @see IWorkNotificationProvider for app/feature module implementations
 */
interface IWorkNotificationFactory {

    /**
     * Retrieves the notification provider for the specified work type.
     *
     * @param workType The work type identifier (e.g., "scan_pdf", "export_pdf")
     * @return Notification provider, or null if workType is not supported
     */
    fun create(
        workType: String
    ): IWorkNotificationProvider?

}
