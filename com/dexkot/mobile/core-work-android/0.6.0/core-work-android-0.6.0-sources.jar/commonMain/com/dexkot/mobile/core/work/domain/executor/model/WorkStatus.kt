package com.dexkot.mobile.core.work.domain.executor.model

import com.dexkot.mobile.core.foundation.CommonParcelable
import com.dexkot.mobile.core.foundation.CommonParcelize

/**
 * Lifecycle states for background work.
 */
@CommonParcelize
sealed class WorkStatus : CommonParcelable {

    /**
     * Work is queued but not started.
     */
    @CommonParcelize
    data object Queued : WorkStatus()

    /**
     * Work is blocked waiting for constraints to be met.
     * For example, waiting for network connectivity or charging.
     */
    @CommonParcelize
    data object Blocked : WorkStatus()

    /**
     * Work is actively executing.
     */
    @CommonParcelize
    data object Running : WorkStatus()

    /**
     * Work finished successfully.
     */
    @CommonParcelize
    data object Completed : WorkStatus()

    /**
     * Work failed permanently.
     */
    @CommonParcelize
    data object Failed : WorkStatus()

    /**
     * Work was cancelled by user.
     */
    @CommonParcelize
    data object Cancelled : WorkStatus()

}
