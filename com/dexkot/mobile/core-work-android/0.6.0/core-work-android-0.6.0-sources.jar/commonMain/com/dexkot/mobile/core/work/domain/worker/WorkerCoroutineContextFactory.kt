package com.dexkot.mobile.core.work.domain.worker

import kotlin.coroutines.CoroutineContext

fun interface WorkerCoroutineContextFactory {
    fun create(workType: String): CoroutineContext
}
