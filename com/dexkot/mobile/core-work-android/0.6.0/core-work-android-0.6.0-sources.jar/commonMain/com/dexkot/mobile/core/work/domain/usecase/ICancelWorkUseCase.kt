package com.dexkot.mobile.core.work.domain.usecase

import com.dexkot.mobile.core.foundation.result.ResultOf
import kotlin.uuid.Uuid

/**
 * Use case for canceling scheduled background work.
 *
 * This use case handles the cancellation of work instances that are queued,
 * blocked, or running in WorkManager.
 *
 * Example usage:
 * ```
 * class ScanViewModel(
 *     private val cancelWork: ICancelWorkUseCase
 * ) : ViewModel() {
 *
 *     fun cancelScan(workId: Uuid) {
 *         viewModelScope.launch {
 *             when (val result = cancelWork(
 *                 workType = "scan_pdf",
 *                 workId = workId
 *             )) {
 *                 is ResultOf.Success -> {
 *                     // Work cancelled successfully
 *                 }
 *                 is ResultOf.Failure -> {
 *                     // Handle error
 *                 }
 *             }
 *         }
 *     }
 * }
 * ```
 */
interface ICancelWorkUseCase {

    /**
     * Cancels scheduled or running work.
     *
     * This will cancel work that is:
     * - Queued (waiting to run)
     * - Blocked (waiting for constraints to be met)
     * - Running (currently executing)
     *
     * If the work has already completed, failed, or been cancelled, this is a no-op.
     *
     * @param workType The type of work to cancel (e.g., "scan_pdf", "pdf_export")
     * @param workId The unique identifier for this work instance
     * @return Success if cancelled, or Failure on error
     */
    operator fun invoke(
        workType: String,
        workId: Uuid
    ): ResultOf<Unit>

}
