package com.dexkot.mobile.core.work.domain.error

import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.errors.ErrorSeverity
import com.dexkot.mobile.core.foundation.CommonParcelize
import kotlin.uuid.Uuid

/**
 * Error indicating that a work instance was not found in the repository.
 *
 * This typically occurs when:
 * - Work was cancelled/deleted before executor started
 * - Work ID is invalid or doesn't exist
 * - Database was cleared/reset
 *
 * @property workId The Uuid of the work that was not found
 */
@CommonParcelize
class WorkNotFound(
    val workId: Uuid
) : ErrorEntity.BusinessError(
    severity = ErrorSeverity.WARN,
    exception = null
)