package com.dexkot.mobile.core.work.domain.config

import com.dexkot.mobile.core.work.domain.config.model.WorkTypeConfig

/**
 * Delegate for providing configuration for a specific work type.
 *
 * Each feature module should implement this interface to define execution
 * constraints and retry policies for their specific work type. This interface
 * differs from [IWorkTypeConfigFactory] in that it only handles a single work
 * type and doesn't need to check the type parameter.
 *
 * Example implementation:
 * ```
 * class ScanWorkConfigDelegate : IWorkTypeConfigDelegate {
 *
 *     override val workType: String = "scan_pdf"
 *
 *     override fun getConfig(): WorkTypeConfig {
 *         return WorkTypeConfig(
 *             workType = workType,
 *             networkRequirement = NetworkRequirement.CONNECTED,
 *             requiresBatteryNotLow = true,
 *             maxRetries = 5
 *         )
 *     }
 * }
 * ```
 */
interface IWorkTypeConfigProvider {

    /**
     * The type identifier for the work this delegate handles.
     * This should match the work type used when scheduling work.
     *
     * Example: "scan_pdf", "export_pdf", etc.
     */
    val workType: String

    /**
     * Returns configuration for this work type.
     *
     * @return Configuration for this work type
     */
    fun getConfig(): WorkTypeConfig

}
