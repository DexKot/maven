package com.dexkot.mobile.core.work.domain.error

import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.errors.ErrorSeverity
import com.dexkot.mobile.core.foundation.CommonParcelize

/**
 * Error indicating that work could not be enqueued in WorkManager.
 *
 * This occurs when WorkManager fails to enqueue the work request,
 * which could happen due to database issues, resource constraints,
 * or other system-level problems.
 *
 * @property workType The type of work that failed to enqueue
 * @property cause The underlying exception that caused the failure
 */
@CommonParcelize
class WorkEnqueueFailed(
    val workType: String,
    val cause: Throwable
) : ErrorEntity.BusinessError(
    exception = cause,
    severity = ErrorSeverity.ERROR
)
