package com.dexkot.mobile.core.work.domain.config.model.backoff

/**
 * Retry backoff policy for failed work.
 *
 * Determines how the delay between retries increases after each failure.
 */
enum class BackoffPolicy {

    /**
     * Exponential backoff - delay doubles with each retry.
     * Example: 10s, 20s, 40s, 80s...
     */
    EXPONENTIAL,

    /**
     * Linear backoff - delay increases by a fixed amount each retry.
     * Example: 10s, 20s, 30s, 40s...
     */
    LINEAR

}
