package com.dexkot.mobile.core.work.domain.config.model

import com.dexkot.mobile.core.work.domain.config.model.backoff.BackoffPolicy
import com.dexkot.mobile.core.work.domain.config.model.network.NetworkRequirement

/**
 * Configuration for a specific type of background work.
 *
 * Defines execution constraints and retry policies without exposing
 * WorkManager implementation details.
 *
 * Example:
 * ```
 * WorkTypeConfig(
 *     workType = "scan_work",
 *     networkRequirement = NetworkRequirement.CONNECTED,
 *     requiresBatteryNotLow = true,
 *     maxRetries = 5
 * )
 * ```
 *
 * @property networkRequirement Network connectivity requirement
 * @property requiresBatteryNotLow Whether work requires battery not to be low
 * @property requiresCharging Whether work requires device to be charging
 * @property requiresStorageNotLow Whether work requires storage not to be low
 * @property requiresDeviceIdle Whether work requires device to be idle
 * @property backoffPolicy Retry backoff strategy
 */
data class WorkTypeConfig(
    val networkRequirement: NetworkRequirement = NetworkRequirement.NONE,
    val requiresBatteryNotLow: Boolean = false,
    val requiresCharging: Boolean = false,
    val requiresStorageNotLow: Boolean = false,
    val requiresDeviceIdle: Boolean = false,
    val backoffPolicy: BackoffPolicy = BackoffPolicy.EXPONENTIAL,
)