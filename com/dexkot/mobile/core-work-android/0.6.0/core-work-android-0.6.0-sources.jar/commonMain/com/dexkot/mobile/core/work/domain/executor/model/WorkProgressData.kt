package com.dexkot.mobile.core.work.domain.executor.model

import kotlin.uuid.Uuid

/**
 * Represents work execution progress in a type-agnostic way.
 *
 * This data class allows executors to report progress without requiring
 * knowledge of the specific work type in the worker layer.
 *
 * Work-specific data can be passed through the metadata map.
 *
 * Example usage in executor:
 * ```
 * class ScanPdfWorkExecutor : IWorkExecutor {
 *     private val _progressFlow = MutableStateFlow(
 *         WorkProgressData(
 *             workType = ScanPdfWork.TYPE,
 *             workId = workId,
 *             current = 0,
 *             total = totalPages,
 *             metadata = mapOf(
 *                 "uri" to pdfUri.toString(),
 *                 "scriptId" to scriptId.toString()
 *             )
 *         )
 *     )
 *     override val progressFlow: Flow<WorkProgressData> = _progressFlow
 *
 *     override suspend fun doWork(): WorkResult {
 *         pages.forEachIndexed { index, page ->
 *             _progressFlow.value = _progressFlow.value.copy(
 *                 current = index + 1,
 *                 metadata = mapOf(
 *                     "uri" to pdfUri.toString(),
 *                     "scriptId" to scriptId.toString(),
 *                     "currentPageNumber" to page.number.toString()
 *                 )
 *             )
 *             // Process page...
 *         }
 *     }
 * }
 * ```
 *
 * @property workType The work type identifier (e.g., "scan_pdf", "export_pdf")
 * @property workId The unique work instance ID
 * @property current Current progress value (e.g., pages processed)
 * @property total Total progress value (e.g., total pages). Use -1 for indeterminate progress
 * @property metadata Optional work-specific data (e.g., file URI, script ID, page numbers)
 */
data class WorkProgressData(
    val workType: String,
    val workId: Uuid,
    val current: Int,
    val total: Int,
    val metadata: Map<String, String> = emptyMap()
)