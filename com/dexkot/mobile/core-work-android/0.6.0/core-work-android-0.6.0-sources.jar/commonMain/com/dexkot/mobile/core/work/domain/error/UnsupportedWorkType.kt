package com.dexkot.mobile.core.work.domain.error

import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.errors.ErrorSeverity
import com.dexkot.mobile.core.foundation.CommonParcelize

/**
 * Error indicating that a work type is not supported.
 *
 * This occurs when attempting to schedule work for a type that
 * has no registered config provider.
 *
 * @property workType The unsupported work type identifier
 */
@CommonParcelize
class UnsupportedWorkType(
    val workType: String
) : ErrorEntity.BusinessError(
    severity = ErrorSeverity.ERROR,
    exception = null
)