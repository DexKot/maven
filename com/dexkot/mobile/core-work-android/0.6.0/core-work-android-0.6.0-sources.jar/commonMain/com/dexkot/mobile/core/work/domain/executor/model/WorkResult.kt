package com.dexkot.mobile.core.work.domain.executor.model

import com.dexkot.mobile.core.foundation.CommonParcelable
import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.CommonParcelize

/**
 * Result of work execution.
 * Similar to Android WorkManager's Result but more detailed.
 */
@CommonParcelize
sealed class WorkResult : CommonParcelable {

    /**
     * Work completed successfully.
     */
    @CommonParcelize
    data object Success : WorkResult()

    /**
     * Work failed.
     *
     * @property error The error that caused failure
     * @property shouldRetry Whether work should be retried (default: true)
     */
    @CommonParcelize
    data class Failure(
        val error: ErrorEntity,
        val shouldRetry: Boolean = true
    ) : WorkResult()

    /**
     * Work was interrupted by user (paused or cancelled).
     * This is a successful termination - work state is saved.
     */
    @CommonParcelize
    data object Interrupted : WorkResult()

}
