package com.dexkot.mobile.core.work.domain.executor

import kotlin.uuid.Uuid

/**
 * Provider for creating work executors for a specific work type.
 *
 * Each feature module should implement this interface to provide executors
 * for their specific work types. This interface differs from [IWorkExecutorFactory]
 * in that it only handles a single work type and doesn't need to check the type
 * parameter.
 *
 * Example implementation:
 * ```
 * class ScanWorkExecutorProvider(
 *     private val repository: IScanPdfWorkRepository,
 *     private val recognizeText: IRecognizeTextUseCase
 * ) : IWorkExecutorProvider {
 *
 *     override val workType: String = "scan_work"
 *
 *     override fun create(workId: Uuid): IWorkExecutor {
 *         return ScanPdfWorkExecutor(
 *             workId = workId,
 *             repository = repository,
 *             recognizeText = recognizeText
 *         )
 *     }
 * }
 * ```
 */
interface IWorkExecutorProvider {

    /**
     * The type identifier for the work this provider handles.
     * This should match the work type used when scheduling work.
     *
     * Example: "scan_work", "pdf_export", etc.
     */
    val workType: String

    /**
     * Creates an executor for the specified work instance.
     *
     * @param workId The unique work instance ID
     * @return Executor instance for this work type
     */
    fun create(workId: Uuid): IWorkExecutor
}
