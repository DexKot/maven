package com.dexkot.mobile.core.work.domain.usecase

import com.dexkot.mobile.core.foundation.result.ResultOf
import kotlin.uuid.Uuid

/**
 * Use case for scheduling background work execution.
 *
 * This use case handles the scheduling of work instances based on their type,
 * applying the appropriate constraints and retry policies.
 *
 * Example usage:
 * ```
 * class ScanViewModel(
 *     private val scheduleWork: IScheduleWorkUseCase
 * ) : ViewModel() {
 *
 *     fun startScan(workId: Uuid) {
 *         viewModelScope.launch {
 *             when (val result = scheduleWork(
 *                 workType = "scan_work",
 *                 workId = workId
 *             )) {
 *                 is ResultOf.Success -> {
 *                     // Work scheduled successfully
 *                     val workRequestId = result.data
 *                 }
 *                 is ResultOf.Failure -> {
 *                     // Handle error (e.g., UnsupportedWorkType)
 *                 }
 *             }
 *         }
 *     }
 * }
 * ```
 */
interface IScheduleWorkUseCase {

    /**
     * Schedules work for execution.
     *
     * This is a suspend function that waits for the work to be successfully enqueued
     * in WorkManager before returning.
     *
     * @param workType The type of work to schedule (e.g., "scan_work", "pdf_export")
     * @param workId The unique identifier for this work instance
     * @return Success with WorkRequest Uuid if scheduled, or Failure with:
     *         - UnsupportedWorkType if work type not supported
     *         - WorkEnqueueFailed if WorkManager fails to enqueue the work
     */
    suspend operator fun invoke(
        workType: String,
        workId: Uuid
    ): ResultOf<Uuid>

}
