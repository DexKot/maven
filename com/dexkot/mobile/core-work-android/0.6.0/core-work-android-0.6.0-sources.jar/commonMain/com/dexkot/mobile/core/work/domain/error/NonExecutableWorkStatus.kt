package com.dexkot.mobile.core.work.domain.error

import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.errors.ErrorSeverity
import com.dexkot.mobile.core.foundation.CommonParcelize
import kotlin.uuid.Uuid

/**
 * Error indicating that a work instance cannot be executed.
 *
 * This error occurs when attempting to execute work that has already been completed.
 *
 * @property workId The Uuid of the work instance
 * @property currentStatus Description of the current status that prevents execution
 */
@CommonParcelize
class NonExecutableWorkStatus(
    val workId: Uuid,
    val currentStatus: String
) : ErrorEntity.BusinessError(
    severity = ErrorSeverity.WARN,
    exception = null
)