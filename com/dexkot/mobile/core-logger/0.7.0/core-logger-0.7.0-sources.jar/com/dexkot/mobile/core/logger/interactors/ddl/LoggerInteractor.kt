package com.dexkot.mobile.core.logger.interactors.ddl

import com.dexkot.mobile.core.logger.ILogger
import com.dexkot.mobile.core.logger.debug
import com.dexkot.mobile.core.logger.error
import com.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import com.dexkot.mobile.core.logger.events.ddl.operation.Status
import com.dexkot.mobile.core.logger.info
import com.dexkot.mobile.core.logger.verbose
import com.dexkot.mobile.core.logger.warning

class LoggerInteractor(
    private val logger: ILogger,
    private val sourceComponent: String
): ILoggerInteractor {

    override fun verbose(
        message: String,
        params: Map<String, Any>
    ) {
        logger.verbose(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun debug(
        message: String,
        params: Map<String, Any>
    ) {
        logger.debug(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun info(
        message: String,
        params: Map<String, Any>
    ) {
        logger.info(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun warning(
        message: String,
        params: Map<String, Any>
    ) {
        logger.warning(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun error(
        message: String,
        params: Map<String, Any>
    ) {
        logger.error(
            tag = getCallerTag(),
            message = message,
            params = params
        )
    }

    override fun error(
        throwable: Throwable,
        message: String?,
        params: Map<String, Any>
    ) {
        logger.log(
            throwable = throwable,
            message = message,
            params = params
        )
    }

    override fun operation(
        operationId: String,
        result: Status,
        params: Map<String, String>,
        isBusinessEvent: Boolean,
    ) {
        logger.log(
            event = OperationEvent(
                sourceComponent = sourceComponent,
                operationId = operationId,
                status = result,
                params = params,
                isBusinessEvent = isBusinessEvent
            )
        )
    }

    /**
     * Extracts the calling class name from the stack trace to use as a log tag.
     * Skips LoggerInteractor and logger utility functions to find the actual caller.
     */
    private fun getCallerTag(): String {
        val stackTrace = Thread.currentThread().stackTrace
        val callerElement = stackTrace.getOrNull(5)
        val caller = callerElement?.className?.substringAfterLast('.') ?: "Unknown"
        return "$sourceComponent/$caller"
    }

}
