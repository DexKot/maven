package com.dexkot.mobile.core.logger.events.ui.permission

enum class Status(
    val value: String,
) {

    Request("requested"),
    Granted("granted"),
    Denied("denied"),
    RequestIgnored("request_ignored");

}
