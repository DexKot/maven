package com.dexkot.mobile.core.logger.interactors.ui

import com.dexkot.mobile.core.logger.ILogger
import com.dexkot.mobile.core.logger.events.ui.interaction.Interaction
import com.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import com.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import com.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import com.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import com.dexkot.mobile.core.logger.events.ui.permission.Status
import com.dexkot.mobile.core.logger.events.ui.screen.Action
import com.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import com.dexkot.mobile.core.logger.events.ui.state.UiState
import com.dexkot.mobile.core.logger.events.ui.state.UiStateEvent

class LoggerInteractor(
    private val logger: ILogger,
    private val sourceComponent: String
): ILoggerInteractor {

    override fun enter() {
        logger.log(
            ScreenEvent(
                sourceComponent = sourceComponent,
                action = Action.Enter
            )
        )
    }

    override fun exit() {
        logger.log(
            ScreenEvent(
                sourceComponent = sourceComponent,
                action = Action.Exit
            )
        )
    }

    override fun navigate(
        navigationId: String,
        params: Map<String, String>
    ) {
        logger.log(
            NavigationEvent(
                navigationId = navigationId,
                sourceComponent = sourceComponent,
                params = params
            )
        )
    }

    override fun permission(permissions: List<String>) {
        val permissionsLog = permissions.associateBy(
            keySelector = { key -> key },
            valueTransform = { Status.Request }
        )

        logger.log(
            PermissionEvent(
                sourceComponent = sourceComponent,
                permissions = permissionsLog
            )
        )
    }

    override fun permission(permissions: Map<String, Status>) {
        val permissionsLog = permissions
            .mapKeys { (permission, _) -> permission }
            .mapValues { (_, result) -> result }

        logger.log(
            PermissionEvent(
                sourceComponent = sourceComponent,
                permissions = permissionsLog
            )
        )
    }

    override fun interaction(
        elementId: String,
        interaction: Interaction,
        extras: Map<String, String>
    ) {
        logger.log(
            InteractionEvent(
                elementId = elementId,
                interaction = interaction,
                sourceComponent = sourceComponent,
                extras = extras
            )
        )
    }

    override fun uiState(
        elementId: String,
        state: UiState,
        extras: Map<String, String>
    ) {
        logger.log(
            UiStateEvent(
                sourceComponent = sourceComponent,
                elementId = elementId,
                state = state,
                extras = extras
            )
        )
    }

    override fun intention(
        intentionId: String,
        params: Map<String, String>
    ) {
        logger.log(
            IntentionEvent(
                intentionId = intentionId,
                sourceComponent = sourceComponent,
                params = params
            )
        )
    }

}
