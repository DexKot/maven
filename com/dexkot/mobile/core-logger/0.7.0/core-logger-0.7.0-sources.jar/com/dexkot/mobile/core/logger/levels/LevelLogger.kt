package com.dexkot.mobile.core.logger.levels

import com.dexkot.mobile.core.logger.ILogger

internal class LevelLogger(
    private val level: Level,
    private val logger: ILogger
): ILogger by logger {

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        if (level.ordinal >= this.level.ordinal)
            logger.log(level, tag, message, params)
    }

}
