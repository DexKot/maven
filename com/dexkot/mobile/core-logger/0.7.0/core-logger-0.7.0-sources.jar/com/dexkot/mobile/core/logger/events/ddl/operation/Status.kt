package com.dexkot.mobile.core.logger.events.ddl.operation

enum class Status(
    val value: String
) {
    InProgress("in_progress"),
    Success("success"),
    Failure("failure")
}