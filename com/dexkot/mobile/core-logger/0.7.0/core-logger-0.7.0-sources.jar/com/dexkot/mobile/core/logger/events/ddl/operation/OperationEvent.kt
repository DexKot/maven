package com.dexkot.mobile.core.logger.events.ddl.operation

import com.dexkot.mobile.core.logger.events.LogEvent
import com.dexkot.mobile.core.logger.events.ui.Parameter

class OperationEvent(
    val sourceComponent: String,
    val operationId: String,
    val status: Status,
    val params: Map<String, String> = mapOf(),
    val isBusinessEvent: Boolean = false
): LogEvent {

    override val type: String = "operation"

    override val parameters: Map<String, Any> = buildMap {
        put(Parameter.SOURCE_COMPONENT, sourceComponent)
        put(Parameter.OPERATION_ID, operationId)
        put(Parameter.STATUS, status.value)
        params.forEach { (key, value) -> put("parameter_$key", value) }
    }

}