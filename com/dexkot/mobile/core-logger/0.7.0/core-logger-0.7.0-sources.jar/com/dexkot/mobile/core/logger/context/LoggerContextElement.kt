package com.dexkot.mobile.core.logger.context

import com.dexkot.mobile.core.logger.interactors.ddl.ILoggerInteractor
import kotlinx.coroutines.ThreadContextElement
import kotlin.coroutines.CoroutineContext

class LoggerContextElement(
    private val loggerInteractor: ILoggerInteractor,
) : ThreadContextElement<ILoggerInteractor?> {

    override val key: CoroutineContext.Key<LoggerContextElement> get() = Key

    override fun updateThreadContext(context: CoroutineContext): ILoggerInteractor? {
        val previous = threadLocal.get()
        threadLocal.set(loggerInteractor)
        return previous
    }

    override fun restoreThreadContext(context: CoroutineContext, oldState: ILoggerInteractor?) {
        threadLocal.set(oldState)
    }

    companion object Key : CoroutineContext.Key<LoggerContextElement> {
        private val threadLocal = ThreadLocal<ILoggerInteractor?>()
        private var defaultLogger: ILoggerInteractor? = null

        fun current(): ILoggerInteractor? = threadLocal.get() ?: defaultLogger

        fun setDefault(logger: ILoggerInteractor) {
            defaultLogger = logger
        }
    }
}
