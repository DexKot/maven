package com.dexkot.mobile.core.logger

import android.util.Log
import com.dexkot.mobile.core.logger.events.LogEvent
import com.dexkot.mobile.core.logger.events.ddl.operation.OperationEvent
import com.dexkot.mobile.core.logger.events.ui.interaction.InteractionEvent
import com.dexkot.mobile.core.logger.events.ui.intention.IntentionEvent
import com.dexkot.mobile.core.logger.events.ui.navigation.NavigationEvent
import com.dexkot.mobile.core.logger.events.ui.permission.PermissionEvent
import com.dexkot.mobile.core.logger.events.ui.screen.ScreenEvent
import com.dexkot.mobile.core.logger.events.ui.state.UiStateEvent
import com.dexkot.mobile.core.logger.levels.Level

internal class ConsoleLogger: ILogger {

    override fun setUserId(identifier: String) {
        Log.i(TAG, "User id: $identifier")
    }

    override fun setUserProperty(key: String, value: String?) {
        Log.i(TAG, "User property: $key = $value")
    }

    override fun removeUserId() {
        Log.i(TAG, "User id deleted")
    }

    override fun removeUserProperty(key: String) {
        Log.i(TAG, "User property $key deleted")
    }

    override fun log(event: LogEvent) {
        when (event) {
            is InteractionEvent -> Log.i(
                TAG,
                "[${event.sourceComponent}] ${event.interaction.value}: ${event.elementId}" +
                    event.extras.ifNotEmpty { " $it" },
            )
            is ScreenEvent -> Log.i(
                TAG,
                "[${event.sourceComponent}] screen: ${event.action.value}",
            )
            is NavigationEvent -> Log.i(
                TAG,
                "[${event.sourceComponent}] navigation: ${event.navigationId}" +
                    event.params.ifNotEmpty { " $it" },
            )
            is OperationEvent -> Log.i(
                TAG,
                "[${event.sourceComponent}] operation: ${event.operationId} [${event.status.value}]" +
                    event.params.ifNotEmpty { " $it" },
            )
            is PermissionEvent -> Log.i(
                TAG,
                "[${event.sourceComponent}] permission: ${event.permissions.map { "${it.key}=${it.value.value}" }}",
            )
            is IntentionEvent -> Log.i(
                TAG,
                "[${event.sourceComponent}] intention: ${event.intentionId}" +
                    event.params.ifNotEmpty { " $it" },
            )
            is UiStateEvent -> Log.i(
                TAG,
                "[${event.sourceComponent}] ${event.state.value}: ${event.elementId}" +
                    event.extras.ifNotEmpty { " $it" },
            )
        }
    }

    override fun log(level: Level, tag: String, message: String, params: Map<String, Any>) {
        val priority = when (level) {
            Level.Verbose -> Log.VERBOSE
            Level.Debug -> Log.DEBUG
            Level.Info -> Log.INFO
            Level.Warning -> Log.WARN
            Level.Error -> Log.ERROR
        }

        Log.println(priority, tag, "$message${params.ifNotEmpty { " $it" }}")
    }

    override fun log(throwable: Throwable, message: String?, params: Map<String, Any>) {
        Log.e(TAG, "$message${params.ifNotEmpty { " $it" }}", throwable)
    }

    private fun <K, V> Map<K, V>.ifNotEmpty(transform: (Map<K, V>) -> String): String {
        return if (isNotEmpty()) transform(this) else ""
    }

    companion object {
        private const val TAG = "Luna"
    }

}
