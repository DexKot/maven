package com.dexkot.mobile.core.logger.events.ui.interaction

import com.dexkot.mobile.core.logger.events.ui.Parameter
import com.dexkot.mobile.core.logger.events.LogEvent

/**
 * This event represent some user interaction: the user click some button, tap some image,
 * scroll to the end of a list, etc.
 */
class InteractionEvent(
    val sourceComponent: String,
    val interaction: Interaction,
    val elementId: String,
    val extras: Map<String, String> = mapOf()
): LogEvent {

    override val type: String = "ui_interaction"

    override val parameters: Map<String, Any> = buildMap {
        put(Parameter.SOURCE_COMPONENT, sourceComponent)
        put(Parameter.ELEMENT_ID, elementId)
        put(Parameter.INTERACTION, interaction.value)
        extras.forEach { (key, value) -> put("extra_$key", value) }
    }

}

