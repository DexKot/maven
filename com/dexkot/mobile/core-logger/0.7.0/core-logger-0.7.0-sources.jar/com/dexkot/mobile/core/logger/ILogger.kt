package com.dexkot.mobile.core.logger

import com.dexkot.mobile.core.logger.events.LogEvent
import com.dexkot.mobile.core.logger.levels.Level

interface ILogger {

    /**
     * Set the user id to be used by the analytics / logs platform.
     * This id will be used to identify the user along different sessions.
     *
     * @param identifier The current user id
     */
    fun setUserId(identifier: String)

    /**
     * Set a user property to be used by the analytics / logs platform. This property will be associated
     * to every event / log sent from this device.
     *
     * @param key The key of the property
     * @param value The value of the property
     */
    fun setUserProperty(key: String, value: String?)

    /**
     * Remove the user id from the analytics / logs platform. This method should be invoked
     * if the user logs out of the app.
     */
    fun removeUserId()

    /**
     * Remove a user property from the analytics / logs platform.
     *
     * @param key The key of the property to be removed
     */
    fun removeUserProperty(key: String)

    /**
     * Log an event to the analytics platform. This event will be used by the data team to elaborate
     * statistics and metrics about the app usage.
     *
     * @param event The event to be logged
     */
    fun log(event: LogEvent)

    /**
     * Log a simple message (like the ones logged in the console). This message will be used by developers
     * to debug the app, find errors and fix them.
     *
     * @param level The level of the message (Accepted values are: [Level.Verbose], [Level.Debug], [Level.Info], [Level.Warning], [Level.Error])
     * @param tag The tag of the message (usually the class name, but can be anything)
     * @param message The message to be logged
     * @param params A map of parameters to be logged with the message (for example, variable values)
     */
    fun log(level: Level, tag: String, message: String, params: Map<String, Any> = mapOf())

    /**
     * Log an exception caught in some operation. This exception will be logged with the entire stacktrace
     * and will be used by developers to debug the app, find errors and fix them.
     *
     * @param throwable The exception to be logged
     * @param message An optional message to be logged with the exception
     * @param params A map of parameters to be logged with the exception (for example, variable values)
     */
    fun log(throwable: Throwable, message: String? = null, params: Map<String, Any> = mapOf())

}
