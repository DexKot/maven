package com.dexkot.mobile.core.logger.events.ui.interaction

enum class Interaction(
    val value: String,
) {

    Tap("tap"),
    Swipe("swipe"),
    ZoomIn("zoom_in"),
    ZoomOut("zoom_out"),
    DragStart("drag_start"),
    DragEnd("drag_end"),
    Search("search"),
    Done("done");

}
