package com.dexkot.mobile.core.logger.events.ui.navigation

import com.dexkot.mobile.core.logger.events.ui.Parameter
import com.dexkot.mobile.core.logger.events.LogEvent

/**
 * This event represent some user interaction: the user click some button, tap some image,
 * scroll to the end of a list, etc.
 */
class NavigationEvent(
    val sourceComponent: String,
    val navigationId: String,
    val params: Map<String, Any> = emptyMap()
): LogEvent {

    override val type: String = "ui_navigation"

    override val parameters: Map<String, Any> = buildMap {
        put(Parameter.SOURCE_COMPONENT, sourceComponent)
        put(Parameter.NAVIGATION_ID, navigationId)
        params.forEach { (key, value) -> put("parameter_$key", value) }
    }

}

