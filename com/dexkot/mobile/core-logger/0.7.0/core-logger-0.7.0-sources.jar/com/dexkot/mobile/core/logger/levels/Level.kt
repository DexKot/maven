package com.dexkot.mobile.core.logger.levels

enum class Level(
    val value: String
) {

    Verbose("verbose"),
    Debug("debug"),
    Info("info"),
    Warning("warning"),
    Error("error");

}
