package com.dexkot.mobile.core.logger.interactors.ddl

import com.dexkot.mobile.core.logger.context.LoggerContextElement

/**
 * An auxiliary function to get an [ILoggerInteractor] from the current coroutine/thread context,
 * or the default logger if no context is available.
 */
fun logger(): ILoggerInteractor? {
    return LoggerContextElement.current()
}

/**
 * An auxiliary function to log events using the [ILoggerInteractor].
 * If no logger is available in the current context, the block is not executed.
 */
fun logger(
    block: ILoggerInteractor.() -> Unit
) {
    logger()?.block()
}
