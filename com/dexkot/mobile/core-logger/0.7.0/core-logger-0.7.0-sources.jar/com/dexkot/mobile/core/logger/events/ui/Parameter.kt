package com.dexkot.mobile.core.logger.events.ui

/**
 * This class defines the keys for the parameters that are usually sent to the logger platform in
 * order to avoid typos.
 */
internal object Parameter {

    /* Common parameters */
    const val SOURCE_COMPONENT = "source"

    /* Navigation parameters */
    const val NAVIGATION_ID = "navigation_id"

    /* Intention parameters */
    const val INTENTION_ID = "intention_id"

    /* Screen parameters */
    const val ACTION = "action"

    /* Interaction parameters */
    const val ELEMENT_ID = "element_id"
    const val INTERACTION = "interaction"

    /* State parameters */
    const val STATE = "state"

    /* Operation parameters */
    const val OPERATION_ID = "operation_id"
    const val STATUS = "status"

}