package com.dexkot.mobile.core.di.koin

import com.dexkot.mobile.core.remoteconfig.handler.FirebaseRemoteConfigHandler
import com.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import com.dexkot.mobile.core.remoteconfig.handler.PostHogRemoteConfigHandler
import com.dexkot.mobile.core.remoteconfig.provider.IRemoteConfigProvider
import com.dexkot.mobile.core.remoteconfig.provider.RemoteConfigProvider
import com.google.firebase.Firebase
import com.google.firebase.remoteconfig.remoteConfig
import com.posthog.PostHog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.koin.core.qualifier.named
import org.koin.dsl.module

fun firebaseRemoteConfig() = named("firebase_remote_config")
fun postHogRemoteConfig() = named("posthog_remote_config")
internal fun remoteConfigCoroutineScope() = named("remote_config_coroutine_scope")

val RemoteConfigModule = module {

    single<CoroutineScope>(remoteConfigCoroutineScope()) {
        CoroutineScope(SupervisorJob() + Dispatchers.Default)
    }

    factory<IRemoteConfigHandler>(firebaseRemoteConfig()) { parameters ->
        FirebaseRemoteConfigHandler(
            firebaseRemoteConfig = Firebase.remoteConfig,
            coroutineScope = get(remoteConfigCoroutineScope()),
            syncTimeOut = parameters.get(),
            serializer = parameters.get()
        )
    }

    factory<IRemoteConfigHandler>(postHogRemoteConfig()) { parameters ->
        PostHogRemoteConfigHandler(
            postHog = PostHog,
            coroutineScope = get(remoteConfigCoroutineScope()),
            serializer = parameters.get()
        )
    }

    factory<IRemoteConfigProvider> {
        RemoteConfigProvider(
            remoteConfigHandler = get()
        )
    }

}
