package com.dexkot.mobile.core.di.koin

import android.content.Context
import com.dexkot.mobile.core.ui.navigation.action.INavActionDispatcher
import com.dexkot.mobile.core.ui.navigation.action.INavActionFactory
import com.dexkot.mobile.core.ui.navigation.action.NavActionDispatcher
import com.dexkot.mobile.core.ui.preferences.IUiPreferences
import com.dexkot.mobile.core.ui.preferences.UiPreferences
import com.dexkot.mobile.core.ui.resources.IResourceProvider
import com.dexkot.mobile.core.ui.resources.ResourceProvider
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val UiModule = module {

    single<INavActionDispatcher> {
        NavActionDispatcher(
            factories = getAll<INavActionFactory<*>>()
        )
    }

    single<IUiPreferences> {
        UiPreferences(
            sharedPreferences = androidContext()
                .getSharedPreferences("com.dexkot.ui.preferences", Context.MODE_PRIVATE)
        )
    }

    factory<IResourceProvider> {
        ResourceProvider(
            context = get()
        )
    }

}
