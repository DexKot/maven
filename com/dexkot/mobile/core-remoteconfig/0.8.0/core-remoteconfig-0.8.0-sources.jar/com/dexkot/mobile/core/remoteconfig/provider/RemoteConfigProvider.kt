package com.dexkot.mobile.core.remoteconfig.provider

import com.dexkot.mobile.core.foundation.result.getOrDefault
import com.dexkot.mobile.core.foundation.result.unwrap
import com.dexkot.mobile.core.remoteconfig.handler.IRemoteConfigHandler
import kotlinx.coroutines.flow.StateFlow

internal class RemoteConfigProvider(
    override val remoteConfigHandler: IRemoteConfigHandler
): IRemoteConfigProvider {

    override fun getBoolean(
        key: String
    ): Boolean? {
        return remoteConfigHandler.getBoolean(key).unwrap()
    }

    override fun getString(
        key: String
    ): String? {
        return remoteConfigHandler.getString(key).unwrap()
    }

    override fun getLong(
        key: String
    ): Long? {
        return remoteConfigHandler.getLong(key).unwrap()
    }

    override fun getBoolean(
        key: String,
        defaultValue: Boolean
    ): Boolean {
        return remoteConfigHandler.getBoolean(key).getOrDefault(defaultValue)
    }

    override fun getString(
        key: String,
        defaultValue: String
    ): String {
        return remoteConfigHandler.getString(key).getOrDefault(defaultValue)
    }

    override fun getLong(
        key: String,
        defaultValue: Long
    ): Long {
        return remoteConfigHandler.getLong(key).getOrDefault(defaultValue)
    }

    override fun getBooleanFlow(
        key: String,
        defaultValue: Boolean
    ): StateFlow<Boolean> {
        return remoteConfigHandler.getBooleanFlow(key, defaultValue)
    }

    override fun getLongFlow(
        key: String,
        defaultValue: Long
    ): StateFlow<Long> {
        return remoteConfigHandler.getLongFlow(key, defaultValue)
    }

    override fun getStringFlow(
        key: String,
        defaultValue: String
    ): StateFlow<String> {
        return remoteConfigHandler.getStringFlow(key, defaultValue)
    }

}
