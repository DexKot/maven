package com.dexkot.mobile.core.remoteconfig.error

import com.dexkot.mobile.core.foundation.errors.ErrorEntity
import com.dexkot.mobile.core.foundation.errors.ErrorSeverity
import com.dexkot.mobile.core.foundation.CommonParcelize

@CommonParcelize
class ConfigNotFound(
    val configKey: String
): ErrorEntity.BusinessError(
    exception = null,
    severity = ErrorSeverity.INFO
)
