package com.dexkot.mobile.core.remoteconfig.handler

import com.dexkot.mobile.core.foundation.result.ResultOf
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.Json

interface IRemoteConfigHandler {

    val serializer: Json

    suspend fun sync(): ResultOf<Boolean>

    fun getBoolean(
        key: String
    ): ResultOf<Boolean>

    fun getLong(
        key: String
    ): ResultOf<Long>

    fun getString(
        key: String
    ): ResultOf<String>

    fun getBooleanFlow(
        key: String,
        defaultValue: Boolean
    ): StateFlow<Boolean>

    fun getLongFlow(
        key: String,
        defaultValue: Long
    ): StateFlow<Long>

    fun getStringFlow(
        key: String,
        defaultValue: String
    ): StateFlow<String>

}
